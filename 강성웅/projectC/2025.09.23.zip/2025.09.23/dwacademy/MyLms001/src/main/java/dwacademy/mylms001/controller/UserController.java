package dwacademy.mylms001.controller;

import dwacademy.mylms001.entity.User;
import dwacademy.mylms001.service.UserService; // 패키지명에 맞게 조정
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.Objects;

@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * ========= 로그인 =========
     */
    @GetMapping({"/user/login", "/login"})
    public String loginForm() {
        return "login"; // templates/login.html
    }

    @PostMapping("/user/login")
    public String login(@RequestParam("nickname") String nickname,
                        @RequestParam("password") String password,
                        HttpServletRequest request,
                        RedirectAttributes ra) {
        return userService.login(nickname, password)
                .map(u -> {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("loginUser", u);
                    return "redirect:/";
                })
                .orElseGet(() -> {
                    ra.addFlashAttribute("errorMessage", "아이디 또는 비밀번호가 맞지 않습니다.");
                    return "redirect:/login";
                });
    }

    @GetMapping("/user/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) session.invalidate();
        return "redirect:/";
    }

    /**
     * ========= 회원가입 폼 =========
     */
    @GetMapping("/user/add")
    public String signupForm(Model model) {
        if (!model.containsAttribute("form")) {
            model.addAttribute("form", new SignupForm());
        }
        return "signup"; // templates/user/add.html 로 매핑
    }

    /**
     * ========= 회원가입 처리 =========
     */
    @PostMapping("/user/add")
    public String signup(@Valid SignupForm form, RedirectAttributes ra) {
        // 비밀번호 확인
        if (!Objects.equals(form.getPassword(), form.getPassword2())) {
            ra.addFlashAttribute("errorMessage", "비밀번호가 일치하지 않습니다.");
            ra.addFlashAttribute("form", form);
            return "redirect:/user/add";
        }

        // 폰 정리(숫자/하이픈만 유지)
        if (form.getPhone() != null) {
            String p = form.getPhone().replaceAll("[^\\d-]", "").replaceAll("-{2,}", "-");
            form.setPhone(p);
        }

        // 기본값 보정
        if (form.getRole() == null) form.setRole(User.Role.STUDENT);

        try {
            // 서비스에 저장 위임 (구현체에서 INSERT 처리)
            User u = new User();
            u.setNickname(form.getNickname());
            u.setPassword(form.getPassword()); // 실제 배포에선 반드시 해시 처리
            u.setEmail(form.getEmail());
            u.setName(form.getName());
            u.setBirth_day(form.getBirth_day());
            u.setGender(form.getGender());
            u.setAddress(form.getAddress());
            // detailAddress를 DB에 저장할 필드가 따로 있으면 거기에 넣으세요
            u.setPhone(form.getPhone());
            u.setRole(form.getRole());

            userService.register(u, form.getAffiliation(), form.getBio()); // 필요 메서드 형태에 맞게 조정

            ra.addFlashAttribute("successMessage", "회원가입이 완료되었습니다. 로그인 해주세요.");
            return "redirect:/login";
        } catch (Exception e) {
            e.printStackTrace();
            ra.addFlashAttribute("errorMessage", "회원가입 처리 중 오류가 발생했습니다.");
            ra.addFlashAttribute("form", form);
            return "redirect:/user/add";
        }
    }

    /**
     * ===== 폼 DTO =====
     */
    @Getter
    @Setter
    public static class SignupForm {
        private String nickname;
        private String password;
        private String password2;
        private String email;
        private String name;
        private LocalDate birth_day;
        private User.Gender gender;         // "MALE"/"FEMALE" (숨은 input #gender로 셋)
        private String address;
        private String detailAddress;
        private String phone;
        private User.Role role;             // "STUDENT"/"INSTRUCTOR" (숨은 input #role로 셋)
        private String affiliation;         // 강사 전용
        private String bio;                 // 강사 전용
        private boolean noteAgree;
        private boolean emailAgree;
    }
}