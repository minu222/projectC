package dwacademy.mylms001.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping({"/", "/home"})
    public String homePage(Model model) {
        model.addAttribute("bodyFragment", "index :: indexContent");
        model.addAttribute("title", "MyLms");
        model.addAttribute("activeCategory", "home");
        model.addAttribute("userRole", "guest"); // guest / 학생 / 강사 구분 가능
        model.addAttribute("showSidebar", false);
        return "layout";
    }
}