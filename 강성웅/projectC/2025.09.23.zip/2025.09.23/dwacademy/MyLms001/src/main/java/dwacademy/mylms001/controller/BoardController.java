package dwacademy.mylms001.controller;

import dwacademy.mylms001.board.BoardType;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;

/**
 * BoardController (통합 라우팅 버전)
 * ----------------------------------------------------------------------
 * ✅ 사용 방법(템플릿/링크 규약)
 * 1) 목록 템플릿(예: board/freeBoard.html)
 *    - 프래그먼트명: <div th:fragment="content"> ... </div>
 *    - 모델 입력: posts(List<?>), typeSlug(String)
 *    - 제목 링크:  <a th:href="@{|/board/${typeSlug}/${post.id}|}" th:text="${post.title}"></a>
 *    - 검색 파라미터(권장): q(검색어), f(필터)
 *
 * 2) 상세 템플릿(예: board/freeDetail.html, board/noticeDetail.html ...)
 *    - 프래그먼트명: <div th:fragment="content"> ... </div>
 *    - 모델 입력: post(Object), typeSlug(String)
 *    - 목록 링크: <a th:href="@{|/board/${typeSlug}|}">목록</a>
 *
 * 3) 글쓰기 템플릿(board/write.html)
 *    - 프래그먼트명: <div th:fragment="content"> ... </div>
 *    - GET:  /board/{type}/write  -> 모델: typeSlug(String), (선택) boardTitle(String)
 *    - POST: /board/{type}/write  -> 저장 후 목록으로 redirect (또는 신규 글 상세로 redirect)
 *    - form action: th:action="@{|/board/${typeSlug}/write|}"
 *
 * 4) 컨트롤러가 제공하는 공통 모델
 *    - activeCategory="board", showSidebar=true (레이아웃에서 사이드바 출력)
 *    - bodyFragment = "파일경로 :: content"
 *
 * 5) BoardType 매핑
 *    - /board/notice         → BoardType.NOTICE
 *    - /board/faq            → BoardType.FAQ
 *    - /board/free           → BoardType.FREE
 *    - /board/qna            → BoardType.QNA
 *    - /board/teacherReview  → BoardType.TEACHER_REVIEW
 *    - /board/courseReview   → BoardType.COURSE_REVIEW
 *    - 상세/글쓰기는 공통 경로 사용: /board/{type}/{id}, /board/{type}/write
 *
 * ⚠️ 서비스 연동 시
 *    - 아래 각 목록/상세/저장 지점에 표시한 [DB] 섹션을 채우면 됩니다.
 * ----------------------------------------------------------------------
 */
@Controller
@RequestMapping("/board")
public class BoardController {

    /* ───────────────── 공통 유틸 ───────────────── */

    /** 레이아웃에 프래그먼트 주입 + 공통 모델 세팅 */
    private String setupBoardModel(Model model, String fragment, String title) {
        model.addAttribute("bodyFragment", fragment);
        model.addAttribute("title", title);
        model.addAttribute("showSidebar", true);   // 사이드바 ON
        model.addAttribute("userRole", "guest");   // 권한 표시는 필요 시 수정
        model.addAttribute("activeCategory", "board");
        return "layout";
    }

    /** BoardType → typeSlug 모델 주입 */
    private void setTypeSlug(Model model, BoardType bt) {
        model.addAttribute("typeSlug", bt.slug());
    }

    /** 문자열 type을 BoardType으로 안전 변환 (잘못된 타입은 404) */
    private BoardType safeType(String type) {
        try {
            return BoardType.from(type);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown board type: " + type);
        }
    }

    /** 페이지 타이틀(브라우저 탭 제목 등) */
    private String toBoardTitle(BoardType bt) {
        return switch (bt) {
            case NOTICE          -> "MyLms";
            case FAQ             -> "MyLms";
            case FREE            -> "MyLms";
            case QNA             -> "MyLms";
            case TEACHER_REVIEW  -> "MyLms";
            case COURSE_REVIEW   -> "MyLms";
        };
    }

    /* ───────────────── 목록 라우트 ───────────────── */

    /** /board → 공지 목록으로 이동 (기본 탭 역할) */
    @GetMapping
    public String boardPage(Model model,
                            @RequestParam(required = false) String q,
                            @RequestParam(required = false) String f) {

        setTypeSlug(model, BoardType.NOTICE);

        // [DB] 검색/필터(q, f) 적용해 목록 생성
        // final var posts = noticeService.findAll(q, f, pageable);
        model.addAttribute("posts", Collections.emptyList()); // 안전 기본값

        return setupBoardModel(model, BoardType.NOTICE.listFragment(), toBoardTitle(BoardType.NOTICE));
    }

    /** 개별 목록 엔드포인트(필요 시 유지) — 각 템플릿을 바로 호출 */
    @GetMapping("/notice")
    public String noticeBoard(Model model,
                              @RequestParam(required = false) String q,
                              @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.NOTICE);
        // [DB] var posts = noticeService.findAll(q, f);
        model.addAttribute("posts", Collections.emptyList());
        return setupBoardModel(model, BoardType.NOTICE.listFragment(), toBoardTitle(BoardType.NOTICE));
    }

    @GetMapping("/faq")
    public String faqBoard(Model model,
                           @RequestParam(required = false) String q,
                           @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.FAQ);
        // [DB] var posts = faqService.findAll(q, f);
        model.addAttribute("posts", Collections.emptyList());
        return setupBoardModel(model, BoardType.FAQ.listFragment(), toBoardTitle(BoardType.FAQ));
    }

    @GetMapping("/free")
    public String freeBoard(Model model,
                            @RequestParam(required = false) String q,
                            @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.FREE);
        // [DB] var posts = freeService.findAll(q, f);
        model.addAttribute("posts", Collections.emptyList());
        return setupBoardModel(model, BoardType.FREE.listFragment(), toBoardTitle(BoardType.FREE));
    }

    @GetMapping("/qna")
    public String qnaBoard(Model model,
                           @RequestParam(required = false) String q,
                           @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.QNA);
        // [DB] var posts = qnaService.findAll(q, f);
        model.addAttribute("posts", Collections.emptyList());
        return setupBoardModel(model, BoardType.QNA.listFragment(), toBoardTitle(BoardType.QNA));
    }

    @GetMapping("/courseReview")
    public String courseReview(Model model,
                               @RequestParam(required = false) String q,
                               @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.COURSE_REVIEW);
        // [DB] var posts = reviewService.findAllCourseReviews(q, f);
        model.addAttribute("posts", Collections.emptyList());
        return setupBoardModel(model, BoardType.COURSE_REVIEW.listFragment(), toBoardTitle(BoardType.COURSE_REVIEW));
    }

    @GetMapping("/teacherReview")
    public String teacherReview(Model model,
                                @RequestParam(required = false) String q,
                                @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.TEACHER_REVIEW);
        // [DB] var posts = reviewService.findAllTeacherReviews(q, f);
        model.addAttribute("posts", Collections.emptyList());
        return setupBoardModel(model, BoardType.TEACHER_REVIEW.listFragment(), toBoardTitle(BoardType.TEACHER_REVIEW));
    }

    /* ───────────────── 글쓰기 ───────────────── */

    /**
     * GET 글쓰기 폼
     * - URL : /board/{type}/write
     * - 모델: typeSlug(String), (선택) boardTitle(String)
     * - 뷰  : board/write :: content
     */
    @GetMapping("/{type}/write")
    public String writeForm(@PathVariable String type, Model model) {
        final BoardType bt = safeType(type);
        setTypeSlug(model, bt);
        model.addAttribute("boardTitle", toBoardTitle(bt)); // 템플릿에서 제목 표시용
        return setupBoardModel(model, "board/write :: content",
                toBoardTitle(bt) + " 글쓰기");
    }

    /**
     * POST 글 저장
     * - URL : /board/{type}/write
     * - 파라미터: title, content (WYSIWYG HTML)
     * - 저장 후: 목록으로 redirect (또는 생성된 글 상세로 redirect 권장)
     */
    @PostMapping("/{type}/write")
    public String writeSubmit(@PathVariable String type,
                              @RequestParam String title,
                              @RequestParam String content) {

        final BoardType bt = safeType(type);

        // [DB] 저장 로직
        // 1) 생성: Long newId = postService.create(bt, title, content, authorId, ...);
        // 2) 권장: return "redirect:/board/" + bt.slug() + "/" + newId;   // 생성된 글 상세로 이동
        //    현재는 목록으로 이동:
        return "redirect:/board/" + bt.slug();
    }

    /* ───────────────── 상세 ───────────────── */

    /**
     * 상세 보기
     * - URL : /board/{type}/{id}
     * - id는 숫자만 허용 (write와 경로 충돌 방지)
     * - 모델: post(Object), typeSlug(String)
     * - 뷰  : {BoardType.detailFragment()}  예) board/freeDetail :: content
     */
    @GetMapping("/{type}/{id:\\d+}")
    public String boardDetail(@PathVariable String type,
                              @PathVariable Long id,
                              Model model) {

        final BoardType bt = safeType(type);

        // [DB] 실제 상세 조회
        // final var post = postService.findById(bt, id)
        //                  .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        final Object post = null; // 서비스 연동 전 안전값

        model.addAttribute("post", post);
        setTypeSlug(model, bt);
        return setupBoardModel(model, bt.detailFragment(),
                toBoardTitle(bt) + " 상세");
    }
}
