function addComment() {
    const input = document.getElementById('comment-input');
    const content = input.value.trim();
    if (!content) return alert('댓글 내용을 입력하세요.');

    const commentList = document.getElementById('comment-list');

    const newComment = document.createElement('div');
    newComment.className = 'comment-item';
    newComment.innerHTML = `
            <div class="author">사용자</div>
            <div class="date">${new Date().toLocaleString()}</div>
            <div class="content">${content}</div>
        `;
    commentList.appendChild(newComment);
    input.value = '';
}