// ✅ 로그인 사용자(예시). 실제론 서버에서 주입/렌더링 하거나 전역으로 셋업
const currentUserId = 'teacher1';
let isInstructor = true; // 기존 그대로 사용

// ✅ books에 소유자(ownerId) 필드 추가 (예시 데이터)
// [DB] 초기 렌더 전에 서버에서 리스트를 받아오도록 변경 예정
const books = [
    {img:'https://via.placeholder.com/200x150', instructor:'강사1', title:'책 제목1', desc:'소개글1', ownerId:'teacher1'},
    {img:'https://via.placeholder.com/200x150', instructor:'강사2', title:'책 제목2', desc:'소개글2', ownerId:'teacher2'},
    {img:'https://via.placeholder.com/200x150', instructor:'강사3', title:'책 제목3', desc:'소개글3', ownerId:'teacher3'},
];

// === 중략 (itemsPerPage, currentPage, renderCards, renderPagination, 검색 로직 등 기존 그대로) ===

// ✅ "수정" 버튼 동작 변경: 내 목록에서 선택 → 수정 모달 열기
document.getElementById('editBtn').addEventListener('click', ()=>{
    if(!isInstructor){ alert('수정 권한이 없습니다.'); return; }
    openMyListForEdit();  // ▶ 내 리스트 선택 모달/오버레이 열기
});

// ✅ "삭제" 버튼도 내 소유만 선택 가능하게 제한 (체크박스 목록 구성 시 필터)
document.getElementById('deleteBtn').addEventListener('click', ()=>{
    if(!isInstructor){ alert('삭제 권한이 없습니다.'); return; }
    openDeleteModal(); // 아래 함수 내부 수정됨
});

// ✅ 등록 시 ownerId 세팅
document.getElementById('registerBtn').addEventListener('click', ()=>{
    if(!isInstructor){ alert('등록 권한이 없습니다.'); return; }
    openModal(); // 새 등록
});

// ✅ 공통 모달 오픈(등록/수정) - 소유권 체크 추가
function openModal(book=null, idx=null){
    modalOverlay.style.display='flex';
    const instructorInput=document.getElementById('instructorInput');
    const titleInput=document.getElementById('titleInput');
    const descInput=document.getElementById('descInput');
    const imgInput=document.getElementById('imgInput');

    if(book){
        // 🔒 소유자만 수정 허용
        if(book.ownerId !== currentUserId){
            alert('본인이 등록한 도서만 수정할 수 있습니다.');
            modalOverlay.style.display='none';
            return;
        }
        instructorInput.value=book.instructor;
        titleInput.value=book.title;
        descInput.value=book.desc;
    } else {
        instructorInput.value='';
        titleInput.value='';
        descInput.value='';
    }

    document.getElementById('saveBtn').onclick=()=>{
        // [DB] 저장/수정은 서버 API로 변경 예정 (아래는 프론트 임시 동작)
        const reader=new FileReader();
        reader.onload=function(e){
            const imgData=e.target.result;
            if(book){
                // 수정
                // [DB] PUT /books/{id} 호출로 대체
                books[idx] = {
                    ...books[idx],
                    instructor: instructorInput.value,
                    title: titleInput.value,
                    desc: descInput.value,
                    img: imgData
                };
            } else {
                // 등록
                // [DB] POST /books 호출로 대체
                books.push({
                    instructor: instructorInput.value,
                    title: titleInput.value,
                    desc: descInput.value,
                    img: imgData,
                    ownerId: currentUserId // ✅ 소유자 등록
                });
            }
            modalOverlay.style.display='none';
            renderCards();
            renderPagination();
        }
        if(imgInput.files[0]){
            reader.readAsDataURL(imgInput.files[0]);
        } else {
            if(book){
                // [DB] PUT /books/{id}
                books[idx] = {
                    ...books[idx],
                    instructor: instructorInput.value,
                    title: titleInput.value,
                    desc: descInput.value
                };
            } else {
                // [DB] POST /books
                books.push({
                    instructor: instructorInput.value,
                    title: titleInput.value,
                    desc: descInput.value,
                    img:'https://via.placeholder.com/200x150',
                    ownerId: currentUserId // ✅ 소유자 등록
                });
            }
            modalOverlay.style.display='none';
            renderCards();
            renderPagination();
        }
    }
}

// ✅ “내 목록에서 골라 수정”용 오버레이/모달 UI가 있다고 가정 (id: myEditOverlay, myEditList, myEditClose)
function openMyListForEdit(){
    const myEditOverlay = document.getElementById('myEditOverlay');
    const myEditList = document.getElementById('myEditList');
    myEditList.innerHTML = '';

    // 내 소유 책만 나열
    const myBooks = books
        .map((b, i)=>({...b, _idx:i}))
        .filter(b => b.ownerId === currentUserId);

    if(myBooks.length === 0){
        alert('내가 등록한 도서가 없습니다.');
        return;
    }

    // 목록 생성(클릭 시 해당 항목 수정 모달로)
    myBooks.forEach(b=>{
        const btn = document.createElement('button');
        btn.className = 'my-edit-item';
        btn.textContent = `${b.title} (${b.instructor})`;
        btn.addEventListener('click', ()=>{
            myEditOverlay.style.display='none';
            openModal(books[b._idx], b._idx);
        });
        myEditList.appendChild(btn);
    });

    myEditOverlay.style.display='flex';
    document.getElementById('myEditClose').onclick = ()=> myEditOverlay.style.display='none';
}

// ✅ 삭제 모달: 내 소유만 체크박스 렌더
function openDeleteModal(){
    deleteOverlay.style.display='flex';
    const listDiv=document.getElementById('deleteList');
    listDiv.innerHTML='';

    // 내 소유만 노출
    books.forEach((book, idx)=>{
        if(book.ownerId !== currentUserId) return; // 🔒 내가 등록한 것만
        const label=document.createElement('label');
        label.innerHTML=`<input type="checkbox" value="${idx}"> ${book.title} (${book.instructor})`;
        listDiv.appendChild(label);
    });
}

// ✅ 삭제 확인: 소유권 체크(이중 보호)
document.getElementById('deleteConfirmBtn').addEventListener('click', ()=>{
    // [DB] DELETE /books/batch 또는 반복 DELETE /books/{id}
    const checked=document.querySelectorAll('#deleteList input[type="checkbox"]:checked');
    const indexes=[...checked].map(c=>parseInt(c.value)).sort((a,b)=>b-a);
    indexes.forEach(i=>{
        if(books[i]?.ownerId === currentUserId){
            books.splice(i,1);
        }
    });
    deleteOverlay.style.display='none';
    renderCards();
    renderPagination();
});

// === 마지막 초기 렌더는 그대로 ===
// [DB] 최초 진입 시 서버에서 목록 fetch → books 갱신 후 renderCards/renderPagination 호출
renderCards();
renderPagination();
