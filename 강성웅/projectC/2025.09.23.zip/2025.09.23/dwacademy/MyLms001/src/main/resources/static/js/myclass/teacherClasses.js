/* ===============================
 *  Teacher - My Classes (List + Edit)
 *  REST API:
 *    GET   /api/teacher/courses?status=published|closed&q=...
 *    PATCH /api/teacher/courses/{courseId}
 *  서버는 세션의 instructor_id로 자동 필터링(방법 B)
 * =============================== */

(function () {
    'use strict';

    // ---------- DOM ----------
    const grid         = document.getElementById('courseGrid');
    const statusFilter = document.getElementById('statusFilter'); // 전체/정상/중지
    const searchBox    = document.getElementById('searchBox');
    const searchBtn    = document.getElementById('searchBtn');

    // Edit modal
    const editModal    = document.getElementById('editModal');
    const editForm     = document.getElementById('editForm');
    const editName     = document.getElementById('editName');
    const editPeriod   = document.getElementById('editPeriod');
    const editType     = document.getElementById('editType');   // VOD/개인강의/다수강의
    const editStatus   = document.getElementById('editStatus'); // 정상/중지
    const editIdInput  = document.getElementById('editId');     // 숨겨진 input(있으면 사용)

    let editingCourseId = null;   // 현재 수정 중인 course_id
    let lastCourses = [];         // 마지막 조회 결과(모달 채울 때 사용)

    // ---------- Utils ----------
    const $ = (sel, p = document) => p.querySelector(sel);

    function fmtDateOnly(d) {
        if (!d) return '';
        const s = String(d);
        const m = s.match(/^(\d{4}-\d{2}-\d{2})/);
        return m ? m[1] : s;
    }

    function mapStatusToUi(db) {
        if (!db) return '정상';
        return String(db).toLowerCase() === 'closed' ? '중지' : '정상';
    }

    function mapFilterToDb(ui) {
        if (!ui || ui === '전체') return '';
        if (ui === '중지') return 'closed';
        return 'published';
    }

    function buildPeriod(created_at, expiry_date) {
        const left  = fmtDateOnly(created_at);
        const right = fmtDateOnly(expiry_date);
        if (left && right) return `${left} ~ ${right}`;
        if (right) return right;
        return left || '';
    }

    function escapeHtml(s) {
        return String(s)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');
    }

    function toast(msg) {
        try {
            const t = document.createElement('div');
            t.textContent = msg;
            t.style.cssText =
                'position:fixed;left:50%;top:70px;transform:translateX(-50%);' +
                'background:#333;color:#fff;padding:10px 14px;border-radius:8px;' +
                'z-index:9999;opacity:.95';
            document.body.appendChild(t);
            setTimeout(() => t.remove(), 1800);
        } catch { alert(msg); }
    }

    // ---------- Data fetch ----------
    async function fetchCourses({ status = '', q = '' } = {}) {
        const params = new URLSearchParams();
        if (status) params.set('status', status);
        if (q)      params.set('q', q);

        const url = '/api/teacher/courses' + (params.toString() ? `?${params}` : '');
        const res = await fetch(url, { method: 'GET' });
        if (!res.ok) throw new Error('강의 목록을 불러오지 못했습니다.');
        return res.json(); // [{course_id,title,category,status,created_at,expiry_date,...}]
    }

    // ---------- Render ----------
    function renderCourses(courses) {
        lastCourses = Array.isArray(courses) ? courses : [];
        grid.innerHTML = '';

        if (lastCourses.length === 0) {
            const empty = document.createElement('div');
            empty.textContent = '표시할 강의가 없습니다.';
            empty.style.cssText = 'padding:24px;color:#666;';
            grid.appendChild(empty);
            return;
        }

        lastCourses.forEach(c => {
            const { course_id, title, category, status, created_at, expiry_date } = c;

            const card = document.createElement('div');
            card.className = 'course-card';
            card.dataset.courseId = course_id;

            const period = buildPeriod(created_at, expiry_date);
            const statusUi = mapStatusToUi(status);

            card.innerHTML = `
        <div class="course-title">${escapeHtml(title || '')}</div>
        <div class="course-meta">
          <div>기간: ${escapeHtml(period)}</div>
          <div>유형: ${escapeHtml(category || 'VOD')}</div>
          <div>상태: ${escapeHtml(statusUi)}</div>
        </div>
        <div class="course-actions">
          <button class="btn-edit">수정</button>
          <button class="btn-students">학생 리스트</button>
        </div>
      `;

            grid.appendChild(card);

            // 액션 바인딩
            $('.btn-edit', card)?.addEventListener('click', () => openEditModal(course_id));
            $('.btn-students', card)?.addEventListener('click', () => {
                toast('학생 리스트는 준비 중입니다.');
            });
        });
    }

    // ---------- Modal ----------
    function openEditModal(courseId) {
        const course = lastCourses.find(c => String(c.course_id) === String(courseId));
        if (!course) {
            alert('강의를 찾을 수 없습니다.');
            return;
        }

        editingCourseId = courseId;
        if (editIdInput) editIdInput.value = String(courseId);

        editName.value   = course.title || '';
        editType.value   = course.category || 'VOD';
        editStatus.value = mapStatusToUi(course.status);
        editPeriod.value = buildPeriod(course.created_at, course.expiry_date);

        if (editModal) editModal.style.display = 'block';
    }

    function closeEditModal() {
        editingCourseId = null;
        if (editIdInput) editIdInput.value = '';
        if (editModal) editModal.style.display = 'none';
    }
    // 혹시 남아있는 인라인 호출 대비
    window.closeEditModal = closeEditModal;

    // 닫기 버튼(X)
    document.querySelectorAll('#editModal .closeModal')
        .forEach(btn => btn.addEventListener('click', closeEditModal));

    // 모달 밖 클릭 시 닫기
    window.addEventListener('click', (e) => {
        if (e.target === editModal) closeEditModal();
    });

    // 저장(수정 완료)
    editForm?.addEventListener('submit', async (e) => {
        e.preventDefault();

        // hidden input 우선, 없으면 메모리 변수 사용
        const idFromDom = editIdInput?.value?.trim();
        const courseId = idFromDom || editingCourseId;

        if (!courseId) { alert('수정할 강의를 찾을 수 없습니다.'); return; }

        const payload = {
            title:    editName.value?.trim(),
            period:   editPeriod.value?.trim(),  // "YYYY-MM-DD ~ YYYY-MM-DD"
            category: editType.value,
            status:   editStatus.value           // 정상/중지 (서버에서 DB 값으로 변환)
        };

        if (!payload.title)  return alert('강의명을 입력하세요.');
        if (!payload.period) return alert('기간을 입력하세요.');

        try {
            const res = await fetch(`/api/teacher/courses/${courseId}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok || data.ok === false) {
                throw new Error(data.message || '수정에 실패했습니다.');
            }

            closeEditModal();
            toast('수정되었습니다.');
            await loadCourses(); // 목록 갱신
        } catch (err) {
            console.error(err);
            alert(err.message || '오류가 발생했습니다.');
        }
    });

    // ---------- List load with filters ----------
    async function loadCourses() {
        const ui = statusFilter?.value || '전체';
        const status = mapFilterToDb(ui);
        const q = searchBox?.value?.trim() || '';
        try {
            const list = await fetchCourses({ status, q });
            renderCourses(list);
        } catch (e) {
            console.error(e);
            grid.innerHTML =
                '<div style="padding:24px;color:#c00;">목록을 불러오는 중 오류가 발생했습니다.</div>';
        }
    }
    // 외부에서도 호출 가능하도록
    window.loadCourses = loadCourses;

    // 이벤트 바인딩
    statusFilter?.addEventListener('change', loadCourses);
    searchBtn?.addEventListener('click', loadCourses);
    searchBox?.addEventListener('keydown', (e) => { if (e.key === 'Enter') loadCourses(); });

    // 초기 로드
    document.addEventListener('DOMContentLoaded', loadCourses);
})();
