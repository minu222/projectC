// 모달 열기
const detailBtns = document.querySelectorAll('.detailBtn');
const modal = document.getElementById('modal');
const modalClose = document.getElementById('modalClose');

detailBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        modal.style.display = 'flex';
    });
});

// 모달 닫기
modalClose.addEventListener('click', () => {
    modal.style.display = 'none';
});

// 모달 외부 클릭 시 닫기
window.addEventListener('click', (e) => {
    if(e.target === modal) {
        modal.style.display = 'none';
    }
});

// 간단 검색 예시: 입력값/필터값을 읽어 콘솔 출력
document.getElementById('searchBtn')?.addEventListener('click', () => {
    const kw = document.getElementById('searchInput').value.trim();
    const ft = document.getElementById('filter').value;
    console.log('검색어:', kw, '필터:', ft);
    // TODO: 실제 필터링 로직/서버 요청 연결
});