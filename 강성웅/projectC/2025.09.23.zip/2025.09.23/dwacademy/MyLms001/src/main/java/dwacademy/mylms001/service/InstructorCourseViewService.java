// src/main/java/dwacademy/mylms001/service/InstructorCourseViewService.java
package dwacademy.mylms001.service;

import dwacademy.mylms001.dto.CourseCardResponse;
import dwacademy.mylms001.dto.CourseStudentItem;
import dwacademy.mylms001.repository.InstructorCourseViewRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InstructorCourseViewService {

    private final InstructorCourseViewRepository repo;

    public InstructorCourseViewService(InstructorCourseViewRepository repo) {
        this.repo = repo;
    }

    private static String toDbStatus(String kor) {
        if (kor == null || kor.isBlank() || "전체".equals(kor)) return null;
        return switch (kor) {
            case "정상" -> "published";
            case "중지" -> "closed";
            case "임시" -> "draft";
            default -> null;
        };
    }

    public List<CourseCardResponse> listForInstructor(int instructorId, String statusKor, String q) {
        return repo.findCardsByInstructor(instructorId, toDbStatus(statusKor), q);
    }

    public List<CourseStudentItem> students(long courseId, int page, int size) {
        int offset = Math.max(0, (page - 1) * size);
        return repo.findStudents(courseId, offset, size);
    }

    public int studentCount(long courseId) {
        return repo.countStudents(courseId);
    }
}

