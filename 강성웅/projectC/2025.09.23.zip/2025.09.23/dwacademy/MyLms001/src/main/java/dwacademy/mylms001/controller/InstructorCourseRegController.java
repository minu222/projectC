// src/main/java/dwacademy/mylms001/controller/InstructorCourseRegController.java
package dwacademy.mylms001.controller;

import dwacademy.mylms001.entity.User;
import dwacademy.mylms001.web.CourseCreateForm;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;

@Controller
public class InstructorCourseRegController {

    private final JdbcTemplate jdbc;

    public InstructorCourseRegController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** 강의 등록 처리 (화면 GET은 MyClassController가 담당) */
    @PostMapping("/instructor/courses/add")
    public String add(@Valid @ModelAttribute("form") CourseCreateForm form,
                      BindingResult bindingResult,
                      @RequestParam(value = "courseType", required = false) String courseType,
                      HttpSession session,
                      RedirectAttributes ra,
                      Model model) {

        // 로그인 체크
        User login = (User) session.getAttribute("loginUser");
        if (login == null) {
            ra.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
            return "redirect:/login?redirect=/myclass/teacher/register";
        }

        // 필수값 서버 검증 실패 → 같은 화면으로
        if (bindingResult.hasErrors()) {
            model.addAttribute("bodyFragment", "myclass/teacherRegisterClass :: content");
            model.addAttribute("activeCategory", "myclass");
            model.addAttribute("showSidebar", true);
            model.addAttribute("userRole", "instructor");
            return "layout";
        }

        // 카테고리 기본값
        String category = (courseType != null && !courseType.isBlank()) ? courseType : "VOD";

        // 기간 문자열에서 종료일(우측)을 만료일로 저장 (형식: "YYYY-MM-DD ~ YYYY-MM-DD")
        LocalDate expiry = parseExpiryDate(form.getPeriod());

        // INSERT (필수 컬럼만)
        String sql = """
            INSERT INTO courses
              (instructor_id, title, description, category, price, is_free, status, expiry_date, created_at, updated_at)
            VALUES
              (?,             ?,     ?,           ?,        ?,     ?,       ?,      ?,           NOW(),    NOW())
            """;

        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            int i = 1;
            ps.setInt(i++, login.getUser_id());                                  // instructor_id
            ps.setString(i++, form.getCourseName());                              // title
            ps.setString(i++, form.getDescription());                             // description
            ps.setString(i++, category);                                          // category (VOD/개인강의/다수강의)
            ps.setBigDecimal(i++, BigDecimal.valueOf(form.getFee()));            // price
            ps.setInt(i++, 0);                                                    // is_free: 0(유료)
            ps.setString(i++, "published");                                       // status 기본 'published'
            if (expiry != null) ps.setDate(i++, Date.valueOf(expiry));           // expiry_date
            else                 ps.setNull(i++, Types.DATE);
            return ps;
        }, kh);

        ra.addFlashAttribute("toast", "등록되었습니다.");
        // 완료 후 다시 등록 화면으로
        return "redirect:/myclass/teacher/register";
    }

    /** "YYYY-MM-DD ~ YYYY-MM-DD" 에서 우측 날짜만 파싱 (형식 오류면 null) */
    private static LocalDate parseExpiryDate(String period) {
        if (period == null) return null;
        String[] parts = period.split("~");
        String right = (parts.length == 2 ? parts[1] : period).trim();
        if (right.isEmpty()) return null;
        try {
            return LocalDate.parse(right);
        } catch (Exception ignored) {
            return null;
        }
    }
}
