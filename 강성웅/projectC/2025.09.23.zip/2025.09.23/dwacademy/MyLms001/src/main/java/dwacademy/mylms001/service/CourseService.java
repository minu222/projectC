package dwacademy.mylms001.service;

import dwacademy.mylms001.repository.CourseRepository;
import dwacademy.mylms001.web.CourseForm;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    /** period: "YYYY-MM-DD ~ YYYY-MM-DD" -> end date */
    private static final Pattern PERIOD = Pattern.compile(
            "\\s*(\\d{4}-\\d{2}-\\d{2})\\s*[~\\-–]\\s*(\\d{4}-\\d{2}-\\d{2})\\s*"
    );

    public long createCourse(int instructorId, CourseForm form,
                             MultipartFile mainImage, MultipartFile examFile) throws IOException {

        String category = form.getCourseType();
        String title = form.getCourseName();
        String description = form.getDescription();

        BigDecimal price = null;
        boolean isFree = false;
        if (form.getFee() != null && !form.getFee().isBlank()) {
            try {
                price = new BigDecimal(form.getFee().trim());
                isFree = price.compareTo(BigDecimal.ZERO) == 0;
            } catch (NumberFormatException ignore) {
                // 잘못된 값이면 null 처리
            }
        }

        LocalDate expiry = null;
        if (form.getPeriod() != null && !form.getPeriod().isBlank()) {
            Matcher m = PERIOD.matcher(form.getPeriod());
            if (m.find()) {
                expiry = LocalDate.parse(m.group(2)); // 끝 날짜
            }
        }

        long courseId = courseRepository.insertCourse(
                instructorId,
                title,
                description,
                category,
                price,
                isFree,
                "published", // 기본값
                0,           // 초기 수강생 수
                expiry
        );

        // 파일 저장 (DB 컬럼이 없다면 경로만 디스크에 저장)
        saveFiles(courseId, mainImage, examFile);

        return courseId;
    }

    private void saveFiles(long courseId, MultipartFile mainImage, MultipartFile examFile) throws IOException {
        Path base = Paths.get("uploads", "courses", String.valueOf(courseId));
        Files.createDirectories(base);

        if (mainImage != null && !mainImage.isEmpty()) {
            Path p = base.resolve("main_" + sanitize(mainImage.getOriginalFilename()));
            Files.copy(mainImage.getInputStream(), p, StandardCopyOption.REPLACE_EXISTING);
        }
        if (examFile != null && !examFile.isEmpty()) {
            Path p = base.resolve("exam_" + sanitize(examFile.getOriginalFilename()));
            Files.copy(examFile.getInputStream(), p, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private String sanitize(String name) {
        if (name == null) return "file";
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
