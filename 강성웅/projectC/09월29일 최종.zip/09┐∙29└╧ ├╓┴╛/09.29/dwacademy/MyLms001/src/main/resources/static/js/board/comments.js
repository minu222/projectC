(function () {
    'use strict';

    const listEl   = document.getElementById('comment-list');
    const inputEl  = document.getElementById('comment-input');
    const submitBtn= document.getElementById('comment-submit');
    const boxEl    = document.getElementById('comments');

    // postId 계산: window.__POST_ID__ 우선, 없으면 data-post-id 폴백
    let postId = Number(window.__POST_ID__ ?? 0);
    if ((!postId || Number.isNaN(postId)) && boxEl && boxEl.dataset.postId) {
        postId = Number(boxEl.dataset.postId);
    }

    if (!listEl || !submitBtn || !postId) {
        console.warn('comments.js: postId가 없거나 DOM 준비가 안 됨.', { postId });
        return;
    }

    submitBtn.addEventListener('click', async function () {
        const content = (inputEl.value || '').trim();
        if (!content) { alert('내용을 입력하세요.'); return; }

        try {
            const res = await fetch('/api/comments', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({ postId, content })
            });

            if (res.status === 401) { alert('로그인이 필요합니다.'); location.href = '/user/login'; return; }
            if (!res.ok) throw new Error('등록 실패');

            inputEl.value = '';
            await load();
        } catch (e) {
            console.error(e);
            alert('댓글 등록에 실패했습니다.');
        }
    });

    async function load() {
        listEl.innerHTML = '<div style="color:#666;padding:8px 0;">불러오는 중...</div>';
        try {
            const res = await fetch(`/api/comments?postId=${postId}`, { headers: { 'Accept': 'application/json' } });
            if (!res.ok) throw new Error('목록 조회 실패');
            const rows = await res.json();
            render(rows);
        } catch (e) {
            console.error(e);
            listEl.innerHTML = '<div style="color:#c00;">댓글을 불러오지 못했습니다.</div>';
        }
    }

    function h(s) {
        const d = document.createElement('div');
        d.innerText = s ?? '';
        return d.innerHTML;
    }

    function dateText(s) {
        if (!s) return '';
        return String(s).replace('T', ' ').slice(0, 16);
    }

    function render(rows) {
        const roots = rows.filter(r => r.parentCommentId == null);
        const children = rows.filter(r => r.parentCommentId != null);

        const ul = document.createElement('ul');
        ul.style.listStyle = 'none';
        ul.style.padding = '0';

        function liItem(r, depth) {
            const li = document.createElement('li');
            li.style.padding = '10px 0';
            li.style.borderTop = '1px solid #eee';
            if (depth === 1) li.style.marginLeft = '24px';

            li.innerHTML = `
        <div style="display:flex;gap:8px;align-items:center;">
          <strong>${h(r.authorName ?? '익명')}</strong>
          <span style="color:#888;font-size:12px;">${dateText(r.createdAt)}</span>
        </div>
        <div style="margin:6px 0 8px 0;">${h(r.content)}</div>
        <div style="display:flex;gap:8px;">
          <button data-edit="${r.id}" style="font-size:12px;">수정</button>
          <button data-del="${r.id}"  style="font-size:12px;">삭제</button>
          <button data-reply="${r.id}" style="font-size:12px;">답글</button>
        </div>
      `;

            li.addEventListener('click', async (ev) => {
                const t = ev.target;
                if (t.dataset.edit) {
                    const newText = prompt('내용 수정', r.content);
                    if (newText == null) return;
                    await fetch(`/api/comments/${r.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ content: newText })
                    }).then(x => {
                        if (x.status === 401) { alert('로그인이 필요합니다.'); location.href = '/user/login'; return; }
                        if (!x.ok) throw new Error('수정 실패');
                        load();
                    }).catch(() => alert('수정에 실패했습니다.'));
                }
                if (t.dataset.del) {
                    if (!confirm('삭제하시겠습니까?')) return;
                    await fetch(`/api/comments/${r.id}`, { method: 'DELETE' })
                        .then(x => {
                            if (x.status === 401) { alert('로그인이 필요합니다.'); location.href = '/user/login'; return; }
                            if (!x.ok) throw new Error('삭제 실패');
                            load();
                        }).catch(() => alert('삭제에 실패했습니다.'));
                }
                if (t.dataset.reply) {
                    const text = prompt('답글 입력');
                    if (!text) return;
                    await fetch('/api/comments', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                        body: JSON.stringify({ postId, content: text, parentCommentId: r.id })
                    }).then(x => {
                        if (x.status === 401) { alert('로그인이 필요합니다.'); location.href = '/user/login'; return; }
                        if (!x.ok) throw new Error('등록 실패');
                        load();
                    }).catch(() => alert('답글 등록에 실패했습니다.'));
                }
            });

            return li;
        }

        roots.forEach(root => {
            ul.appendChild(liItem(root, 0));
            children.filter(ch => ch.parentCommentId === root.id)
                .forEach(ch => ul.appendChild(liItem(ch, 1)));
        });

        listEl.innerHTML = '';
        listEl.appendChild(ul);
    }

    // 최초 로드
    load();
})();