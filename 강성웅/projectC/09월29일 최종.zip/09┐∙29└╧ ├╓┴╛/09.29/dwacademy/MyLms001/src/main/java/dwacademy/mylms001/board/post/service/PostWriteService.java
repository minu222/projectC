package dwacademy.mylms001.board.post.service;

public interface PostWriteService {
    Long write(String title, String content, String category, Long userId);
}
