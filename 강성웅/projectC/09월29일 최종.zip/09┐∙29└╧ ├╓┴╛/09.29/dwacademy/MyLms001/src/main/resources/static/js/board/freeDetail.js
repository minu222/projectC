// src/main/resources/static/js/freeDetail.js

function qs(sel, root = document) { return root.querySelector(sel); }
function qsa(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

function getPostId() {
    // 1) hidden input 우선, 2) URL 폴백
    const hid = qs('#postId')?.value;
    if (hid) return parseInt(hid, 10);
    const m = location.pathname.match(/\/board\/free\/(\d+)/);
    return m ? parseInt(m[1], 10) : null;
}

function roleLabel(r) {
    const v = (r || '').toLowerCase();
    if (v === 'admin') return '관리자';
    if (v === 'instructor') return '강사';
    return '학생';
}

function escapeHtml(s) {
    return (s || '').replace(/[&<>"']/g, (m) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[m]));
}

/** -------- 댓글 목록 렌더링 -------- */
async function fetchComments() {
    const postId = getPostId();
    if (!postId) return;
    try {
        const res = await fetch(`/api/posts/${postId}/comments`, { headers: { 'Accept': 'application/json' } });
        if (!res.ok) return;
        const list = await res.json();
        renderComments(list);
    } catch (e) {
        console.error(e);
    }
}

function renderComments(list) {
    const wrap = qs('#comment-list');
    if (!wrap) return;
    wrap.innerHTML = '';

    if (!list || list.length === 0) {
        wrap.innerHTML = `<div style="color:#666;">첫 댓글을 남겨보세요.</div>`;
        return;
    }

    // 간단히 루트/대댓글 1단만 표시
    const byParent = new Map();
    const roots = [];
    list.forEach(c => {
        if (c.parentCommentId == null) roots.push(c);
        else {
            if (!byParent.has(c.parentCommentId)) byParent.set(c.parentCommentId, []);
            byParent.get(c.parentCommentId).push(c);
        }
    });

    const frag = document.createDocumentFragment();
    roots.forEach(root => {
        frag.appendChild(renderItem(root, 0));
        (byParent.get(root.id) || []).forEach(child => frag.appendChild(renderItem(child, 1)));
    });
    wrap.appendChild(frag);
}

function renderItem(c, depth) {
    const el = document.createElement('div');
    el.className = 'comment-item';
    el.dataset.id = c.id;
    el.style.cssText = `border:1px solid #eee;border-radius:6px;padding:10px;${depth ? 'margin-left:24px;' : ''}`;

    // 날짜 문자열 (ISO → 보기 좋게)
    const when = (c.createdAt || '').toString().replace('T', ' ').slice(0, 16);

    el.innerHTML = `
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:4px;">
      <strong>${escapeHtml(c.authorName || 'user#' + c.userId)}</strong>
      <span style="color:#ff7f00;">${roleLabel(c.authorRole)}</span>
      <span style="color:#888;font-size:12px;">${escapeHtml(when)}</span>
    </div>
    <div class="content" style="white-space:pre-wrap;">${escapeHtml(c.content)}</div>
    <div class="actions" style="margin-top:6px;display:flex;gap:6px;">
      ${depth === 0 ? `<button class="btn-reply" data-id="${c.id}" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;background:#fff;">답글</button>` : ''}
      <button class="btn-edit" data-id="${c.id}" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;background:#fff;">수정</button>
      <button class="btn-del" data-id="${c.id}" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;background:#fff;">삭제</button>
    </div>
  `;
    return el;
}

/** -------- 댓글 등록 -------- */
async function addComment() {
    const postId = getPostId();
    const input = qs('#comment-input');
    const content = (input?.value || '').trim();

    // fetch 경로를 못 만들면 기본 폼 제출로 폴백하도록 반환
    const form = qs('#comment-form');
    const hasAction = !!form?.action;
    if (!postId && !hasAction) return true; // 기본 제출 허용

    // 여기서부터는 fetch 사용
    if (!content) { alert('댓글 내용을 입력하세요.'); return false; }

    const res = await fetch(`/api/posts/${postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
    });

    if (res.status === 401) {
        location.href = '/login?redirect=' + encodeURIComponent(location.pathname);
        return false;
    }
    if (!res.ok) { alert('댓글 등록 실패'); return false; }

    input.value = '';
    // 목록 다시 로드 (가장 단순하게는 새로고침)
    await fetchComments();
    return false;
}

/** -------- 대댓글/수정/삭제 이벤트 위임 -------- */
document.addEventListener('click', async (e) => {
    const t = e.target;
    if (!(t instanceof HTMLElement)) return;

    const postId = getPostId();

    if (t.classList.contains('btn-del')) {
        const id = t.dataset.id;
        if (!confirm('삭제하시겠습니까?')) return;
        const res = await fetch(`/api/posts/${postId}/comments/${id}`, { method: 'DELETE' });
        if (res.status === 401) return location.href = '/login?redirect=' + encodeURIComponent(location.pathname);
        if (!res.ok) return alert('삭제 실패');
        fetchComments();
    } else if (t.classList.contains('btn-edit')) {
        const id = t.dataset.id;
        const box = t.closest('.comment-item');
        const before = box?.querySelector('.content')?.textContent || '';
        const next = prompt('수정할 내용을 입력하세요.', before);
        if (next == null) return;
        const res = await fetch(`/api/comments/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: next })
        });
        if (res.status === 401) return location.href = '/login?redirect=' + encodeURIComponent(location.pathname);
        if (!res.ok) return alert('수정 실패');
        fetchComments();
    } else if (t.classList.contains('btn-reply')) {
        const id = t.dataset.id;
        const item = t.closest('.comment-item');
        if (item.querySelector('.reply-form')) { item.querySelector('.reply-form').remove(); return; }
        const rf = document.createElement('div');
        rf.className = 'reply-form';
        rf.style.cssText = 'margin-top:8px;padding:8px;border:1px dashed #ddd;border-radius:6px;';
        rf.innerHTML = `
      <textarea rows="2" placeholder="답글을 입력하세요" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:6px;"></textarea>
      <div style="margin-top:6px;display:flex;gap:6px;">
        <button class="btn-reply-submit" data-parent-id="${id}" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;background:#fff;">등록</button>
        <button class="btn-reply-cancel" style="padding:4px 8px;border:1px solid #ddd;border-radius:4px;background:#fff;">취소</button>
      </div>
    `;
        item.appendChild(rf);
    } else if (t.classList.contains('btn-reply-cancel')) {
        t.closest('.reply-form')?.remove();
    } else if (t.classList.contains('btn-reply-submit')) {
        const rf = t.closest('.reply-form');
        const ta = rf.querySelector('textarea');
        const content = (ta.value || '').trim();
        if (!content) return alert('내용을 입력하세요.');
        const parentId = Number(t.dataset.parentId);
        const res = await fetch(`/api/posts/${postId}/comments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content, parentId })
        });
        if (res.status === 401) return location.href = '/login?redirect=' + encodeURIComponent(location.pathname);
        if (!res.ok) return alert('등록 실패');
        fetchComments();
    }
});

/** -------- 초기화 -------- */
document.addEventListener('DOMContentLoaded', () => {
    // 폼 submit 핸들러: fetch로 시도, 실패하면 기본 제출 폴백
    const form = qs('#comment-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            const allowDefault = await addComment(); // true 면 기본 제출 허용
            if (!allowDefault) e.preventDefault();
        });

        // form.action 비어 있으면 URL에서 postId로 자동 세팅 (HTML에서도 한 번 세팅하지만 이중 안전망)
        if (!form.action) {
            const pid = getPostId();
            if (pid) form.action = '/api/posts/' + pid + '/comments';
        }
    }

    fetchComments();
});
