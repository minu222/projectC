package dwacademy.mylms001.controller;

import dwacademy.mylms001.board.BoardType;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@RequestMapping("/board")
public class BoardController {

    private final JdbcTemplate jdbcTemplate;

    /* ---------------- 공통 유틸 ---------------- */

    /** layout.html 은 ~{${bodyFragment}} 로 삽입하므로
     *  bodyFragment 에는 "board/경로 :: content" 를 그대로 넣는다.
     */
    private String setupBoardModel(Model model, String fragment, String title) {
        model.addAttribute("bodyFragment", fragment); // 예: "board/qnaBoard :: content"
        model.addAttribute("title", title);
        model.addAttribute("showSidebar", true);
        model.addAttribute("userRole", "guest");
        model.addAttribute("activeCategory", "board");
        return "layout";
    }

    private void setTypeSlug(Model model, BoardType bt) { model.addAttribute("typeSlug", bt.slug()); }

    private BoardType safeType(String type) {
        try { return BoardType.from(type); }
        catch (IllegalArgumentException e) { throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown board type: " + type); }
    }

    private String toBoardTitle(BoardType bt) {
        return switch (bt) {
            case NOTICE -> "공지사항";
            case FAQ -> "FAQ";
            case FREE -> "자유게시판";
            case QNA -> "문의게시판";
            case TEACHER_REVIEW -> "강사 리뷰";
            case COURSE_REVIEW-> "강의 리뷰";
        };
    }

    /* ---------------- 공통 조회 로직 (RowMapper 단일) ---------------- */

    /**
     * posts 테이블에서 카테고리별 목록을 조회한다.
     * - categoryUpper: 'NOTICE' / 'FAQ' / 'FREE' / 'QNA' / 'COURSE_REVIEW' / 'TEACHER_REVIEW'
     * - q: 검색어(옵션). 제목/내용 LIKE 검색
     * 반환 컬럼: id, title, authorName, createdAt(LocalDateTime)
     */
    private List<Map<String, Object>> queryPostsByCategory(String categoryUpper, String q) {
        final boolean hasQ = (q != null && !q.isBlank());

        final String baseSql = """
            SELECT  p.post_id      AS id,
                    p.title        AS title,
                    COALESCE(u.name, '익명') AS authorName,
                    p.created_at   AS createdAt
              FROM  project.posts p
        LEFT JOIN  project.users u ON u.user_id = p.user_id
             WHERE  UPPER(p.category) = ?
               AND  p.is_deleted = 0
        """;
        final String whereQ = hasQ ? " AND (p.title LIKE ? OR p.content LIKE ?) " : " ";
        final String order  = " ORDER BY p.post_id DESC LIMIT 200";
        final String sql    = baseSql + whereQ + order;

        Object[] args = hasQ
                ? new Object[]{ categoryUpper, "%" + q + "%", "%" + q + "%" }
                : new Object[]{ categoryUpper };

        // ✅ 모호성 없는 오버로드: (sql, args, RowMapper)
        return jdbcTemplate.query(sql, args, (rs, rowNum) -> {
            var m = new HashMap<String, Object>();
            m.put("id", rs.getLong("id"));
            m.put("title", rs.getString("title"));
            m.put("authorName", rs.getString("authorName"));
            Timestamp ts = rs.getTimestamp("createdAt");
            m.put("createdAt", ts != null ? ts.toLocalDateTime() : null);
            m.putIfAbsent("role", "USER");
            return m;
        });
    }

    /* ---------------- 목록 ---------------- */

    @GetMapping
    public String boardRoot() { return "redirect:/board/notice"; }

    @GetMapping("/notice")
    public String noticeBoard(Model model, @RequestParam(required = false) String q) {
        setTypeSlug(model, BoardType.NOTICE);
        var posts = queryPostsByCategory("NOTICE", q);
        model.addAttribute("posts", posts);
        return setupBoardModel(model, "board/noticeBoard :: content", toBoardTitle(BoardType.NOTICE));
    }

    @GetMapping("/faq")
    public String faqBoard(Model model, @RequestParam(required = false) String q) {
        setTypeSlug(model, BoardType.FAQ);
        var posts = queryPostsByCategory("FAQ", q);
        model.addAttribute("posts", posts);
        return setupBoardModel(model, "board/faqBoard :: content", toBoardTitle(BoardType.FAQ));
    }

    @GetMapping("/courseReview")
    public String courseReviewBoard(Model model, @RequestParam(required = false) String q) {
        setTypeSlug(model, BoardType.COURSE_REVIEW);
        var posts = queryPostsByCategory("COURSE_REVIEW", q);
        model.addAttribute("posts", posts);
        return setupBoardModel(model, "board/courseReview :: content", toBoardTitle(BoardType.COURSE_REVIEW));
    }

    /** 자유게시판 목록 */
    @GetMapping("/free")
    public String freeBoard(Model model, @RequestParam(required = false) String q) {
        setTypeSlug(model, BoardType.FREE);
        var posts = queryPostsByCategory("FREE", q);
        model.addAttribute("posts", posts);
        return setupBoardModel(model, "board/freeBoard :: content", toBoardTitle(BoardType.FREE));
    }

    /** 문의게시판 목록 */
    @GetMapping("/qna")
    public String qnaBoard(Model model,
                           @RequestParam(required = false) String q,
                           @RequestParam(required = false) String f) {
        setTypeSlug(model, BoardType.QNA);
        var posts = queryPostsByCategory("QNA", q);

        // QNA: 마스킹/보조필드 부여
        for (Map<String, Object> row : posts) {
            String name = (String) row.getOrDefault("authorName", "익명");
            row.put("authorMasked", maskName(name));
            row.putIfAbsent("draft", Boolean.FALSE);
            row.putIfAbsent("secret", Boolean.FALSE);
            row.putIfAbsent("answerStatus", "-");
        }

        model.addAttribute("posts", posts);
        return setupBoardModel(model, "board/qnaBoard :: content", toBoardTitle(BoardType.QNA));
    }

    /* ---------------- 글쓰기 ---------------- */

    @GetMapping("/{type}/write")
    public String writeForm(@PathVariable String type, Model model) {
        final BoardType bt = safeType(type);
        setTypeSlug(model, bt);
        return setupBoardModel(model, "board/write :: content", toBoardTitle(bt) + " 글쓰기");
    }

    @PostMapping("/{type}/write")
    public String writeSubmit(@PathVariable String type,
                              @RequestParam String title,
                              @RequestParam String content,
                              HttpServletRequest req) {
        final BoardType bt = safeType(type);
        final String category = switch (bt) {
            case QNA -> "QNA";
            case FREE -> "FREE";
            case NOTICE -> "NOTICE";
            case FAQ -> "FAQ";
            case COURSE_REVIEW -> "COURSE_REVIEW";
            case TEACHER_REVIEW -> "TEACHER_REVIEW";
        };

        final Long userId = getLoginUserId(req);
        if (userId == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "로그인이 필요합니다.");

        final String sql = """
            INSERT INTO project.posts
                (user_id, title, content, category, is_deleted, created_at, updated_at)
            VALUES (?, ?, ?, ?, 0, NOW(), NOW())
        """;
        KeyHolder kh = new GeneratedKeyHolder();
        jdbcTemplate.update(con -> {
            var ps = con.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, userId);
            ps.setString(2, title);
            ps.setString(3, content);
            ps.setString(4, category);
            return ps;
        }, kh);

        Long newId = (kh.getKey() != null) ? kh.getKey().longValue() : null;
        return (newId != null) ? "redirect:/board/" + bt.slug() + "/" + newId
                : "redirect:/board/" + bt.slug();
    }

    /* ---------------- 상세(제너릭 제외 규칙) ---------------- */

    // QNA, FREE는 전용 컨트롤러가 처리하도록 '제외' 정규식만 둡니다.
    @GetMapping("/{type:^(?!qna$|free$).+}/{id:\\d+}")
    public String genericDetail(@PathVariable String type, @PathVariable Long id) {
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "상세 페이지가 없습니다.");
    }

    /* ---------------- helpers ---------------- */

    private Long getLoginUserId(HttpServletRequest req) {
        var s = req.getSession(false);
        if (s == null) return null;

        Object o = s.getAttribute("loginUser");
        if (o instanceof dwacademy.mylms001.entity.User u) {
            try { return Long.valueOf(u.getUser_id()); } catch (Exception ignored) {}
        }
        Object v = s.getAttribute("userId");
        if (v instanceof Number n) return n.longValue();
        try { return (v == null) ? null : Long.parseLong(v.toString()); } catch (Exception e) { return null; }
    }

    private String maskName(String name) {
        if (name == null || name.isBlank()) return "익명";
        String n = name.trim();
        if (n.length() <= 1) return n;
        if (n.length() == 2) return n.charAt(0) + "*";
        return n.charAt(0) + "*".repeat(n.length() - 2) + n.charAt(n.length() - 1);
    }
}
