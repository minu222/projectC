package dwacademy.mylms001.repository;

public class MyPostsRepository {
}
