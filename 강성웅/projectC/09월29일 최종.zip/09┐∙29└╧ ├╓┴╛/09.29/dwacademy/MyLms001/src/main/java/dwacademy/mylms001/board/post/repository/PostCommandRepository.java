package dwacademy.mylms001.board.post.repository;

public interface PostCommandRepository {
    Long insert(String title, String content, String category, Long userId);
}
