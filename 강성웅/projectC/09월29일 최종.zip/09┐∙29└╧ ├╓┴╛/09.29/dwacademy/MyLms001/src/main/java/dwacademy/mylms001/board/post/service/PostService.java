package dwacademy.mylms001.board.post.service;

import dwacademy.mylms001.board.post.domain.Post;
import dwacademy.mylms001.common.page.PageResponse;

public interface PostService {
    PageResponse<Post> list(String category, String q, int page, int size);
    Post get(Long id);
}
