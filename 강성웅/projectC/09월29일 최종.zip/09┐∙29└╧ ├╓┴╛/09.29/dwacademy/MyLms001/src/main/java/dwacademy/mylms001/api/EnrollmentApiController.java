package dwacademy.mylms001.api;

import dwacademy.mylms001.entity.User;
import dwacademy.mylms001.repository.EnrollmentRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentApiController {
    private final EnrollmentRepository repo;
    public EnrollmentApiController(EnrollmentRepository repo){ this.repo = repo; }

    @GetMapping("/my")
    public ResponseEntity<?> myEnrollments(HttpSession session){
        User login = (User) session.getAttribute("loginUser");
        if (login == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(java.util.Map.of("ok", false, "message", "로그인이 필요합니다."));
        return ResponseEntity.ok(repo.listByStudent(login.getUser_id()));
    }
}
