// src/main/resources/static/js/paymentModal.js
// 결제 모달 제어 스크립트 (모달 열기/닫기, 입력 마스킹, 유효성 검사)

(function () {
    /* ---------- helpers ---------- */
    function formatWon(v) {
        const n = typeof v === 'number' ? v : Number(v) || 0;
        return n.toLocaleString('ko-KR') + '원';
    }

    function csrfHeaders() {
        const tokenEl = document.querySelector('meta[name="_csrf"]');
        const headerEl = document.querySelector('meta[name="_csrf_header"]');
        const token = tokenEl ? tokenEl.getAttribute('content') : null;
        const headerName = headerEl ? headerEl.getAttribute('content') : null;
        return token && headerName ? { [headerName]: token } : {};
    }

    const $ = (id) => document.getElementById(id);
    const getModal = () => $('paymentModal');

    function isModalOpen() {
        const modal = getModal();
        if (!modal) return false;
        const inline = modal.style.display;
        return inline ? inline !== 'none' : window.getComputedStyle(modal).display !== 'none';
    }

    function hideAllPaymentForms() {
        document.querySelectorAll('.payment-form').forEach((f) => {
            f.style.display = 'none';
        });
    }

    // 입력 마스킹 util
    const onlyDigits = (s) => (s || '').replace(/\D/g, '');
    function maskGroups(digits, groups) {
        const out = [];
        let i = 0;
        for (const g of groups) {
            if (i >= digits.length) break;
            out.push(digits.slice(i, i + g));
            i += g;
        }
        return out.filter(Boolean).join('-');
    }

    /* ---------- input masking (placeholder와 동일한 형태로 보이도록) ---------- */
    document.addEventListener('input', (e) => {
        const t = e.target;
        if (!(t instanceof HTMLInputElement)) return;

        if (t.id === 'cardNumber') {
            const d = onlyDigits(t.value).slice(0, 16);   // 16자리까지만
            t.value = maskGroups(d, [4, 4, 4, 4]);        // 0000-0000-0000-0000
        } else if (t.id === 'cardExpiry') {
            const d = onlyDigits(t.value).slice(0, 4);    // MMYY
            const mm = d.slice(0, 2);
            const yy = d.slice(2, 4);
            t.value = mm + (d.length > 2 ? '/' + yy : '');
        } else if (t.id === 'cardCvc') {
            t.value = onlyDigits(t.value).slice(0, 3);
        } else if (t.id === 'bankAccount') {
            const d = onlyDigits(t.value).slice(0, 11);   // 3+4+4 = 11자리
            t.value = maskGroups(d, [3, 4, 4]);           // 000-0000-0000
        }
    });

    /* ---------- 노출 API ---------- */

    // 결제수단 선택 시 해당 폼만 표시
    window.showPaymentForm = function () {
        hideAllPaymentForms();
        const pm = $('paymentMethod');
        const method = pm ? pm.value : '';
        if (!method) return;

        const formEl = $(method + 'Form');
        if (formEl) formEl.style.display = 'block';
    };

    /**
     * 모달 열기
     * @param {string} courseName
     * @param {number} price
     * @param {number} qty
     * @param {string} imgUrl
     * @param {string} instructor
     * @param {string} desc
     * @param {number} courseId
     */
    window.goToPayment = function (
        courseName,
        price,
        qty = 1,
        imgUrl,
        instructor,
        desc,
        courseId
    ) {
        const modal = getModal();
        if (!modal) return;

        // 레이아웃 간섭 방지를 위해 body 직속으로 이동
        if (modal.parentElement !== document.body) {
            document.body.appendChild(modal);
        }

        // 필드 세팅
        const setText = (id, text) => { const el = $(id); if (el) el.textContent = text; };
        setText('modalCourseName', '결제 - ' + (courseName || ''));
        setText('modalCourseNameDetail', courseName || '');
        setText('modalPrice', formatWon(price || 0));
        setText('modalQty', String(qty || 1));
        setText('modalTotal', formatWon((price || 0) * (qty || 1)));

        const imgEl = $('modalImg');
        if (imgUrl && imgEl) imgEl.src = imgUrl;

        const instEl = $('modalInstructor');
        if (instructor && instEl) instEl.textContent = '강사: ' + instructor;

        const descEl = $('modalDesc');
        if (desc && descEl) descEl.textContent = desc;

        const hid = $('modalCourseId');
        if (hid) hid.value = courseId || '';

        // 열기
        document.body.classList.add('modal-open'); // CSS: body.modal-open { overflow:hidden; }
        modal.style.display = 'flex';
    };

    // 모달 닫기 (X/배경/ESC 공통)
    window.closeModal = function (el) {
        const modal = el ? el.closest('#paymentModal') : getModal();
        if (!modal) return;

        modal.style.display = 'none';
        document.body.classList.remove('modal-open');

        // 상태 리셋(현재 모달 내부만)
        const pm = modal.querySelector('#paymentMethod');
        if (pm) pm.value = '';
        modal.querySelectorAll('.payment-form').forEach((f) => (f.style.display = 'none'));
    };

    // 결제 확인 → 장바구니 추가 (유효성 검사를 placeholder 패턴과 동일하게)
    window.confirmPayment = async function () {
        // 현재 보이는 결제 폼의 필드 validate
        const pmSel = $('paymentMethod');
        const method = pmSel ? pmSel.value : '';
        if (method) {
            const form = $(method + 'Form');
            if (form) {
                const fields = form.querySelectorAll('input, select');
                for (const f of fields) {
                    if (!f.checkValidity()) {
                        f.reportValidity();
                        return;
                    }
                }
            }
        }

        // 약관 체크
        const agree1El = $('agreeTerms1');
        const agree2El = $('agreeTerms2');
        const agree1 = !!(agree1El && agree1El.checked);
        const agree2 = !!(agree2El && agree2El.checked);
        if (!agree1 || !agree2) {
            alert('약관에 모두 동의해야 결제할 수 있습니다.');
            return;
        }

        // 코스 ID 확인
        const cidEl = $('modalCourseId');
        const courseId = cidEl ? Number(cidEl.value) : 0;
        if (!courseId) {
            alert('강의 정보를 찾을 수 없습니다.');
            return;
        }

        try {
            const res = await fetch('/api/cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    ...csrfHeaders(),
                },
                body: JSON.stringify({ courseId }),
            });

            const data = await res.json().catch(() => ({}));
            if (res.status === 401) throw new Error('로그인이 필요합니다.');
            if (res.status === 409) throw new Error(data.message || '이미 장바구니에 담긴 강의입니다.');
            if (!res.ok) throw new Error(data.message || '장바구니 추가에 실패했습니다.');

            alert('결제가 완료되었습니다! 장바구니에 담겼습니다.');
            window.closeModal();
        } catch (e) {
            alert(e.message || '오류가 발생했습니다.');
        }
    };

    /* ---------- 전역 이벤트: 오버레이 클릭 / ESC ---------- */
    document.addEventListener('click', (e) => {
        const modal = getModal();
        if (!modal || !isModalOpen()) return;
        if (e.target === modal) {
            window.closeModal(modal);
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && isModalOpen()) {
            window.closeModal();
        }
    });
})();
