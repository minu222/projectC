// src/main/resources/static/js/courseLecture.js
// DB에서 강의 목록을 가져와 탭(개인강의/다수강의/VOD)별로 렌더링
// 서버 API는 GET /api/courses?status=published&category=VOD&q=검색어 형태를 가정
// (다른 경로를 쓰신다면 아래 API_URL만 바꿔주세요)

(function () {
    'use strict';

    /** ====================== 설정 ====================== */
    const API_URL = '/api/courses'; // 예: /api/public/courses 로 쓰면 여기만 교체
    const LIST_ITEMS = 5;
    const CARD_ITEMS = 12;

    // 탭 → DB 카테고리 매핑
    const TAB_TO_CATEGORY = {
        personal: '개인강의',
        multi: '다수강의',
        vod: 'VOD',
    };

    // DOM
    const $id = (id) => document.getElementById(id);
    const listSection = $id('listSection');
    const cardSection = $id('cardSection');
    const searchInput = $id('searchInput');
    const sortFilter = $id('sortFilter');

    let currentTab = 'personal';
    let lastFetched = []; // 서버에서 받은 원본
    let fetchSeq = 0; // 오래된 응답 무시용

    /** ====================== 유틸 ====================== */
    function escapeHtml(s) {
        return String(s ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');
    }

    function formatCurrency(v) {
        if (v === null || v === undefined) return '';
        const num = typeof v === 'number' ? v : Number(String(v).replace(/[^\d.-]/g, ''));
        if (!isFinite(num)) return '';
        return num.toLocaleString('ko-KR');
    }

    function buildImg(course) {
        return (
            course.image_url ||
            `https://picsum.photos/300/140?random=${course.course_id || Math.floor(Math.random() * 10000)}`
        );
    }

    function buildPeriod(course) {
        const left = (course.created_at || '').toString().slice(0, 10);
        const right = (course.expiry_date || '').toString().slice(0, 10);
        if (left && right) return `${left} ~ ${right}`;
        return right || left || '';
    }

    function popularityScore(c) {
        const students = Number(c.student_count ?? 0);
        const rating = Number(c.avg_rating ?? 0);
        return students * 1 + rating * 10;
    }

    function showToast(msg) {
        try {
            const t = document.createElement('div');
            t.textContent = msg;
            t.style.cssText =
                'position:fixed;left:50%;top:70px;transform:translateX(-50%);' +
                'background:#333;color:#fff;padding:10px 14px;border-radius:8px;' +
                'z-index:9999;opacity:.95';
            document.body.appendChild(t);
            setTimeout(() => t.remove(), 1600);
        } catch {
            alert(msg);
        }
    }

    /** ====================== 서버 통신 ====================== */
    async function fetchCoursesFromDB({ tab = currentTab, q = searchInput?.value || '' } = {}) {
        const category = TAB_TO_CATEGORY[tab] || 'VOD';
        const params = new URLSearchParams();
        params.set('status', 'published');
        params.set('category', category);
        if (q && q.trim()) params.set('q', q.trim());

        const url = `${API_URL}?${params}`;
        const mySeq = ++fetchSeq;

        // 로딩 상태 표시
        setLoading(true);
        try {
            const res = await fetch(url, { method: 'GET', headers: { Accept: 'application/json' } });
            // 뒤늦은 응답이면 무시
            if (mySeq !== fetchSeq) return [];

            if (res.status === 401) {
                setLoading(false);
                throw new Error('로그인이 필요합니다.');
            }
            if (!res.ok) {
                const txt = await res.text().catch(() => '');
                throw new Error(txt || '목록 조회 실패');
            }

            const data = await res.json();
            if (!Array.isArray(data)) {
                if (data && data.ok === false && data.message) throw new Error(data.message);
                return [];
            }
            return data;
        } catch (err) {
            console.error('[courseLecture] fetch error:', err);
            showToast(err.message || '목록을 불러오지 못했습니다.');
            return [];
        } finally {
            if (mySeq === fetchSeq) setLoading(false);
        }
    }

    function setLoading(isLoading) {
        if (!listSection || !cardSection) return;
        if (isLoading) {
            listSection.innerHTML = `<div style="padding:18px;color:#666;">불러오는 중...</div>`;
            cardSection.innerHTML = `<div style="padding:18px;color:#666;">불러오는 중...</div>`;
        }
    }

    /** ====================== 렌더 ====================== */
    function render() {
        if (!listSection || !cardSection) return;

        const q = (searchInput?.value || '').toLowerCase();
        const sort = sortFilter?.value || '';

        // 검색 필터
        let filtered = lastFetched.filter((c) => {
            const title = (c.title || '').toLowerCase();
            const desc = (c.description || '').toLowerCase();
            const inst = (c.instructor_name || '').toLowerCase();
            return !q || title.includes(q) || desc.includes(q) || inst.includes(q);
        });

        // 정렬
        if (sort === 'latest') {
            filtered.sort(
                (a, b) =>
                    new Date(b.updated_at || b.created_at || 0) - new Date(a.updated_at || a.created_at || 0)
            );
        } else if (sort === 'oldest') {
            filtered.sort(
                (a, b) =>
                    new Date(a.updated_at || a.created_at || 0) - new Date(b.updated_at || b.created_at || 0)
            );
        } else if (sort === 'popular') {
            filtered.sort((a, b) => popularityScore(b) - popularityScore(a));
        }

        // ===== 리스트형 =====
        listSection.innerHTML = '';
        if (filtered.length === 0) {
            listSection.innerHTML = `<div style="padding:18px;color:#888;">표시할 강의가 없습니다.</div>`;
        } else {
            filtered.slice(0, LIST_ITEMS).forEach((c) => {
                const img = buildImg(c);
                const period = buildPeriod(c);
                const priceNum = c.is_free ? 0 : Number(c.price ?? 0) || 0; // ✅
                const price = c.is_free ? '무료' : c.price != null ? `${formatCurrency(c.price)}원` : '';
                const level = escapeHtml(c.level || '');

                const div = document.createElement('div');
                div.className = 'lecture'; // 카드 루트
                // 결제 모달용 데이터
                div.dataset.title = c.title || '';
                div.dataset.price = String(priceNum);
                div.dataset.img = img;
                div.dataset.instructor = c.instructor_name || '';
                div.dataset.desc = c.description || '';
                div.dataset.qty = '1';
                div.dataset.courseId = String(c.course_id || '');

                div.innerHTML = `
          <img src="${img}" alt="강의 이미지">
          <div class="lecture-content">
            <h3>${escapeHtml(c.title || '')}</h3>
            <p>${escapeHtml(c.description || '')}</p>
            <div class="info">
              ${c.instructor_name ? `강사: ${escapeHtml(c.instructor_name)} | ` : ''}${level ? `${level} | ` : ''}${period}${price ? ` | ${price}` : ''}
            </div>
            <button type="button" class="btn-buy">구매하기</button>
          </div>
        `;

                const link = c.link || `/course/detail/${c.course_id}`;
                // 구매 버튼 클릭 시 상세 이동 막기
                div.addEventListener('click', (ev) => {
                    if (ev.target.closest('.btn-buy')) return;
                    location.href = link;
                });

                listSection.appendChild(div);
            });
        }

        // ===== 카드형 =====
        cardSection.innerHTML = '';
        if (filtered.length === 0) {
            cardSection.innerHTML = `<div style="padding:18px;color:#888;">표시할 강의가 없습니다.</div>`;
        } else {
            filtered.slice(0, CARD_ITEMS).forEach((c) => {
                const img = buildImg(c);
                const priceNum = c.is_free ? 0 : Number(c.price ?? 0) || 0;
                const price = c.is_free ? '무료' : c.price != null ? `${formatCurrency(c.price)}원` : '';

                const div = document.createElement('div');
                div.className = 'card'; // 카드 루트
                // 결제 모달용 데이터
                div.dataset.title = c.title || '';
                div.dataset.price = String(priceNum);
                div.dataset.img = img;
                div.dataset.instructor = c.instructor_name || '';
                div.dataset.desc = c.description || '';
                div.dataset.qty = '1';
                div.dataset.courseId = String(c.course_id || '');

                div.innerHTML = `
          <img src="${img}" alt="강의 이미지">
          <div class="card-content">
            <h3>${escapeHtml(c.title || '')}</h3>
            <p>${escapeHtml(c.description || '')}</p>
            <div class="level">${c.instructor_name ? `강사: ${escapeHtml(c.instructor_name)}` : ''}</div>
            <button type="button" class="btn-buy">구매하기</button>
          </div>
        `;

                const link = c.link || `/course/detail/${c.course_id}`;
                // 구매 버튼 클릭 시 상세 이동 막기
                div.addEventListener('click', (ev) => {
                    if (ev.target.closest('.btn-buy')) return;
                    location.href = link;
                });

                cardSection.appendChild(div);
            });
        }
    }

    /** ====================== 탭/보기 전환 ====================== */
    async function changeTab(tab) {
        currentTab = tab;
        document.querySelectorAll('.tabs button').forEach((b) => b.classList.remove('active'));
        const btn = document.querySelector(`.tabs button[onclick="changeTab('${tab}')"]`);
        if (btn) btn.classList.add('active');

        lastFetched = await fetchCoursesFromDB({ tab, q: searchInput?.value || '' });
        render();
    }

    function showList() {
        const list = $id('listSection');
        const card = $id('cardSection');
        if (list && card) {
            list.style.display = 'flex';
            card.style.display = 'none';
        }
    }

    function showCard() {
        const list = $id('listSection');
        const card = $id('cardSection');
        if (list && card) {
            list.style.display = 'none';
            card.style.display = 'grid';
        }
    }

    // 전역 노출(HTML의 onclick 대비)
    window.changeTab = changeTab;
    window.showList = showList;
    window.showCard = showCard;

    /** ====================== 초기화 ====================== */
    async function init() {
        // 최초 탭 데이터 로드
        lastFetched = await fetchCoursesFromDB({ tab: currentTab, q: searchInput?.value || '' });
        render();

        // 검색/정렬 이벤트
        searchInput?.addEventListener(
            'input',
            debounce(async () => {
                lastFetched = await fetchCoursesFromDB({ tab: currentTab, q: searchInput.value });
                render();
            }, 250)
        );

        sortFilter?.addEventListener('change', render);
    }

    function debounce(fn, ms) {
        let t;
        return function (...args) {
            clearTimeout(t);
            t = setTimeout(() => fn.apply(this, args), ms);
        };
    }

    document.addEventListener('DOMContentLoaded', init);

    /** ====================== 구매 버튼 전역 위임: 모달 열기 ====================== */
    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.btn-buy');
        if (!btn) return;

        // 카드 루트에서 데이터 수집 (.lecture 또는 .card)
        const card = btn.closest('.lecture, .card');
        if (!card) return;

        const { title, price, img, instructor, desc, qty, courseId } = card.dataset;

        // 결제 모달 오픈 (paymentModal.js 필요)
        if (typeof window.goToPayment === 'function') {
            window.goToPayment(
                title,
                Number(price || 0),
                Number(qty || 1) || 1,
                img,
                instructor,
                desc,
                Number(courseId || 0)
            );
        } else {
            alert('결제 모듈이 아직 준비되지 않았습니다. paymentModal.js 로드를 확인해주세요.');
        }
    });
})();
