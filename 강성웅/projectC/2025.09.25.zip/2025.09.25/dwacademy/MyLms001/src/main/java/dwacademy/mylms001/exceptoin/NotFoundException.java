package dwacademy.mylms001.exceptoin;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg) { super(msg); }
}
