// src/main/resources/static/js/myclass/studentCourses.js
// cart에 담긴 항목을 "수강중(progress)"으로 간주하여 렌더
(function () {
    'use strict';

    /** ====== DOM ====== */
    const $id = (id) => document.getElementById(id);
    const courseGrid   = $id('courseGrid');
    const pagination   = $id('pagination');
    const filterSelect = $id('filter');
    const searchInput  = $id('searchInput');
    const searchBtn    = $id('searchBtn');

    /** ====== 상태 ====== */
    const PER_PAGE = 9;
    let currentPage = 1;
    let rawItems  = []; // 서버 원본(cart join)
    let viewItems = []; // 검색/필터 적용 후

    /** ====== 유틸 ====== */
    function escapeHtml(s) {
        return String(s ?? '')
            .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
            .replaceAll('"','&quot;').replaceAll("'","&#39;");
    }
    function fmtDateOnly(s) {
        if (!s) return '';
        const d = new Date(s);
        if (!isFinite(d)) return String(s).slice(0,10);
        const yy = d.getFullYear();
        const mm = String(d.getMonth()+1).padStart(2,'0');
        const dd = String(d.getDate()).padStart(2,'0');
        return `${yy}-${mm}-${dd}`;
    }
    function buildPeriod(created_at, expiry_date) {
        const left  = fmtDateOnly(created_at);
        const right = fmtDateOnly(expiry_date);
        if (left && right) return `${left} ~ ${right}`;
        return right || left || '';
    }
    function formatWon(v) {
        const n = Number(v ?? 0) || 0;
        return n.toLocaleString('ko-KR') + '원';
    }

    /** ====== 서버에서 cart 불러오기 ====== */
    async function loadFromCart() {
        if (courseGrid) {
            courseGrid.innerHTML = '<p style="padding:16px;color:#666;">불러오는 중...</p>';
        }
        try {
            const res = await fetch('/api/cart', { headers: { 'Accept': 'application/json' } });
            if (res.status === 401) throw new Error('로그인이 필요합니다.');
            if (!res.ok) throw new Error('목록 조회에 실패했습니다.');
            const data = await res.json();

            // cart + courses LEFT JOIN 결과를 화면 모델로 변환
            rawItems = Array.isArray(data) ? data.map(row => {
                const title    = row.title || '(제목 없음)';
                const teacher  = row.instructor_name || '';
                const period   = buildPeriod(row.created_at, row.expiry_date);
                const progress = 0; // 추적 전이면 0
                return {
                    id: row.course_id,
                    title,
                    teacher,
                    period,
                    score: 0,
                    progress,
                    status: 'progress',                 // ✅ cart = 수강중
                    priceText: row.is_free ? '무료' : formatWon(row.price),
                    purchaseDate: row.added_at || row.created_at, // cart 담긴 시각을 구매시각처럼 사용
                    lastAccess:  row.added_at || row.created_at,
                    image: row.image_url || `https://picsum.photos/300/150?random=${encodeURIComponent(row.course_id)}`
                };
            }) : [];

            applyAndRender();
        } catch (e) {
            if (courseGrid) {
                courseGrid.innerHTML = `<p style="padding:16px;color:#c00;">${escapeHtml(e.message || '오류가 발생했습니다.')}</p>`;
            }
            pagination && (pagination.innerHTML = '');
        }
    }

    /** ====== 필터/검색 ====== */
    function getFiltered() {
        let items = [...rawItems];

        // 검색(강의명/강사명)
        const keyword = (searchInput?.value || '').trim().toLowerCase();
        if (keyword) {
            items = items.filter(c =>
                c.title.toLowerCase().includes(keyword) ||
                (c.teacher || '').toLowerCase().includes(keyword)
            );
        }

        // 필터
        const filter = filterSelect?.value || 'all';
        if (filter === 'progress') {
            items = items.filter(c => c.status === 'progress');
        } else if (filter === 'completed') {
            items = items.filter(c => c.status === 'completed'); // 현재는 없음(추후 수료 연동)
        } else if (filter === 'purchase') {
            items.sort((a, b) => new Date(b.purchaseDate) - new Date(a.purchaseDate)); // 최신 구매순
        } else if (filter === 'recent') {
            items.sort((a, b) => new Date(b.lastAccess) - new Date(a.lastAccess));     // 최근 수강순
        }
        return items;
    }

    function applyAndRender() {
        viewItems = getFiltered();
        currentPage = 1;
        render();
    }

    /** ====== 렌더 ====== */
    function render() {
        renderCourses();
        renderPagination();
    }

    function renderCourses() {
        if (!courseGrid) return;
        courseGrid.innerHTML = '';

        const total = viewItems.length;
        if (total === 0) {
            courseGrid.innerHTML = '<p>표시할 강의가 없습니다.</p>';
            return;
        }

        const start = (currentPage - 1) * PER_PAGE;
        const pageCourses = viewItems.slice(start, start + PER_PAGE);

        pageCourses.forEach(c => {
            const card = document.createElement('div');
            card.className = 'course-card';
            card.innerHTML = `
        <img src="${escapeHtml(c.image)}" alt="강의 썸네일">
        <h3>${escapeHtml(c.title)}</h3>
        <p>${c.teacher ? `강사: ${escapeHtml(c.teacher)}` : ''}</p>
        <p>학습기간: ${escapeHtml(c.period)}</p>
        <p>시험: ${c.score} 점</p>
        <p>진도율: ${c.progress}%</p>
        <div class="actions">
          <!-- 팝업만 열기: data-link 넣지 않음 -->
          <button type="button"
                  class="btn-enter"
                  data-popup="lecture"
                  data-course-id="${encodeURIComponent(c.id)}">
            강의실 입장
          </button>
          <button type="button" data-link="/exam/start/${encodeURIComponent(c.id)}">시험보기</button>
          <button type="button" data-link="/review/course/${encodeURIComponent(c.id)}">강의후기 작성</button>
          <button type="button" data-link="/review/instructor/${encodeURIComponent(c.id)}">강사후기 작성</button>
        </div>
      `;
            courseGrid.appendChild(card);
        });
    }

    function renderPagination() {
        if (!pagination) return;
        const total = viewItems.length;
        const pages = Math.max(1, Math.ceil(total / PER_PAGE));
        pagination.innerHTML = '';

        for (let i = 1; i <= pages; i++) {
            const btn = document.createElement('button');
            btn.textContent = String(i);
            if (i === currentPage) btn.classList.add('active');
            btn.addEventListener('click', () => {
                currentPage = i;
                render();
            });
            pagination.appendChild(btn);
        }
    }

    /** ====== 팝업 유틸 & 전역 이벤트 ====== */

        // 같은 코스는 같은 창으로 재사용/포커스
    const _popupRefs = {};

    // ✅ 팝업 차단 시 현재 페이지로의 폴백 이동 없음 (알림만)
    function openCenteredPopup(url, name, w = 1100, h = 800) {
        const dualScreenLeft = window.screenLeft ?? window.screenX ?? 0;
        const dualScreenTop  = window.screenTop  ?? window.screenY ?? 0;

        const width  = window.outerWidth  ?? document.documentElement.clientWidth  ?? screen.width;
        const height = window.outerHeight ?? document.documentElement.clientHeight ?? screen.height;

        const left = dualScreenLeft + Math.max(0, (width - w) / 2);
        const top  = dualScreenTop  + Math.max(0, (height - h) / 2);

        const features = `popup=yes,noopener,noreferrer,resizable=yes,scrollbars=yes,width=${w},height=${h},left=${Math.round(left)},top=${Math.round(top)}`;

        // 이미 열린 팝업 있으면 포커스 & 주소 갱신
        if (_popupRefs[name] && !(_popupRefs[name].closed)) {
            _popupRefs[name].focus();
            _popupRefs[name].location.href = url;
            return _popupRefs[name];
        }

        const win = window.open(url, name, features);
        if (!win) {
            alert('브라우저에서 팝업이 차단되었습니다. 사이트의 팝업을 허용해 주세요.');
            return null;
        }
        _popupRefs[name] = win;
        return win;
    }

    // 공통 전역 클릭 위임
    document.addEventListener('click', (e) => {
        // 1) 강의실 팝업만 열기 (현재 페이지 유지)
        const enterBtn = e.target.closest('[data-popup="lecture"]');
        if (enterBtn) {
            e.preventDefault();
            e.stopPropagation(); // 카드 전체 클릭 등 다른 핸들러 차단
            const courseId = enterBtn.getAttribute('data-course-id');
            const url = `/myclass/lectureroom?courseId=${encodeURIComponent(courseId)}&popup=1`;
            const win = openCenteredPopup(url, `lectureRoom-${courseId}`, 1100, 800);
            if (win) { try { win.focus(); } catch (_) {} }
            return;
        }

        // 2) 일반 이동 버튼 (data-link가 있는 경우만)
        const go = e.target.closest('[data-link]');
        if (go) {
            const href = go.getAttribute('data-link');
            if (href) window.location.href = href;
        }
    });

    // 필터/검색 이벤트
    filterSelect && filterSelect.addEventListener('change', applyAndRender);
    searchBtn    && searchBtn.addEventListener('click', applyAndRender);
    searchInput  && searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') applyAndRender();
    });

    document.addEventListener('DOMContentLoaded', loadFromCart);
})();
