// src/main/java/dwacademy/mylms001/repository/CartRepository.java
package dwacademy.mylms001.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class CartRepository {
    private final JdbcTemplate jdbc;
    public CartRepository(JdbcTemplate jdbc){ this.jdbc = jdbc; }

    public boolean exists(int userId, long courseId) {
        Integer c = jdbc.queryForObject(
                "SELECT COUNT(*) FROM cart WHERE user_id=? AND course_id=?",
                Integer.class, userId, courseId
        );
        return c != null && c > 0;
    }

    public long insert(int userId, long courseId) {
        jdbc.update("INSERT INTO cart (user_id, course_id, added_at) VALUES (?, ?, NOW())",
                userId, courseId);
        // cart_id를 굳이 반환하지 않아도 되면 0L 반환해도 무방
        Long id = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        return id == null ? 0L : id;
    }

    /** user의 장바구니 항목을 courses 와 조인해서 반환. courseId가 있으면 필터링 */
    public List<Map<String, Object>> findItems(int userId, Long courseId) {
        StringBuilder sql = new StringBuilder(
                "SELECT ct.cart_id, ct.user_id, ct.course_id, ct.added_at,\n" +
                        "       c.title, c.description, c.category, c.price, c.is_free,\n" +
                        "       c.avg_rating, c.student_count, c.created_at, c.expiry_date\n" +
                        "  FROM cart ct JOIN courses c ON c.course_id = ct.course_id\n" +
                        " WHERE ct.user_id = ?"
        );
        List<Object> args = new ArrayList<>();
        args.add(userId);

        if (courseId != null) {
            sql.append(" AND ct.course_id = ?");
            args.add(courseId);
        }
        sql.append(" ORDER BY ct.added_at DESC");

        return jdbc.queryForList(sql.toString(), args.toArray());
    }
}
