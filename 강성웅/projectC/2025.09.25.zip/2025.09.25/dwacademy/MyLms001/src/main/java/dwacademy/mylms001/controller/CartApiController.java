// src/main/java/dwacademy/mylms001/controller/CartApiController.java
package dwacademy.mylms001.controller;

import dwacademy.mylms001.entity.User;
import dwacademy.mylms001.service.CartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartApiController {
    private final CartService service;
    public CartApiController(CartService service){ this.service = service; }

    public static class AddRequest {
        private Long courseId;
        public Long getCourseId() { return courseId; }
        public void setCourseId(Long courseId) { this.courseId = courseId; }
    }

    @PostMapping
    public ResponseEntity<?> add(@RequestBody AddRequest req, HttpSession session) {
        User login = (User) session.getAttribute("loginUser");
        if (login == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("ok", false, "message", "로그인이 필요합니다."));
        }
        if (req.getCourseId() == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("ok", false, "message", "courseId는 필수입니다."));
        }
        long id = service.addToCart(login.getUser_id(), req.getCourseId());
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("ok", true, "id", id));
    }

    /** ✅ 장바구니 목록 (옵션: courseId로 필터) */
    @GetMapping
    public ResponseEntity<?> list(@RequestParam(value = "courseId", required = false) Long courseId,
                                  HttpSession session) {
        User login = (User) session.getAttribute("loginUser");
        if (login == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("ok", false, "message", "로그인이 필요합니다."));
        }
        List<Map<String,Object>> items = service.list(login.getUser_id(), courseId);
        return ResponseEntity.ok(items);
    }

    @ExceptionHandler(CartService.AlreadyInCartException.class)
    public ResponseEntity<?> dup(CartService.AlreadyInCartException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("ok", false, "message", e.getMessage()));
    }
}
