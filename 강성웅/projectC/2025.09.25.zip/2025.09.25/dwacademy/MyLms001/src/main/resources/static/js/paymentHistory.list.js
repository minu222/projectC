// /js/paymentHistory.list.js
(function () {
    'use strict';

    const $ = (sel, p = document) => p.querySelector(sel);
    const tbody = $('#orderTable tbody');
    const pagination = $('#pagination');
    const searchInput = $('#searchInput');

    let allItems = [];   // 서버 원본
    let viewItems = [];  // 검색/필터 적용 결과
    let currentFilter = 'all';
    let page = 1;
    const PAGE_SIZE = 10;

    function getParam(name) {
        const u = new URL(window.location.href);
        return u.searchParams.get(name);
    }

    function formatWon(v) {
        const n = Number(v ?? 0) || 0;
        return n.toLocaleString('ko-KR') + '원';
    }

    function fmtDate(s) {
        if (!s) return '';
        const d = new Date(s);
        if (isNaN(d)) return String(s).slice(0, 19).replace('T', ' ');
        const yy = d.getFullYear();
        const mm = String(d.getMonth()+1).padStart(2,'0');
        const dd = String(d.getDate()).padStart(2,'0');
        const hh = String(d.getHours()).padStart(2,'0');
        const mi = String(d.getMinutes()).padStart(2,'0');
        return `${yy}-${mm}-${dd} ${hh}:${mi}`;
    }

    async function load() {
        // URL에 ?courseId=123 이 있으면 해당 course만, 없으면 내 장바구니 전체
        const courseId = getParam('courseId');
        const url = '/api/cart' + (courseId ? (`?courseId=${encodeURIComponent(courseId)}`) : '');
        tbody.innerHTML = `<tr><td colspan="9" style="padding:16px;color:#666;">불러오는 중...</td></tr>`;
        try {
            const res = await fetch(url, { headers: { 'Accept': 'application/json' }});
            if (res.status === 401) throw new Error('로그인이 필요합니다.');
            if (!res.ok) throw new Error('목록 조회 실패');
            allItems = await res.json();
            applyAndRender();
        } catch (e) {
            tbody.innerHTML = `<tr><td colspan="9" style="padding:16px;color:#c00;">${e.message || '오류가 발생했습니다.'}</td></tr>`;
        }
    }

    function applyAndRender() {
        const q = (searchInput?.value || '').trim().toLowerCase();

        viewItems = allItems.filter(row => {
            // 상태 필터(예시): cart에는 상태가 없으므로 completed 고정처럼 처리
            if (currentFilter === 'pending') return false;
            // 검색: 주문명(=강의명), 설명 기준
            const title = (row.title || '').toLowerCase();
            const desc  = (row.description || '').toLowerCase();
            return !q || title.includes(q) || desc.includes(q);
        });

        renderTable();
        renderPagination();
    }

    function renderTable() {
        if (!Array.isArray(viewItems) || viewItems.length === 0) {
            tbody.innerHTML = `<tr><td colspan="9" style="padding:16px;color:#888;">표시할 항목이 없습니다.</td></tr>`;
            return;
        }
        const start = (page - 1) * PAGE_SIZE;
        const slice = viewItems.slice(start, start + PAGE_SIZE);

        tbody.innerHTML = slice.map((row, idx) => {
            const no   = start + idx + 1;
            const name = row.title || '(제목 없음)';
            const unit = row.is_free ? '무료' : formatWon(row.price);
            const qty  = 1;
            const total= row.is_free ? '무료' : unit; // qty=1 기준
            const paid = '-'; // 결제수단(데모)
            const date = fmtDate(row.added_at || row.created_at);
            const stat = '주문완료'; // 장바구니에 담긴 시점 기준으로 표시
            const link = `/course/detail/${row.course_id}`;

            return `
        <tr class="order-row" data-course-id="${row.course_id}">
          <td>${no}</td>
          <td>${escapeHtml(name)}</td>
          <td>${unit}</td>
          <td>${qty}</td>
          <td>${total}</td>
          <td>${paid}</td>
          <td>${date}</td>
          <td>${stat}</td>
          <td><button type="button" class="btn-go" data-link="${link}">이동</button></td>
        </tr>
      `;
        }).join('');
    }

    function renderPagination() {
        const total = viewItems.length;
        const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        if (page > pages) page = pages;

        let html = '';
        for (let i=1;i<=pages;i++){
            html += `<button class="page-btn${i===page?' active':''}" data-p="${i}">${i}</button>`;
        }
        pagination.innerHTML = html || '';
    }

    function escapeHtml(s) {
        return String(s ?? '')
            .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
            .replaceAll('"','&quot;').replaceAll("'","&#39;");
    }

    // 이벤트 바인딩
    document.addEventListener('click', (e) => {
        const pbtn = e.target.closest('.page-btn');
        if (pbtn) {
            page = Number(pbtn.dataset.p) || 1;
            renderTable(); // 페이지만 변경
            return;
        }
        const gbtn = e.target.closest('.btn-go');
        if (gbtn) {
            const href = gbtn.getAttribute('data-link');
            if (href) window.location.href = href;
        }
        const fbtn = e.target.closest('.filter-buttons button');
        if (fbtn) {
            document.querySelectorAll('.filter-buttons button').forEach(b=>b.classList.remove('active'));
            fbtn.classList.add('active');
            currentFilter = fbtn.getAttribute('data-filter') || 'all';
            page = 1;
            applyAndRender();
        }
    });

    // 검색
    if (searchInput) {
        searchInput.addEventListener('input', () => { page = 1; applyAndRender(); });
    }

    // 템플릿에 남아있는 on* 핸들러 대응 (옵셔널)
    window.setFilter = function (btn) {
        if (!btn) return;
        document.querySelectorAll('.filter-buttons button').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        currentFilter = btn.getAttribute('data-filter') || 'all';
        page = 1;
        applyAndRender();
    };
    window.renderTable = function(){ applyAndRender(); };

    document.addEventListener('DOMContentLoaded', load);
})();
