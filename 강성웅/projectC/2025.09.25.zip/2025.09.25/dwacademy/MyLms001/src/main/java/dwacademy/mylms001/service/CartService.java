// src/main/java/dwacademy/mylms001/service/CartService.java
package dwacademy.mylms001.service;

import dwacademy.mylms001.repository.CartRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class CartService {
    private final CartRepository repo;
    public CartService(CartRepository repo){ this.repo = repo; }

    @Transactional
    public long addToCart(int userId, long courseId) {
        if (repo.exists(userId, courseId)) {
            throw new AlreadyInCartException("이미 장바구니에 담긴 강의입니다.");
        }
        return repo.insert(userId, courseId);
    }

    public List<Map<String,Object>> list(int userId, Long courseId) {
        return repo.findItems(userId, courseId);
    }

    public static class AlreadyInCartException extends RuntimeException {
        public AlreadyInCartException(String m){ super(m); }
    }
}
