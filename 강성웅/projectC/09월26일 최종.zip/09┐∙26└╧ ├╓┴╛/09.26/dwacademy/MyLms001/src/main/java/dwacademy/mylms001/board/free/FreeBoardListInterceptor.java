// src/main/java/dwacademy/mylms001/board/free/FreeBoardListInterceptor.java
package dwacademy.mylms001.board.free;

import dwacademy.mylms001.board.free.dto.FreePostItem;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collections;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class FreeBoardListInterceptor implements HandlerInterceptor {

    private final FreeBoardQueryRepository repo;

    @Override
    public void postHandle(HttpServletRequest request,
                           HttpServletResponse response,
                           Object handler,
                           @Nullable ModelAndView mav) throws Exception {
        if (mav == null) return;

        String uri = request.getRequestURI();
        if (uri == null || !uri.startsWith("/board/free")) return;

        int page = parseInt(request.getParameter("page"), 0);
        int size = parseInt(request.getParameter("size"), 10);
        String q = request.getParameter("q");

        List<FreePostItem> posts;
        try {
            posts = repo.list(q, page, size);
            if (posts == null) posts = Collections.emptyList();
        } catch (Exception e) {
            log.warn("Failed to load free board list (q={}, page={}, size={})", q, page, size, e);
            posts = Collections.emptyList();
            mav.addObject("loadError", true); // 템플릿에서 필요시 표시 가능
        }

        // 컨트롤러가 넣은 값이 있어도 응답 직전에 실제 데이터로 덮어씀
        mav.addObject("posts", posts);
        mav.addObject("typeSlug", "free"); // 링크/액션 생성에 사용
    }

    private static int parseInt(String s, int def) {
        if (s == null || s.isBlank()) return def;
        try { return Integer.parseInt(s); }
        catch (NumberFormatException ignore) { return def; }
    }
}
