package dwacademy.mylms001.board.free;

import dwacademy.mylms001.board.free.dto.FreePostItem;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.List;

/**
 * /board/free* 요청일 때, 컨트롤러를 건드리지 않고
 * 모델에 'posts', 'typeSlug' 등을 자동 주입한다.
 */
@ControllerAdvice
@RequiredArgsConstructor
public class FreeBoardModelAdvice {

    private final FreeBoardQueryRepository repo;

    @ModelAttribute("typeSlug")
    public String typeSlug(HttpServletRequest req) {
        String uri = req.getRequestURI();
        if (uri != null && uri.startsWith("/board/free")) {
            return "free";
        }
        return null; // 다른 페이지에는 주입하지 않음
    }

    @ModelAttribute("posts")
    public List<FreePostItem> posts(HttpServletRequest req) {
        String uri = req.getRequestURI();
        if (uri == null || !uri.startsWith("/board/free")) return null;

        // 간단한 페이징/검색 파라미터 처리 (없으면 기본값)
        int page = parseInt(req.getParameter("page"), 0);
        int size = parseInt(req.getParameter("size"), 10);
        String q = req.getParameter("q");

        return repo.list(q, page, size);
    }

    /** 안전한 int 파싱 */
    private static int parseInt(String s, int def) {
        try { return (s == null || s.isBlank()) ? def : Integer.parseInt(s); }
        catch (Exception e) { return def; }
    }
}
