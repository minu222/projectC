// 패키지는 @SpringBootApplication의 base-package 하위(예: dwacademy.mylms001.**)로!
package dwacademy.mylms001.board.comment;

import dwacademy.mylms001.board.comment.dto.CommentDto;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/posts") // /api/posts 까지 고정
public class CommentApiController {

    private final CommentService commentService;

    /** 댓글 목록: GET /api/posts/{postId}/comments (끝 슬래시 허용) */
    @GetMapping(path = {"/{postId}/comments", "/{postId}/comments/"})
    public List<CommentDto> list(@PathVariable long postId) {
        return commentService.list(postId);
    }

    /** 댓글 등록: POST /api/posts/{postId}/comments
     *  - JSON: { "content": "...", "parentId": 123 }
     *  - 폼 : content=...&parentId=123
     */
    @PostMapping(path = {"/{postId}/comments", "/{postId}/comments/"})
    public ResponseEntity<?> add(@PathVariable long postId,
                                 @RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(value = "content", required = false) String contentParam,
                                 @RequestParam(value = "parentId", required = false) Long parentParam,
                                 HttpServletRequest request) {

        Long userId = getLoginUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        // JSON/폼 모두 지원
        String content = contentParam;
        Long parentId = parentParam;
        if (content == null && body != null) {
            Object c = body.get("content");
            if (c != null) content = c.toString();
            Object p = body.get("parentId");
            if (p != null) try { parentId = Long.valueOf(p.toString()); } catch (Exception ignore) {}
        }
        if (content == null || content.isBlank()) {
            return ResponseEntity.badRequest().body("content is required");
        }

        long newId = commentService.add(postId, userId, content, parentId);
        return ResponseEntity.status(HttpStatus.CREATED).body(new IdRes(newId));
    }

    /** 댓글 수정: PUT /api/comments/{commentId} */
    @PutMapping("/comments/{commentId}")
    public ResponseEntity<?> edit(@PathVariable long commentId,
                                  @RequestBody EditReq req,
                                  HttpServletRequest request) {
        Long userId = getLoginUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        if (req == null || req.getContent() == null || req.getContent().isBlank()) {
            return ResponseEntity.badRequest().body("content is required");
        }
        boolean ok = commentService.edit(commentId, userId, req.getContent());
        return ok ? ResponseEntity.ok().build() : ResponseEntity.status(HttpStatus.FORBIDDEN).build();
    }

    /** 댓글 삭제: DELETE /api/posts/{postId}/comments/{commentId} (끝 슬래시 허용) */
    @DeleteMapping(path = {"/{postId}/comments/{commentId}", "/{postId}/comments/{commentId}/"})
    public ResponseEntity<?> delete(@PathVariable long postId,
                                    @PathVariable long commentId,
                                    HttpServletRequest request) {
        Long userId = getLoginUserId(request);
        if (userId == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        boolean ok = commentService.delete(commentId, userId, postId);
        return ok ? ResponseEntity.noContent().build() : ResponseEntity.status(HttpStatus.FORBIDDEN).build();
    }

    private Long getLoginUserId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return null;
        Object v = s.getAttribute("userId");
        if (v instanceof Number n) return n.longValue();
        try { return v == null ? null : Long.parseLong(v.toString()); } catch (Exception e) { return null; }
    }

    @Data static class EditReq { private String content; }
    @Data static class IdRes { private final long id; }
}
