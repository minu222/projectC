// src/main/java/dwacademy/mylms001/board/post/controller/BoardPageController.java
package dwacademy.mylms001.board.post.controller;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

// ✅ 기본 프로파일에선 비활성화(빈 미등록) → 매핑 충돌 없음
@Profile("board-v2")
@Controller
public class BoardPageController {

    // ※ 페이지 매핑을 전부 제거하거나, 필요 시 /postboard 같은 다른 경로로만 사용하세요.
    //   예) @GetMapping("/postboard/notice") ...
    //   지금은 의도적으로 매핑을 두지 않아 충돌 가능성 0%

    // 기존에 쓰던 유틸 메서드는 남겨도 문제없습니다(매핑이 없으니 빈만 없어짐).
    @SuppressWarnings("unused")
    private String setup(Model model, String fragment, String title) {
        model.addAttribute("bodyFragment", fragment);
        model.addAttribute("title", title);
        model.addAttribute("activeCategory", "board");
        model.addAttribute("userRole", "guest");
        model.addAttribute("showSidebar", true);
        return "layout";
    }
}
