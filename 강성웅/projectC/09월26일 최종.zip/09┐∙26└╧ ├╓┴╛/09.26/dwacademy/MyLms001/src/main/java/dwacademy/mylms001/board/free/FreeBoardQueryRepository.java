package dwacademy.mylms001.board.free;

import dwacademy.mylms001.board.free.dto.FreePostItem;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class FreeBoardQueryRepository {

    private final JdbcTemplate jdbc;

    private static java.time.LocalDateTime toLocal(Timestamp ts) {
        return ts == null ? null : ts.toLocalDateTime();
    }

    private final RowMapper<FreePostItem> mapper = (rs, n) -> FreePostItem.builder()
            .id(rs.getLong("id"))
            .title(rs.getString("title"))
            .createdAt(toLocal(rs.getTimestamp("created_at")))
            .authorId(rs.getLong("author_id"))
            .authorName(rs.getString("author_name"))
            .role(toLower(rs.getString("role")))
            .build();

    private static String toLower(String s) {
        return s == null ? null : s.trim().toLowerCase();
    }

    public List<FreePostItem> list(String q, int page, int size) {
        int offset = Math.max(0, page) * Math.max(1, size);

        String base = """
            SELECT
              p.post_id AS id,
              p.user_id AS author_id,
              COALESCE(u.name, CONCAT('user#', p.user_id)) AS author_name,
              u.role AS role,
              p.title,
              p.created_at
            FROM posts p
            LEFT JOIN users u ON u.user_id = p.user_id
            WHERE UPPER(p.category) = 'FREE' AND p.is_deleted = 0
            """;

        String orderLimit = " ORDER BY p.post_id DESC LIMIT ? OFFSET ?";

        if (q == null || q.isBlank()) {
            return jdbc.query(base + orderLimit, mapper, size, offset);
        }
        String withSearch = base + " AND p.title LIKE ? " + orderLimit;
        return jdbc.query(withSearch, mapper, "%" + q.trim() + "%", size, offset);
    }
}
