package dwacademy.mylms001.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/myclass")
public class MyClassController {

    /**
     * 나의 강의실 공통 모델 설정 메서드
     * @param model Spring Model 객체
     * @param fragment Thymeleaf fragment 경로
     * @param title 페이지 제목
     * @param userRole 사용자 역할 (guest, student, teacher)
     * @return layout 템플릿명
     */
    private String setupMyClassModel(Model model, String fragment, String title, String userRole) {
        model.addAttribute("bodyFragment", fragment);
        model.addAttribute("title", title);
        model.addAttribute("showSidebar", true); // 사이드바 표시
        model.addAttribute("userRole", userRole);
        model.addAttribute("activeCategory", "myclass");
        return "layout";
    }

    /**
     * 나의 강의실 메인 페이지
     * URL: /myclass
     */
    @GetMapping
    public String myClassPage(Model model) {
        return setupMyClassModel(model,
                "myclass/myclass :: content",  // myClassContent → content로 변경
                "MyLms",
                "null"
        );
    }

    /**
     * 학생 - 수강목록 페이지
     * URL: /myclass/student/courses
     */
    @GetMapping("/student/courses")
    public String studentCourses(Model model) {
        return setupMyClassModel(model,
                "myclass/studentCourses :: content",
                "MyLms",
                "student"
        );
    }

    /**
     * 학생 - 시험목록 페이지
     * URL: /myclass/student/exams
     */
    @GetMapping("/student/exams")
    public String studentExams(Model model) {
        return setupMyClassModel(model,
                "myclass/studentExams :: content",
                "MyLms",
                "student"
        );
    }

    /**
     * 강사 - 강의실목록 페이지
     * URL: /myclass/teacher/classes
     */
    @GetMapping("/teacher/classes")
    public String teacherClasses(Model model) {
        return setupMyClassModel(model,
                "myclass/teacherClasses :: content",
                "MyLms",
                "instructor"
        );
    }

    /**
     * 강사 - 강의실등록 페이지
     * URL: /myclass/teacher/register
     */
    @GetMapping("/teacher/register")
    public String teacherRegisterClass(Model model) {
        return setupMyClassModel(model,
                "myclass/teacherRegisterClass :: content",
                "MyLms",
                "instructor"
        );
    }

    /**
     * 공통 - 결제내역 페이지
     * URL: /myclass/payment
     */
    @GetMapping("/payment")
    public String paymentHistory(Model model) {
        return setupMyClassModel(model,
                "myclass/paymentHistory :: content",
                "MyLms",
                "student"
        );
    }

    /**
     * 공통 - 나의게시판 페이지
     * URL: /myclass/myBoard
     */
    @GetMapping("/myBoard")
    public String myBoard(Model model) {
        return setupMyClassModel(model,
                "myclass/myBoard :: content",
                "MyLms",
                "student"
        );
    }

    /**
     * 공통 - 이메일/쪽지 페이지
     * URL: /myclass/myMessage
     */
    @GetMapping("/myMessage")
    public String myMessage(Model model) {
        return setupMyClassModel(model,
                "myclass/myMessage :: content",
                "MyLms",
                "student"
        );
    }

    /**
     * 공통 - 회원정보수정 페이지
     * URL: /myclass/myInfo
     */
    @GetMapping("/myInfo")
    public String myInfo(Model model) {
        return setupMyClassModel(model,
                "myclass/myInfo :: content",
                "MyLms",
                "student"
        );
    }
}