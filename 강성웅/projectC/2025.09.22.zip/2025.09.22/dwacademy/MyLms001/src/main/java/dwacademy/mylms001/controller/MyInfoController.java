package dwacademy.mylms001.controller;

import dwacademy.mylms001.repository.UserRepository;
import dwacademy.mylms001.service.ProfileUpdateForm;
import dwacademy.mylms001.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Slf4j
@Controller
@RequestMapping("/myclass/myInfo")
@RequiredArgsConstructor
public class MyInfoController {

    private final UserService userService;
    private final UserRepository userRepository;

    @PostMapping("/update")
    public String update(@ModelAttribute ProfileUpdateForm form,
                         @RequestParam(value = "profileImage", required = false) MultipartFile profileImage,
                         HttpSession session,
                         RedirectAttributes ra) {

        log.info("Profile update request: user_id={}, nickname={}, name={}, phone={}, address={}, email={}, affiliation={}, bio={}",
                form.getUser_id(), form.getNickname(), form.getName(), form.getPhone(), form.getAddress(), form.getEmail(),
                form.getAffiliation(), form.getBio());

        userService.updateProfile(form, profileImage);

        // ✅ 세션 사용자 최신화 (화면에 바로 반영되게)
        userRepository.findById((int) form.getUser_id())
                .ifPresent(u -> session.setAttribute("loginUser", u));

        ra.addFlashAttribute("msg", "저장되었습니다.");
        return "redirect:/myclass/myInfo"; // 본인 라우팅에 맞게
    }
}

