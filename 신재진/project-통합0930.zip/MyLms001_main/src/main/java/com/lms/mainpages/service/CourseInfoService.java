// src/main/java/dwacademy/mylms001/service/CourseInfoService.java
package com.lms.mainpages.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

@Service
public class CourseInfoService {

    private final JdbcTemplate jdbc;
    private final DataSource dataSource;

    public CourseInfoService(JdbcTemplate jdbc, DataSource dataSource) {
        this.jdbc = jdbc;
        this.dataSource = dataSource;
    }

    private static final class Resolved {
        final String table;
        final String idCol;
        final String titleCol;
        final String instructorCol; // instructor_id / teacher_id / user_id ...
        Resolved(String table, String idCol, String titleCol, String instructorCol) {
            this.table = table; this.idCol = idCol; this.titleCol = titleCol; this.instructorCol = instructorCol;
        }
    }

    private volatile Resolved cached;

    private static String pick(Set<String> cols, String... cands) {
        for (String c : cands) if (cols.contains(c)) return c; return null;
    }

    private Resolved resolve() {
        var c = cached;
        if (c != null) return c;

        synchronized (this) {
            if (cached != null) return cached;

            String[] tableCands = {"courses","course","classes","class","tbl_course","tb_courses"};
            String[] idCands    = {"course_id","id","class_id"};
            String[] titleCands = {"title","course_name","name"};
            String[] instrCands = {"instructor_id","teacher_id","user_id","owner_id"};

            try (Connection con = dataSource.getConnection()) {
                for (String t : tableCands) {
                    // table exists?
                    try (PreparedStatement ps = con.prepareStatement(
                            "SELECT 1 FROM information_schema.tables WHERE table_schema=database() AND table_name=?")) {
                        ps.setString(1, t);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) continue;
                        }
                    }
                    // columns
                    Set<String> cols = new HashSet<>();
                    try (PreparedStatement ps = con.prepareStatement(
                            "SELECT column_name FROM information_schema.columns WHERE table_schema=database() AND table_name=?")) {
                        ps.setString(1, t);
                        try (ResultSet rs = ps.executeQuery()) {
                            while (rs.next()) cols.add(rs.getString(1).toLowerCase(Locale.ROOT));
                        }
                    }
                    String id = pick(cols, idCands);
                    String title = pick(cols, titleCands);
                    String instr = pick(cols, instrCands); // optional
                    if (id != null && title != null) {
                        cached = new Resolved(t, id, title, instr);
                        System.out.println("[CourseInfoService] resolved table=" + t + ", id=" + id + ", title=" + title + ", instructor=" + instr);
                        return cached;
                    }
                }
            } catch (SQLException e) {
                throw new IllegalStateException("강의 테이블 메타 탐지 실패", e);
            }
            throw new IllegalStateException("강의 테이블/컬럼을 찾지 못했습니다.");
        }
    }

    public String findCourseTitle(Long courseId) {
        if (courseId == null) return null;
        var r = resolve();
        String sql = "SELECT " + r.titleCol + " FROM " + r.table + " WHERE " + r.idCol + "=? LIMIT 1";
        return jdbc.query(sql, rs -> rs.next() ? rs.getString(1) : null, courseId);
    }

    public Long findInstructorIdOfCourse(Long courseId) {
        if (courseId == null) return null;
        var r = resolve();
        if (r.instructorCol == null) return null;
        String sql = "SELECT " + r.instructorCol + " FROM " + r.table + " WHERE " + r.idCol + "=? LIMIT 1";
        return jdbc.query(sql, rs -> rs.next() ? rs.getLong(1) : null, courseId);
    }
}
