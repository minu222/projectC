package com.lms.mainpages.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@RequiredArgsConstructor
public class ExamController {

    // exam/start/{id} 형태로 URL 매핑
    @GetMapping("/exam/start/{id}")
    public String examPage(@PathVariable("id") String id) {
        // id를 사용해야 한다면 여기서 처리
        System.out.println("Exam ID: " + id);
        return "myclass/examspage";
    }

}
