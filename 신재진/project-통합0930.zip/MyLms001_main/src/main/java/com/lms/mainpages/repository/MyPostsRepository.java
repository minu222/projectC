package com.lms.mainpages.repository;

public class MyPostsRepository {
}
