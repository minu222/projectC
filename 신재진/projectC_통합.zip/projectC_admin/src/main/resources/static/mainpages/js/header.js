// /static/js/header.js  (핵심만)
document.addEventListener('click', async (e) => {
    const a = e.target.closest('a');
    if (!a) return;

    const href = a.getAttribute('href');
    if (!href || href.startsWith('#')) return;

    // 외부링크/파일다운로드 등은 제외
    const isInternal = href.startsWith('/');
    if (!isInternal) return;

    // 부분 로딩으로 시도
    e.preventDefault();
    try {
        const res = await fetch(href, {
            headers: { 'X-Requested-With': 'Fetch' },
            credentials: 'same-origin'
        });

        const ct = res.headers.get('content-type') || '';
        if (!ct.includes('application/json')) {
            // 서버가 JSON이 아니면(리다이렉트/권한오류 등) 풀페이지 이동
            location.href = href;
            return;
        }

        const { sidebarHtml, bodyHtml, showSidebar } = await res.json();

        // ===== 본문 교체 =====
        const main = document.querySelector('main.content');
        if (main) {
            // bodyHtml은 프래그먼트 렌더 결과(루트 요소 포함)라서 innerHTML로 교체가 가장 안전
            main.innerHTML = bodyHtml;
        }

        // ===== 사이드바 교체/표시/숨김 =====
        let aside = document.querySelector('aside.sidebar');

        if (showSidebar) {
            if (!aside) {
                // 기존 레이아웃 구조 유지: main 앞에 aside를 만들어 붙임
                aside = document.createElement('aside');
                aside.className = 'sidebar';
                main.parentNode.insertBefore(aside, main);
            }
            aside.innerHTML = sidebarHtml;
            aside.style.display = '';       // 보이게
        } else {
            if (aside) aside.remove();      // 숨기는 대신 DOM 제거
        }

        // 히스토리 유지
        history.pushState({}, '', href);

    } catch (err) {
        console.error(err);
        // 실패 시 풀페이지 이동으로 폴백
        location.href = href;
    }
});
