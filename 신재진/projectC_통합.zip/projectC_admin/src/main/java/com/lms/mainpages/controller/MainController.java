package com.lms.mainpages.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller("mainController")
public class MainController {

    @GetMapping({"/", "/home"})
    public String homePage(Model model) {
        model.addAttribute("bodyFragment", "mainpages/index :: indexContent");
        model.addAttribute("title", "MyLms");
        model.addAttribute("activeCategory", "home");
        model.addAttribute("userRole", "guest"); // guest / 학생 / 강사 구분 가능
        model.addAttribute("showSidebar", false);
        return "mainpages/layout";
    }


}