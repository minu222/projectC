package dwacademy.ai01.ai.dto;

/**
 * 문제 자동생성 요청 파라미터
 * - sourceText: 수업/교재 텍스트
 * - mcqCount/shortCount/essayCount: 각 문항 수
 * - level: 난이도(상/중/하)
 */
public class GenerateRequest {
    private String sourceText;
    private int mcqCount = 3;
    private int shortCount = 2;
    private int essayCount = 1;
    private String level = "중";

    // --- getters/setters ---
    public String getSourceText() { return sourceText; }
    public void setSourceText(String sourceText) { this.sourceText = sourceText; }
    public int getMcqCount() { return mcqCount; }
    public void setMcqCount(int mcqCount) { this.mcqCount = mcqCount; }
    public int getShortCount() { return shortCount; }
    public void setShortCount(int shortCount) { this.shortCount = shortCount; }
    public int getEssayCount() { return essayCount; }
    public void setEssayCount(int essayCount) { this.essayCount = essayCount; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
}
