package dwacademy.ai01.ai;

import dwacademy.ai01.ai.dto.*;

import java.util.List;

/**
 * AI 연동 추상화 인터페이스
 * - 구현체 교체만으로 HuggingFace/Ollama 전환 가능
 */
public interface AiService {
    /** 주어진 텍스트로 문제 생성 */
    List<QuestionDto> generateQuestions(GenerateRequest req) throws Exception;

    /** 학생답 해설(간단) */
    String explainAnswer(QuestionDto q, String studentAnswer, boolean concise) throws Exception;
}
