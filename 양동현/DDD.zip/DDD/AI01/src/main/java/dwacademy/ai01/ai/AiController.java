package dwacademy.ai01.ai;

import dwacademy.ai01.ai.dto.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 문제 생성/채점용 REST API
 * - /api/ai/generate : 문제 자동생성
 * - /api/ai/grade    : 자동채점(+선택적 AI 해설)
 */
@RestController
@RequestMapping("/api/ai")
public class AiController {

    private final AiService ai;

    public AiController(AiService ai) {
        this.ai = ai;
    }

    /** 문제 자동생성 */
    @PostMapping("/generate")
    public ResponseEntity<List<QuestionDto>> generate(@RequestBody GenerateRequest req) throws Exception {
        List<QuestionDto> list = ai.generateQuestions(req);
        // 안전장치: id 미설정 시 UUID 부여
        list.forEach(q -> {
            if (q.getId()==null || q.getId().isBlank())
                q.setId(java.util.UUID.randomUUID().toString());
            if (q.getPoints() <= 0) q.setPoints(1);
        });
        return ResponseEntity.ok(list);
    }

    /** 자동채점(간단 키워드 매칭 + 선택적 AI 해설) */
    @PostMapping("/grade")
    public ResponseEntity<GradeResult> grade(@RequestBody GradeRequest req) throws Exception {
        Map<String, QuestionDto> byId = req.getQuestions()
                .stream().collect(Collectors.toMap(QuestionDto::getId, q->q));

        List<GradeResult.Item> items = new ArrayList<>();
        int total=0, max=0;

        for (GradeRequest.StudentAnswer sa : req.getAnswers()) {
            QuestionDto q = byId.get(sa.getQuestionId());
            if (q==null) continue;

            GradeResult.Item it = new GradeResult.Item();
            it.setQuestionId(q.getId());

            int pts = q.getPoints()<=0?1:q.getPoints();
            max += pts;

            // 간단 채점 규칙
            boolean correct = switch (q.getType()) {
                case MCQ   -> compareMcq(sa.getAnswerText(), q.getAnswer());
                case SHORT -> keywordMatch(sa.getAnswerText(), q.getAnswer(), 0.6);
                case ESSAY -> keywordMatch(sa.getAnswerText(), q.getAnswer(), 0.5); // 서술형은 느슨
            };
            it.setCorrect(correct);
            it.setScore(correct? pts : 0);

            // 선택적 AI 해설
            if (req.isUseAIExplain()) {
                String fb = ai.explainAnswer(q, sa.getAnswerText(), true);
                if (fb!=null && fb.length()>800) fb = fb.substring(0,800) + "...";
                it.setFeedback(fb);
            } else {
                it.setFeedback(correct? "정답입니다!" : "오답입니다. 핵심 키워드를 확인해보세요.");
            }

            total += it.getScore();
            items.add(it);
        }

        GradeResult gr = new GradeResult();
        gr.setItems(items);
        gr.setTotalScore(total);
        gr.setMaxScore(max);
        return ResponseEntity.ok(gr);
    }

    // --- 채점 유틸 ---

    /** 객관식: A/B/C/D 라벨 일치 여부 */
    private boolean compareMcq(String a, String key) {
        if (a==null || key==null) return false;
        return a.trim().equalsIgnoreCase(key.trim());
    }

    /**
     * 키워드 포함 매칭(단답/서술)
     * - answer에 쉼표/줄바꿈으로 키워드 나열
     * - 포함율이 thresh 이상이면 정답 처리
     */
    private boolean keywordMatch(String ans, String key, double thresh) {
        if (ans==null || key==null) return false;
        String[] kws = key.toLowerCase().split("[,\\n]");
        int hit=0, need=0;
        String low = ans.toLowerCase();

        for (String kw : kws) {
            String k = kw.trim();
            if (k.isEmpty()) continue;
            need++;
            if (low.contains(k)) hit++;
        }
        if (need==0) return false;
        return (hit/(double)need) >= thresh;
    }
}
