package dwacademy.ai01.ai.debug;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

/**
 * /api/ai/_debug/ping : Ollama 연결/모델 상태를 런타임에서 확인
 */
@RestController
@RequestMapping("/api/ai/_debug")
public class AiDebugController {
    private final RestTemplate rt = new RestTemplate();
    private final ObjectMapper om = new ObjectMapper();

    @Value("${ai.ollama.url:http://localhost:11434/api/generate}")
    private String ollamaUrl;
    @Value("${ai.ollama.model:llama3.1}")
    private String model;

    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        try {
            var body = new java.util.HashMap<String,Object>();
            body.put("model", model);
            body.put("prompt", "ping");
            body.put("stream", false);

            var h = new HttpHeaders();
            h.setContentType(MediaType.APPLICATION_JSON);
            var res = rt.exchange(ollamaUrl, HttpMethod.POST, new HttpEntity<>(om.writeValueAsString(body), h), String.class);
            return ResponseEntity.ok("OK " + res.getStatusCodeValue() + " / body.len=" + (res.getBody()==null?0:res.getBody().length()));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("ERR: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }
}
