package dwacademy.ai01.ai.dto;

import java.util.List;

/**
 * 단일 문항을 표현하는 DTO
 * - type: MCQ(객관), SHORT(단답), ESSAY(서술)
 * - stem: 문제 지문
 * - options: 보기(객관식 전용, A~D 4개 가정)
 * - answer: 정답(객관/단답) 또는 채점 키워드(서술)
 * - points: 배점(기본 1점)
 */
public class QuestionDto {
    public enum Type { MCQ, SHORT, ESSAY }

    private String id;            // 프론트/채점에서 식별용 UUID
    private Type type;
    private String stem;
    private List<String> options; // MCQ 전용
    private String answer;        // 정답/키워드
    private int points = 1;       // 배점

    // --- getters/setters ---
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public Type getType() { return type; }
    public void setType(Type type) { this.type = type; }
    public String getStem() { return stem; }
    public void setStem(String stem) { this.stem = stem; }
    public List<String> getOptions() { return options; }
    public void setOptions(List<String> options) { this.options = options; }
    public String getAnswer() { return answer; }
    public void setAnswer(String answer) { this.answer = answer; }
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }
}
