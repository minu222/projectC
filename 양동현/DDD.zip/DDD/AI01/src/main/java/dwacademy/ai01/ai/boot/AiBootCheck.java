package dwacademy.ai01.ai.boot;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 부팅 직후 환경/연결 상태를 로그로 덤프해서
 * "왜 ApplicationContext 시작 실패처럼 보이는가?"를 즉시 파악.
 * - 실패해도 예외를 삼켜서 앱이 죽지 않도록 설계.
 */
@Configuration
public class AiBootCheck {

    @Value("${ai.ollama.url:http://localhost:11434/api/generate}")
    private String ollamaUrl;

    @Value("${ai.ollama.model:llama3.1}")
    private String model;

    @Value("${ai.checkAtBoot:true}")
    private boolean checkAtBoot;

    @Bean
    ApplicationRunner aiEnvDumpRunner() {
        return args -> {
            if (!checkAtBoot) return;
            try {
                System.out.println("=== [AI BOOT CHECK] start ===");
                System.out.println("ai.ollama.url   = " + ollamaUrl);
                System.out.println("ai.ollama.model = " + model);

                // 간단한 네트워크 체크(HTTP만 열려있는지)
                var url = new java.net.URL(ollamaUrl);
                var conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(2000);
                conn.setReadTimeout(2000);
                conn.setDoOutput(true);
                String pingJson = "{\"model\":\"" + model + "\",\"prompt\":\"ping\",\"stream\":false}";
                try (var os = conn.getOutputStream()) { os.write(pingJson.getBytes()); }
                int code = conn.getResponseCode();
                System.out.println("Ollama HTTP response = " + code + " (200이면 OK, 500/404면 URL/모델/데몬 확인)");
            } catch (Exception e) {
                System.out.println("!!! [AI BOOT CHECK] Ollama 연결 실패(앱은 계속 실행): " + e.getClass().getSimpleName() + " - " + e.getMessage());
            } finally {
                System.out.println("=== [AI BOOT CHECK] end ===");
            }
        };
    }
}
