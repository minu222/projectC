package dwacademy.ai01.ai.dto;

import java.util.List;

/**
 * 자동채점 요청
 * - questions: 출제본(원문항들)
 * - answers: 학생 제출답안
 * - useAIExplain: AI 해설 생성 여부
 */
public class GradeRequest {

    /** 학생 제출답 단위 DTO */
    public static class StudentAnswer {
        private String questionId; // QuestionDto.id
        private String answerText; // 학생이 고른 값(A/B/C/D 혹은 텍스트)

        public String getQuestionId() { return questionId; }
        public void setQuestionId(String questionId) { this.questionId = questionId; }
        public String getAnswerText() { return answerText; }
        public void setAnswerText(String answerText) { this.answerText = answerText; }
    }

    private List<QuestionDto> questions;
    private List<StudentAnswer> answers;
    private boolean useAIExplain = true;

    // --- getters/setters ---
    public List<QuestionDto> getQuestions() { return questions; }
    public void setQuestions(List<QuestionDto> questions) { this.questions = questions; }
    public List<StudentAnswer> getAnswers() { return answers; }
    public void setAnswers(List<StudentAnswer> answers) { this.answers = answers; }
    public boolean isUseAIExplain() { return useAIExplain; }
    public void setUseAIExplain(boolean useAIExplain) { this.useAIExplain = useAIExplain; }
}
