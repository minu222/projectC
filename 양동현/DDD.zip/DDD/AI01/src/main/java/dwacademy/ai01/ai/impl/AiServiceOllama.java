package dwacademy.ai01.ai.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import dwacademy.ai01.ai.AiService;
import dwacademy.ai01.ai.dto.GenerateRequest;
import dwacademy.ai01.ai.dto.QuestionDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * 로컬 무료 LLM(Ollama) 연동 구현체
 * - 기본 엔드포인트: http://localhost:11434/api/generate
 * - 모델: llama3.1 (가볍고 무난)
 */
@Primary
@Service
public class AiServiceOllama implements AiService {

    private final RestTemplate rt = new RestTemplate();
    private final ObjectMapper om = new ObjectMapper();

    @Value("${ai.ollama.url:http://localhost:11434/api/generate}")
    private String ollamaUrl;

    @Value("${ai.ollama.model:llama3.1}")
    private String model;

    @Override
    public List<QuestionDto> generateQuestions(GenerateRequest req) throws Exception {
        // 1) 출제 프롬프트 생성
        String prompt = buildGenPrompt(req);
        // 2) Ollama 호출
        String text = callOllama(prompt);

        // 3) 모델이 JSON 배열로 잘 보냈다면 그대로 파싱
        try {
            QuestionDto[] arr = om.readValue(text, QuestionDto[].class);
            return new ArrayList<>(Arrays.asList(arr));
        } catch (Exception e) {
            // 4) 혹시 JSON 포맷이 깨진 경우(LLM 특성) 최소 파싱(백업)
            return fallbackParse(text);
        }
    }

    @Override
    public String explainAnswer(QuestionDto q, String studentAnswer, boolean concise) throws Exception {
        // 문항/정답/학생답 기반 간단 해설 요청
        String prompt = """
                당신은 채점 해설가입니다. 아래 문제와 학생 답안을 보고,
                1) 정오판정 근거, 2) 핵심 개념, 3) 보완 팁을 간결하게 한국어로 설명하세요.
                %s
                [문제] %s
                [정답(키워드/모범답안)] %s
                [학생답] %s
                """.formatted(concise ? "(간결 모드)" : "(자세히 모드)",
                q.getStem(), q.getAnswer(), studentAnswer);
        return callOllama(prompt);
    }

    /** Ollama HTTP 호출 공통부 */
    private String callOllama(String prompt) throws Exception {
        Map<String, Object> body = Map.of(
                "model", model,
                "prompt", prompt,
                "stream", false // 단건 응답(스트리밍 X)
        );
        HttpHeaders h = new HttpHeaders();
        h.setContentType(MediaType.APPLICATION_JSON);

        ResponseEntity<String> res = rt.exchange(
                ollamaUrl, HttpMethod.POST, new HttpEntity<>(body, h), String.class);

        // Ollama 응답 JSON에서 "response" 필드 추출
        JsonNode root = om.readTree(res.getBody());
        return root.path("response").asText();
    }

    /** 생성 프롬프트(모델이 JSON만 출력하도록 강하게 가이드) */
    private String buildGenPrompt(GenerateRequest r) {
        return """
                당신은 교육용 출제기입니다. 아래 텍스트로부터 시험 문제를 생성하세요.

                [요구사항]
                - 난이도: %s
                - 출력 형식: 오직 JSON 배열만 출력 (주석/설명 금지)
                - 스키마:
                  [
                    {
                      "id": "uuid",
                      "type": "MCQ|SHORT|ESSAY",
                      "stem": "문항",
                      "options": ["A","B","C","D"],   // MCQ 전용
                      "answer":"정답 또는 키워드",
                      "points": 1
                    }
                  ]
                - 객관식 %d문항(보기 4개, 정답 1개), 단답형 %d문항(키워드 정답), 서술형 %d문항(채점 키워드)
                - 한국어로 작성

                [수업 텍스트]
                ---
                %s
                ---
                """.formatted(r.getLevel(), r.getMcqCount(), r.getShortCount(), r.getEssayCount(), r.getSourceText());
    }

    /**
     * JSON 파싱 실패 시 최소한으로 문항 형태를 구성해주는 백업 파서
     * - 실제 운영 시에는 JSON 강제 포맷팅 재요청(리트라이) 로직을 추가해도 좋음
     */
    private List<QuestionDto> fallbackParse(String txt) {
        List<QuestionDto> list = new ArrayList<>();
        String[] lines = txt.split("\n");
        for (String ln : lines) {
            if (ln.trim().length() < 5) continue;
            QuestionDto q = new QuestionDto();
            q.setId(UUID.randomUUID().toString());
            q.setType(ln.contains("객관식") ? QuestionDto.Type.MCQ : QuestionDto.Type.SHORT);
            q.setStem(ln);
            q.setAnswer("");
            q.setPoints(1);
            list.add(q);
            if (list.size() >= 6) break; // 너무 길어지는 것 방지(데모)
        }
        return list;
    }
}
