package dwacademy.ai01.ai;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 데모 페이지 라우팅
 * - /ai/demo : 생성 패널 + 응시/채점 패널이 한 페이지에 존재
 * - 기존 레이아웃 유지하고 싶으면 layout에 삽입하도록 변형 가능
 */
@Controller
public class AiDemoController {

    @GetMapping("/ai/demo")
    public String demoPage() {
        return "ai-demo"; // templates/ai-demo.html
    }
}
