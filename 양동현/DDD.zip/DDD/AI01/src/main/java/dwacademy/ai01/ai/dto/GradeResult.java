package dwacademy.ai01.ai.dto;

import java.util.List;

/**
 * 자동채점 결과
 * - totalScore/maxScore: 합계/만점
 * - items: 문항별 판정/점수/피드백
 */
public class GradeResult {

    /** 문항별 결과 단위 DTO */
    public static class Item {
        private String questionId;
        private boolean correct;
        private int score;
        private String feedback; // 간단 해설

        public String getQuestionId() { return questionId; }
        public void setQuestionId(String questionId) { this.questionId = questionId; }
        public boolean isCorrect() { return correct; }
        public void setCorrect(boolean correct) { this.correct = correct; }
        public int getScore() { return score; }
        public void setScore(int score) { this.score = score; }
        public String getFeedback() { return feedback; }
        public void setFeedback(String feedback) { this.feedback = feedback; }
    }

    private int totalScore;
    private int maxScore;
    private List<Item> items;

    // --- getters/setters ---
    public int getTotalScore() { return totalScore; }
    public void setTotalScore(int totalScore) { this.totalScore = totalScore; }
    public int getMaxScore() { return maxScore; }
    public void setMaxScore(int maxScore) { this.maxScore = maxScore; }
    public List<Item> getItems() { return items; }
    public void setItems(List<Item> items) { this.items = items; }
}
