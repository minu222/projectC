// 학생용 응시/채점 스크립트
// - 텍스트에 JSON을 붙여넣고 [문제 로드]
// - 답안 입력 후 [제출 & 채점] -> /api/ai/grade 호출
(function(){
    const $ = (q)=>document.querySelector(q);
    const form = $("#answerForm");
    const btnLoad = $("#btnLoad");
    const btnSubmit = $("#btnSubmit");

    if(!btnLoad || !form) return;

    // 문제 로드
    btnLoad.addEventListener("click", ()=>{
        try {
            const qs = JSON.parse($("#questionsJson").value);
            form.innerHTML = qs.map(renderQ).join("");
            btnSubmit.style.display = "inline-block";
            // 원본 문항을 hidden state로 저장
            form.dataset.questions = JSON.stringify(qs);
        } catch(e) {
            alert("JSON 파싱 오류: 생성 패널에서 복사한 원문 JSON을 붙여넣어 주세요.");
        }
    });

    // 제출 & 채점
    btnSubmit.addEventListener("click", async ()=>{
        const qs = JSON.parse(form.dataset.questions||"[]");
        const answers = [];

        // 각 문항 타입별로 값 추출
        qs.forEach(q=>{
            const name = `q_${q.id}`;
            let val = "";
            if(q.type==="MCQ"){
                const checked = form.querySelector(`input[name="${name}"]:checked`);
                val = checked ? checked.value : "";
            } else {
                const el = form.querySelector(`[name="${name}"]`);
                val = el ? el.value : "";
            }
            answers.push({ questionId: q.id, answerText: val });
        });

        // API 호출
        const res = await fetch("/api/ai/grade", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ questions: qs, answers, useAIExplain: true })
        });
        const data = await res.json();

        // 결과 표시
        $("#gradeResult").innerHTML = `
      <div style="margin-bottom:6px;"><b>점수:</b> ${data.totalScore} / ${data.maxScore}</div>
      <ul style="padding-left:18px;">
        ${data.items.map(it=>`<li style="margin-bottom:8px;">
          <b>${it.questionId}</b> - ${it.correct? "정답 ✅":"오답 ❌"} ( ${it.score}점 )<br>
          <div style="color:#555;">해설: ${escapeHtml(it.feedback||"")}</div>
        </li>`).join("")}
      </ul>
    `;
    });

    // --- 렌더링 유틸 ---
    function renderQ(q,i){
        const idx=i+1;
        if(q.type==="MCQ"){
            // 객관식: A/B/C/D 라디오 (라벨은 A,B,C,D로 제출)
            const opts = (q.options||[]).map((o,oi)=>{
                const optLabel = String.fromCharCode(65+oi); // 65='A'
                return `<label style="display:block;margin:4px 0;">
          <input type="radio" name="q_${q.id}" value="${optLabel}">
          (${optLabel}) ${escapeHtml(o)}
        </label>`;
            }).join("");
            return wrap(idx, q.stem, opts);
        }
        // 단답/서술
        const rows = q.type==="SHORT" ? 1 : 4;
        const input = `<textarea name="q_${q.id}" rows="${rows}" style="width:100%;"></textarea>`;
        return wrap(idx, q.stem, input);
    }

    function wrap(idx, stem, inner){
        return `<div style="border:1px solid #ddd;padding:10px;border-radius:8px;margin:8px 0;">
      <div><b>Q${idx}.</b> ${escapeHtml(stem||"")}</div>
      <div style="margin-top:6px;">${inner}</div>
    </div>`;
    }
    function escapeHtml(s){ return (s||"").replace(/[&<>"']/g, m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m])); }
})();
