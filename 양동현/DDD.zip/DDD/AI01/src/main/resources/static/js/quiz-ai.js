// 교사용 생성 패널 스크립트
// - /api/ai/generate 호출 -> JSON 배열(문항들) 수신 -> 사람이 미리보기 확인
(function(){
    const $ = (q)=>document.querySelector(q);
    const btn = $("#btnGenerate");
    if(!btn) return; // 이 스크립트가 없는 페이지에서 오류 방지

    btn.addEventListener("click", async ()=>{
        const body = {
            sourceText: $("#qaSource").value,
            mcqCount: parseInt($("#mcqCount").value||"0"),
            shortCount: parseInt($("#shortCount").value||"0"),
            essayCount: parseInt($("#essayCount").value||"0"),
            level: $("#level").value
        };

        // UX: 로딩 표시
        $("#genPreview").innerHTML = "생성 중... (로컬 모델 호출 중)";

        // 백엔드 호출
        const res = await fetch("/api/ai/generate", {
            method:"POST",
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify(body)
        });

        // 응답 JSON -> 간단 렌더
        const data = await res.json();
        $("#genPreview").innerHTML = data.map(renderQ).join("");

        // --- 내부 함수들 ---
        function renderQ(q,i){
            const idx = i+1;
            const opt = (q.type==="MCQ" && q.options) ? `
        <ol type="A" style="margin:6px 0 0 18px;">
          ${q.options.map(o=>`<li>${escapeHtml(o)}</li>`).join("")}
        </ol>` : "";
            return `
      <div style="border:1px solid #ddd;padding:10px;border-radius:8px;margin:8px 0;">
        <div><b>[${q.type}] Q${idx}.</b> ${escapeHtml(q.stem)}</div>
        ${opt}
        <div style="color:#888;font-size:12px;margin-top:6px;">
          정답/키: ${escapeHtml(q.answer||"")}, 배점: ${q.points||1}, id: ${q.id}
        </div>
      </div>`;
        }
        function escapeHtml(s){ return (s||"").replace(/[&<>"']/g, m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m])); }
    });
})();
