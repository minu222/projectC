// teacherIntro.js

(() => {
    document.addEventListener('DOMContentLoaded', () => {
        // ===== 페이지 가드: 이 페이지의 모달이 없으면 종료 =====
        const modal = document.getElementById('modal');
        if (!modal) return;

        const modalClose = document.getElementById('modalClose');
        const detailBtns = document.querySelectorAll('.detailBtn');

        detailBtns.forEach(btn => btn.addEventListener('click', () => { modal.style.display='flex'; }));
        modalClose?.addEventListener('click', () => { modal.style.display='none'; });

        window.addEventListener('click', (e) => {
            if (e.target === modal) modal.style.display='none';
        });

        // 검색(있을 때만)
        const searchBtn = document.getElementById('searchBtn');
        searchBtn?.addEventListener('click', () => {
            const kw = (document.getElementById('searchInput')?.value || '').trim();
            const ft = (document.getElementById('filter')?.value || '');
            console.log('검색어:', kw, '필터:', ft);
            // TODO: 실제 필터링 로직/서버 요청 연결
        });
    });
})();
