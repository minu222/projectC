// examSchedule.js

(() => {
    document.addEventListener('DOMContentLoaded', () => {
        // ===== 페이지 가드: 핵심 요소(#calendar)가 없으면 종료 =====
        const calendar = document.getElementById('calendar');
        if (!calendar) return;

        // ===== 전역 기본값 =====
        const currentUser = window.currentUser || 'teacher1';
        const exams = Array.isArray(window.exams) ? window.exams : [
            {course:"JAVA",   name:"중간고사", date:"2025-09-03", author:"teacher1"},
            {course:"React",  name:"기말고사", date:"2025-09-05", author:"teacher2"},
            {course:"Python", name:"퀴즈",    date:"2025-09-03", author:"teacher1"}
        ];

        // ===== 모달 및 입력 요소 (널 허용: 없으면 해당 기능만 비활성) =====
        const registerModal = document.getElementById('registerModal');
        const editModal     = document.getElementById('editModal');
        const deleteModal   = document.getElementById('deleteModal');

        const courseInput   = document.getElementById('courseInput');
        const examNameInput = document.getElementById('examName');
        const examDateInput = document.getElementById('examDate');

        const regBtn   = document.getElementById('registerBtn'); // 이 페이지에 같은 ID가 없다면 그대로 사용
        const editBtn  = document.getElementById('editBtn');
        const delBtn   = document.getElementById('deleteBtn');

        let editingIndex = null;

        function renderCalendar() {
            calendar.innerHTML = '';
            // 간단한 30일 캘린더
            const monthDays = 30;
            for (let day=1; day<=monthDays; day++){
                const dayDiv = document.createElement('div');
                dayDiv.className='day';
                dayDiv.innerHTML = `<h4>${day}일</h4>`;
                exams.filter(e=> new Date(e.date).getDate()===day)
                    .forEach(e=>{
                        const div = document.createElement('div');
                        div.className='exam';
                        div.textContent = `${e.course} - ${e.name}`;
                        dayDiv.appendChild(div);
                    });
                calendar.appendChild(dayDiv);
            }
        }

        function openModal(modal){ if (modal) modal.style.display='flex'; }
        function closeModal(modal){ if (modal) modal.style.display='none'; }

        // 등록 버튼: 모달 열기 (필요 요소가 모두 있을 때만)
        regBtn?.addEventListener('click', ()=>{
            if (courseInput)   courseInput.value='';
            if (examNameInput) examNameInput.value='';
            if (examDateInput) examDateInput.value='';
            editingIndex = null;
            openModal(registerModal);
        });

        // 수정 버튼: 내 소유 목록 만들기
        editBtn?.addEventListener('click', ()=>{
            const listDiv = document.getElementById('editList');
            if (!listDiv) { openModal(editModal); return; }
            listDiv.innerHTML='';
            exams.forEach((e,i)=>{
                if (e.author===currentUser){
                    const div=document.createElement('div');
                    div.className='modal-exam-item';
                    div.textContent=`${e.date} - ${e.course} - ${e.name}`;
                    div.style.cursor='pointer';
                    div.addEventListener('click', ()=>{
                        if (courseInput)   courseInput.value=e.course;
                        if (examNameInput) examNameInput.value=e.name;
                        if (examDateInput) examDateInput.value=e.date;
                        editingIndex=i;
                        closeModal(editModal);
                        openModal(registerModal);
                    });
                    listDiv.appendChild(div);
                }
            });
            openModal(editModal);
        });

        // 삭제 버튼: 체크박스 목록
        delBtn?.addEventListener('click', ()=>{
            const listDiv = document.getElementById('deleteList');
            if (!listDiv) { openModal(deleteModal); return; }
            listDiv.innerHTML='';
            exams.forEach((e,i)=>{
                if (e.author===currentUser){
                    const row=document.createElement('div');
                    row.className='modal-exam-item';
                    const checkbox=document.createElement('input');
                    checkbox.type='checkbox';
                    checkbox.className='delete-checkbox';
                    checkbox.value=String(i);
                    row.appendChild(checkbox);
                    const label=document.createElement('span');
                    label.textContent=`${e.date} - ${e.course} - ${e.name}`;
                    row.appendChild(label);
                    listDiv.appendChild(row);
                }
            });
            openModal(deleteModal);
        });

        // 저장
        document.getElementById('submitExam')?.addEventListener('click', ()=>{
            const course = (courseInput?.value || '').trim();
            const name   = (examNameInput?.value || '').trim();
            const date   = (examDateInput?.value || '');

            if(!course || !name || !date){ alert('모든 항목을 입력해주세요'); return; }

            if (editingIndex !== null){
                exams[editingIndex] = { course, name, date, author: currentUser };
                editingIndex = null;
            } else {
                exams.push({ course, name, date, author: currentUser });
            }
            closeModal(registerModal);
            renderCalendar();
        });

        // 삭제 확인
        document.getElementById('deleteConfirmBtn')?.addEventListener('click', ()=>{
            const checkboxes=document.querySelectorAll('#deleteList input[type="checkbox"]:checked');
            const indexes=[...checkboxes].map(cb=>parseInt(cb.value,10)).sort((a,b)=>b-a);
            indexes.forEach(i=> exams.splice(i,1));
            closeModal(deleteModal);
            renderCalendar();
        });

        // 모달 닫기 (X 버튼)
        document.querySelectorAll('.modal-close')?.forEach(btn=>{
            btn.addEventListener('click', ()=>{
                const modal = btn.closest('.modal-overlay');
                if (modal) closeModal(modal);
            });
        });
        // 오버레이 클릭 닫기
        document.querySelectorAll('.modal-overlay')?.forEach(mod=>{
            mod.addEventListener('click', (e)=>{
                if (e.target === mod) closeModal(mod);
            });
        });

        // 최초 렌더
        renderCalendar();
    });
})();
