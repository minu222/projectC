// bookRecommendation.js

(() => {
    document.addEventListener('DOMContentLoaded', () => {
        // ===== 페이지 가드: 이 페이지의 핵심 요소가 없으면 종료 =====
        const modalOverlay = document.getElementById('modalOverlay');
        const myEditOverlay = document.getElementById('myEditOverlay');
        const deleteOverlay = document.getElementById('deleteOverlay');
        if (!modalOverlay || !myEditOverlay || !deleteOverlay) return; // 다른 페이지에서는 조용히 패스

        // ===== 전역(또는 서버 주입) 기대값 기본값 처리 =====
        window.currentUserId = window.currentUserId || 'teacher1';
        window.isInstructor = typeof window.isInstructor === 'boolean' ? window.isInstructor : true;
        window.books = Array.isArray(window.books) ? window.books : [
            {img:'https://via.placeholder.com/200x150', instructor:'강사1', title:'책 제목1', desc:'소개글1', ownerId:'teacher1'},
            {img:'https://via.placeholder.com/200x150', instructor:'강사2', title:'책 제목2', desc:'소개글2', ownerId:'teacher2'},
            {img:'https://via.placeholder.com/200x150', instructor:'강사3', title:'책 제목3', desc:'소개글3', ownerId:'teacher3'},
        ];

        // ===== 안전 셀렉터 =====
        const $id = (id) => document.getElementById(id);

        // 강사 버튼 노출 제어 (해당 버튼이 있으면만 처리)
        ['registerBtn','editBtn','deleteBtn'].forEach(id=>{
            const el = $id(id);
            if (el) el.style.display = window.isInstructor ? '' : 'none';
        });

        // 닫기 버튼 바인딩(존재할 때만)
        $id('modalClose')?.addEventListener('click', ()=> modalOverlay.style.display='none');
        $id('myEditClose')?.addEventListener('click', ()=> myEditOverlay.style.display='none');
        $id('deleteClose')?.addEventListener('click', ()=> deleteOverlay.style.display='none');

        let cameFromEditList = false;

        // 등록
        $id('registerBtn')?.addEventListener('click', ()=>{
            if(!window.isInstructor){ alert('등록 권한이 없습니다.'); return; }
            cameFromEditList = false;
            openModal(); // 새 등록
        });

        // 수정
        $id('editBtn')?.addEventListener('click', ()=>{
            if(!window.isInstructor){ alert('수정 권한이 없습니다.'); return; }
            openMyListForEdit();
        });

        // 삭제
        $id('deleteBtn')?.addEventListener('click', ()=>{
            if(!window.isInstructor){ alert('삭제 권한이 없습니다.'); return; }
            openDeleteModal();
        });

        function openModal(book=null, idx=null){
            modalOverlay.style.display='flex';

            const instructorInput=$id('instructorInput');
            const titleInput=$id('titleInput');
            const descInput=$id('descInput');
            const imgInput=$id('imgInput');
            const backBtn = $id('backToEditListBtn');
            const saveBtn = $id('saveBtn');

            if (!instructorInput || !titleInput || !descInput || !imgInput || !backBtn || !saveBtn) {
                console.warn('[bookRecommendation] 필수 입력/버튼 누락');
                return;
            }

            // “수정목록으로” 표시
            backBtn.style.display = cameFromEditList ? '' : 'none';
            backBtn.onclick = ()=>{
                modalOverlay.style.display='none';
                openMyListForEdit();
            };

            if(book){
                if(book.ownerId !== window.currentUserId){
                    alert('본인이 등록한 도서만 수정할 수 있습니다.');
                    modalOverlay.style.display='none';
                    return;
                }
                instructorInput.value=book.instructor || '';
                titleInput.value=book.title || '';
                descInput.value=book.desc || '';
                imgInput.value='';
            } else {
                instructorInput.value=''; titleInput.value=''; descInput.value=''; imgInput.value='';
            }

            saveBtn.onclick = ()=>{
                const finalize = (imgDataOrNull)=>{
                    if(book){
                        window.books[idx] = {
                            ...window.books[idx],
                            instructor: instructorInput.value,
                            title: titleInput.value,
                            desc: descInput.value,
                            ...(imgDataOrNull ? {img: imgDataOrNull} : {})
                        };
                        // TODO: PUT /books/{id}
                    } else {
                        window.books.push({
                            instructor: instructorInput.value,
                            title: titleInput.value,
                            desc: descInput.value,
                            img: imgDataOrNull || 'https://via.placeholder.com/200x150',
                            ownerId: window.currentUserId
                        });
                        // TODO: POST /books
                    }
                    modalOverlay.style.display='none';
                    window.renderCards?.();
                    window.renderPagination?.();
                    if (cameFromEditList) openMyListForEdit();
                };

                const file = imgInput.files && imgInput.files[0];
                if(file){
                    const reader=new FileReader();
                    reader.onload = (e)=> finalize(e.target.result);
                    reader.readAsDataURL(file);
                } else {
                    finalize(null);
                }
            };
        }

        function openMyListForEdit(){
            const list = $id('myEditList');
            if (!list) return;
            list.innerHTML = '';

            const myBooks = window.books.map((b,i)=>({...b,_idx:i})).filter(b=> b.ownerId === window.currentUserId);
            if(myBooks.length===0){ alert('내가 등록한 도서가 없습니다.'); return; }

            myBooks.forEach(b=>{
                const card = document.createElement('div');
                card.className = 'vcard';
                card.innerHTML = `
          <img src="${b.img || 'https://via.placeholder.com/200x150'}" alt="">
          <div class="meta">
            <div class="title">${escapeHtml(b.title || '')}</div>
            <div class="muted">${escapeHtml(b.instructor || '')}</div>
            <div class="muted">${escapeHtml(b.desc || '')}</div>
          </div>
          <div class="actions">
            <button class="btn-primary" type="button">수정</button>
          </div>`;
                card.querySelector('.btn-primary')?.addEventListener('click', ()=>{
                    myEditOverlay.style.display='none';
                    cameFromEditList = true;
                    openModal(window.books[b._idx], b._idx);
                });
                list.appendChild(card);
            });

            myEditOverlay.style.display='flex';
        }

        function openDeleteModal(){
            const listDiv = $id('deleteList');
            if (!listDiv) return;
            listDiv.innerHTML='';

            const myBooks = window.books.map((b,i)=>({...b,_idx:i})).filter(b=> b.ownerId === window.currentUserId);
            if(myBooks.length===0){ alert('내가 등록한 도서가 없습니다.'); return; }

            myBooks.forEach(b=>{
                const card = document.createElement('div');
                card.className = 'vcard';
                card.innerHTML = `
          <img src="${b.img || 'https://via.placeholder.com/200x150'}" alt="">
          <div class="meta">
            <div class="title">${escapeHtml(b.title || '')}</div>
            <div class="muted">${escapeHtml(b.instructor || '')}</div>
          </div>
          <div class="select">
            <input type="checkbox" value="${b._idx}" id="chk-${b._idx}">
            <label for="chk-${b._idx}">선택</label>
          </div>`;
                listDiv.appendChild(card);
            });

            deleteOverlay.style.display='flex';
        }

        $id('deleteConfirmBtn')?.addEventListener('click', ()=>{
            const checked = document.querySelectorAll('#deleteList input[type="checkbox"]:checked');
            if(checked.length===0){ alert('삭제할 도서를 선택하세요.'); return; }
            const indexes=[...checked].map(c=>parseInt(c.value,10)).sort((a,b)=>b-a);
            indexes.forEach(i=>{
                if(window.books[i]?.ownerId === window.currentUserId){
                    window.books.splice(i,1);
                    // TODO: DELETE /books/{id}
                }
            });
            deleteOverlay.style.display='none';
            window.renderCards?.();
            window.renderPagination?.();
        });

        function escapeHtml(s){
            return String(s).replace(/[&<>"']/g, m=> ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
        }
    });
})();
