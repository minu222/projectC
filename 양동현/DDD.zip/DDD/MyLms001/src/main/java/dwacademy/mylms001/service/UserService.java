package dwacademy.mylms001.service;

import dwacademy.mylms001.entity.User;
import dwacademy.mylms001.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    // 비밀번호 해시를 쓰면 주입받아 사용 (없으면 주석)
    // private final PasswordEncoder passwordEncoder;

    public Optional<User> login(String nickname, String rawPassword) {
        return userRepository.findByNickname(nickname)
                .filter(u -> Objects.equals(u.getPassword(), rawPassword));
        // 해시 사용 시: .filter(u -> passwordEncoder.matches(rawPassword, u.getPassword()));
    }

    @Transactional
    public long register(User u, String affiliation, String bio) {
        // 해시 사용 시
        // u.setPassword(passwordEncoder.encode(u.getPassword()));

        long userId = userRepository.insertUser(u);
        if (u.getRole() == User.Role.INSTRUCTOR) {
            userRepository.insertInstructorProfile((int) userId, affiliation, bio);
        }
        return userId;
    }
}