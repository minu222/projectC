package com.example.mylms01.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/course")
public class CourseController {

    /**
     * 공통 모델 설정 메서드
     * @param model Spring Model 객체
     * @param fragment Thymeleaf fragment 경로
     * @param title 페이지 제목
     * @return layout 템플릿명
     */
    private String setupModel(Model model, String fragment, String title) {
        model.addAttribute("bodyFragment", fragment);
        model.addAttribute("title", title);
        model.addAttribute("activeCategory", "course");
        model.addAttribute("userRole", "guest");
        model.addAttribute("showSidebar", true); // 사이드바 표시
        return "layout";
    }

    /**
     * 교육과정 메인 페이지
     * URL: /course
     */
    @GetMapping
    public String coursePage(Model model) {
        return setupModel(model,
                "course/course :: content",
                "교육과정"
        );
    }

    /**
     * 강의목록 페이지
     * URL: /course/lecture
     */
    @GetMapping("/lecture")
    public String courseLecture(Model model) {
        return setupModel(model,
                "course/courseLecture :: content",
                "교육강의 - 강의목록"
        );
    }

    /**
     * 이과 강의소개 페이지
     * URL: /course/introduction/science
     */
    @GetMapping("/introduction/science")
    public String courseIntroScience(Model model) {
        return setupModel(model,
                "course/courseIntroScience :: content",
                "강의소개 - 이과"
        );
    }

    /**
     * 문과 강의소개 페이지
     * URL: /course/introduction/liberal
     */
    @GetMapping("/introduction/liberal")
    public String courseIntroLiberal(Model model) {
        return setupModel(model,
                "course/courseIntroLiberal :: content",
                "강의소개 - 문과"
        );
    }

    /**
     * 예체능 강의소개 페이지
     * URL: /course/introduction/arts
     */
    @GetMapping("/introduction/arts")
    public String courseIntroArts(Model model) {
        return setupModel(model,
                "course/courseIntroArts :: content",
                "강의소개 - 예체능"
        );
    }
}