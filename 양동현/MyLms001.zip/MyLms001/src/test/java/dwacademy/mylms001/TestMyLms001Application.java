package dwacademy.mylms001;

import org.springframework.boot.SpringApplication;

public class TestMyLms001Application {

    public static void main(String[] args) {
        SpringApplication.from(MyLms001Application::main).with(TestcontainersConfiguration.class).run(args);
    }

}
