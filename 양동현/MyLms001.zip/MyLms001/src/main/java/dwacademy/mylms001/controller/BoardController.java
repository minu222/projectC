package dwacademy.mylms001.controller;

import dwacademy.mylms001.board.BoardType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;

@Controller
@RequestMapping("/board")
public class BoardController {

    /** 공통 모델 셋업 (레이아웃에 프래그먼트 주입) */
    private String setupBoardModel(Model model, String fragment, String title) {
        model.addAttribute("bodyFragment", fragment);
        model.addAttribute("title", title);
        model.addAttribute("showSidebar", true); // 사이드바 표시
        model.addAttribute("userRole", "guest");
        model.addAttribute("activeCategory", "board");
        return "layout";
    }

    /** 목록/상세 템플릿에서 공통으로 쓰는 보드 타입 슬러그 제공 */
    private void setTypeSlug(Model model, BoardType bt) {
        model.addAttribute("typeSlug", bt.slug());
    }

    /* ====================== 목록 라우트 ====================== */

    /** /board → 공지 목록으로 라우팅 */
    @GetMapping
    public String boardPage(Model model) {
        setTypeSlug(model, BoardType.NOTICE);
        model.addAttribute("posts", Collections.emptyList()); // [DB] 목록 채우기 전 안전값
        return setupBoardModel(model, BoardType.NOTICE.listFragment(), "MyLms");
    }

    /** /board/notice */
    @GetMapping("/notice")
    public String noticeBoard(Model model) {
        setTypeSlug(model, BoardType.NOTICE);
        model.addAttribute("posts", Collections.emptyList()); // [DB] noticeService.findAll()
        return setupBoardModel(model, BoardType.NOTICE.listFragment(), "MyLms");
    }

    /** /board/faq */
    @GetMapping("/faq")
    public String faqBoard(Model model) {
        setTypeSlug(model, BoardType.FAQ);
        model.addAttribute("posts", Collections.emptyList()); // [DB] faqService.findAll()
        return setupBoardModel(model, BoardType.FAQ.listFragment(), "MyLms");
    }

    /** /board/free */
    @GetMapping("/free")
    public String freeBoard(Model model) {
        setTypeSlug(model, BoardType.FREE);
        model.addAttribute("posts", Collections.emptyList()); // [DB] freeService.findAll()
        return setupBoardModel(model, BoardType.FREE.listFragment(), "MyLms");
    }

    /** /board/qna */
    @GetMapping("/qna")
    public String qnaBoard(Model model) {
        setTypeSlug(model, BoardType.QNA);
        model.addAttribute("posts", Collections.emptyList()); // [DB] qnaService.findAll()
        return setupBoardModel(model, BoardType.QNA.listFragment(), "MyLms");
    }

    /** /board/courseReview */
    @GetMapping("/courseReview")
    public String courseReview(Model model) {
        setTypeSlug(model, BoardType.COURSE_REVIEW);
        model.addAttribute("posts", Collections.emptyList()); // [DB] reviewService.findAllCourseReviews()
        return setupBoardModel(model, BoardType.COURSE_REVIEW.listFragment(), "MyLms");
    }

    /** /board/teacherReview */
    @GetMapping("/teacherReview")
    public String teacherReview(Model model) {
        setTypeSlug(model, BoardType.TEACHER_REVIEW);
        model.addAttribute("posts", Collections.emptyList()); // [DB] reviewService.findAllTeacherReviews()
        return setupBoardModel(model, BoardType.TEACHER_REVIEW.listFragment(), "MyLms");
    }

    /* ====================== 상세 라우트(통합) ====================== */

    /** 제목 클릭 → 상세: /board/{type}/{id} */
    @GetMapping("/{type}/{id}")
    public String boardDetail(@PathVariable String type,
                              @PathVariable Long id,
                              Model model) {
        BoardType bt = BoardType.from(type);

        // [DB] 여기서 실제 상세 데이터 조회해서 post로 넣어주세요.
        // Object post;
        // switch (bt) {
        //   case NOTICE -> post = noticeService.findById(id);
        //   case FAQ    -> post = faqService.findById(id);
        //   case FREE   -> post = freeService.findById(id);
        //   case QNA    -> post = qnaService.findById(id);
        //   case TEACHER_REVIEW, COURSE_REVIEW -> post = reviewService.findById(id);
        //   default -> post = null;
        // }
        Object post = null; // 서비스 연동 전 안전값

        model.addAttribute("post", post);
        setTypeSlug(model, bt); // 상세에서 "목록으로" 링크용 (/board/{typeSlug})
        return setupBoardModel(model, bt.detailFragment(), "MyLms");
    }
}
