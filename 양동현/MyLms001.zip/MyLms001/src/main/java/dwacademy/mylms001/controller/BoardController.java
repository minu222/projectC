package dwacademy.mylms001.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/board")
public class BoardController {

    /**
     * 게시판 공통 모델 설정 메서드
     * @param model Spring Model 객체
     * @param fragment Thymeleaf fragment 경로
     * @param title 페이지 제목
     * @return layout 템플릿명
     */
    private String setupBoardModel(Model model, String fragment, String title) {
        model.addAttribute("bodyFragment", fragment);
        model.addAttribute("title", title);
        model.addAttribute("showSidebar", true); // 사이드바 표시
        model.addAttribute("userRole", "guest");
        model.addAttribute("activeCategory", "board");
        return "layout";
    }

    /**
     * 게시판 메인 페이지
     * URL: /board
     */
    @GetMapping
    public String boardPage(Model model) {
        return setupBoardModel(model,
                "board/board :: content",  // boardContent → content로 변경
                "MyLms"
        );
    }

    /**
     * 공지사항 게시판
     * URL: /board/notice
     */
    @GetMapping("/notice")
    public String noticeBoard(Model model) {
        return setupBoardModel(model,
                "board/noticeBoard :: content",
                "MyLms"
        );
    }

    /**
     * FAQ 게시판
     * URL: /board/faq
     */
    @GetMapping("/faq")
    public String faqBoard(Model model) {
        return setupBoardModel(model,
                "board/faqBoard :: content",
                "MyLms"
        );
    }

    /**
     * 자유게시판
     * URL: /board/free
     */
    @GetMapping("/free")
    public String freeBoard(Model model) {
        return setupBoardModel(model,
                "board/freeBoard :: content",
                "MyLms"
        );
    }

    /**
     * 문의게시판
     * URL: /board/qna
     */
    @GetMapping("/qna")
    public String qnaBoard(Model model) {
        return setupBoardModel(model,
                "board/qnaBoard :: content",
                "MyLms"
        );
    }

    /**
     * 강의 후기 게시판
     * URL: /board/courseReview
     */
    @GetMapping("/courseReview")
    public String courseReview(Model model) {
        return setupBoardModel(model,
                "board/courseReview :: content",
                "MyLms"
        );
    }

    /**
     * 강사 후기 게시판
     * URL: /board/teacherReview
     */
    @GetMapping("/teacherReview")
    public String teacherReview(Model model) {
        return setupBoardModel(model,
                "board/teacherReview :: content",
                "MyLms"
        );
    }
}