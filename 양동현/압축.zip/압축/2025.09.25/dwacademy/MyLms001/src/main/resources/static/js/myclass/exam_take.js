// exam_take.js
// 페이지 진입 → eligibility → start(50분 서버 타이머) → questions → 화면 렌더
// 제출(수동/자동) → 서버 자동채점 → mock_exam_results 저장

(function () {
    const API = {
        elig:  (examId, courseTitle) =>
            fetch(`/api/compat/my/exams/${encodeURIComponent(examId)}/eligibility?courseTitle=${encodeURIComponent(courseTitle)}`, {credentials:'same-origin'}).then(r=>r.json()),
        start: (examId, courseTitle) =>
            fetch(`/api/compat/exams/${encodeURIComponent(examId)}/start?courseTitle=${encodeURIComponent(courseTitle)}`, {method:'POST', credentials:'same-origin'}).then(r=>r.json()),
        q:     (courseTitle) =>
            fetch(`/api/compat/exams/by-course/${encodeURIComponent(courseTitle)}/questions`, {credentials:'same-origin'}).then(r=>r.json()),
        submit:(courseTitle, payload) =>
            fetch(`/api/compat/exams/by-course/${encodeURIComponent(courseTitle)}/submit`, {
                method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin', body: JSON.stringify(payload)
            }).then(r=>r.json()),
    };

    const bodyEl = document.getElementById('examBody');
    const timerEl = document.getElementById('timer');
    const btnSubmit = document.getElementById('btnSubmit');
    const btnCancel = document.getElementById('btnCancel');

    let attemptId = null;
    let questions = [];
    let endAt = 0;
    let ticking = null;

    init().catch(err => {
        console.error(err);
        alert('시험 로딩 실패'); window.history.back();
    });

    async function init() {
        // 0) 응시 가능 여부
        const g = await API.elig(EXAM_ID, COURSE_TITLE);
        if (!g.ok) throw new Error(g.message || '로그인이 필요합니다.');
        if (g.allowed === false && g.reason === 'ALREADY_SUBMITTED') {
            alert('이미 제출하신 시험입니다.');
            window.history.back();
            return;
        }

        // 1) 시작/토큰
        const s = await API.start(EXAM_ID, COURSE_TITLE);
        if (!s.ok) throw new Error(s.message || '시험 시작 실패');
        attemptId = s.attemptId;
        endAt = new Date(s.expiresAt).getTime();

        // 2) 문제
        const q = await API.q(COURSE_TITLE);
        if (!q.ok || !Array.isArray(q.items) || q.items.length === 0) throw new Error('문제를 불러오지 못했습니다.');
        questions = q.items;

        renderQuestions(questions);
        startTimer();
    }

    function renderQuestions(items) {
        bodyEl.innerHTML = items.map((q, idx) => `
      <article>
        <div class="qtitle">Q${idx+1}. ${escapeHtml(String(q.question ?? ''))}</div>
        <div class="opts">
          ${(q.options || []).map((op, i) => `
            <label class="opt">
              <input type="radio" name="q_${q.id}" value="${i+1}">
              <span>${escapeHtml(String(op ?? ''))}</span>
            </label>
          `).join('')}
        </div>
      </article>
    `).join('');
    }

    function startTimer() {
        if (ticking) clearInterval(ticking);
        ticking = setInterval(async () => {
            const now = Date.now();
            const remain = Math.max(0, Math.floor((endAt - now)/1000));
            timerEl.textContent = `${String(Math.floor(remain/60)).padStart(2,'0')}:${String(remain%60).padStart(2,'0')}`;

            if (remain <= 0) {
                clearInterval(ticking);
                btnSubmit.disabled = true;
                // 자동 제출
                try {
                    const answers = collectAnswers();
                    const res = await API.submit(COURSE_TITLE, { attemptId, examId: EXAM_ID, courseTitle: COURSE_TITLE, answers });
                    if (res.ok) alert(`시간 종료로 자동 제출되었습니다.\n점수: ${res.score}/${res.total}`);
                    else alert(res.message || '시간 종료');
                } catch (e) {
                    console.error(e);
                    alert('자동 제출 중 오류');
                } finally {
                    // 시험 페이지 종료 (목록 페이지로 보내고 싶으면 URL 교체)
                    window.history.back();
                }
            }
        }, 500);
    }

    btnSubmit.onclick = async () => {
        btnSubmit.disabled = true;
        try {
            const answers = collectAnswers();
            const res = await API.submit(COURSE_TITLE, { attemptId, examId: EXAM_ID, courseTitle: COURSE_TITLE, answers });
            if (!res.ok) { alert(res.message || '제출 실패'); btnSubmit.disabled = false; return; }
            alert(`제출 완료! 점수: ${res.score}/${res.total}`);
            // 여기서는 정답/오답 노출하지 않습니다. (요청 사항)
            window.history.back();
        } catch (e) {
            console.error(e); alert('제출 중 오류'); btnSubmit.disabled = false;
        }
    };

    btnCancel.onclick = () => {
        if (confirm('정말 나가시겠습니까? (제출 전에는 저장되지 않습니다)')) window.history.back();
    };

    function collectAnswers() {
        return questions.map(q => {
            const sel = document.querySelector(`input[name="q_${q.id}"]:checked`);
            return { questionId: q.id, choice: sel ? sel.value : null };
        });
    }

    function escapeHtml(s){return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));}
})();
