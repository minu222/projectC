// /static/js/examModal.js
(function () {
    'use strict';

    // 외부에서 호출:
    //   openExamModal({ examId?, courseId?, courseTitle, instructorName, studentName })
    window.openExamModal = async function (opts) {
        const { examId, courseId, courseTitle, instructorName, studentName } = opts || {};
        if (!examId && !courseId) { alert('examId 또는 courseId가 필요합니다.'); return; }

        // 중복 오픈 방지
        const old = document.getElementById('exam-modal');
        if (old) old.remove();

        // 모달 DOM 생성
        const wrap = document.createElement('div');
        wrap.id = 'exam-modal';
        wrap.setAttribute('role','dialog');
        wrap.setAttribute('aria-modal','true');
        wrap.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:10000;';

        wrap.innerHTML = `
    <div class="exam-dialog" role="document" aria-labelledby="exam-title">
      <style>
        :root{ --brand:#ffb400; --bg:#f7f7fb; --card:#fff; --text:#222; --border:#e9ecef; }
        .exam-dialog{ width:min(1200px,94vw); max-height:92vh; background:#fff; border-radius:16px;
                      box-shadow:0 20px 60px rgba(0,0,0,.25); overflow:hidden; display:grid;
                      grid-template-rows:auto 1fr auto; font-family:inherit; }
        .exam-header{ background:linear-gradient(180deg, var(--brand), #ffc84d); padding:16px 20px; }
        .exam-title{ margin:0; color:#1d1d1d; font-size:22px; font-weight:800; line-height:1.2; }
        .exam-meta{ margin-top:6px; display:flex; gap:10px; flex-wrap:wrap; font-weight:600; font-size:14px; color:#2a2a2a; }
        .exam-body{ background:var(--bg); padding:20px; overflow:auto; }
        .grid{ display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:16px; }
        @media (max-width:900px){ .grid{ grid-template-columns:1fr; } }
        .card{ background:#fff; border:1px solid var(--border); border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,.06); padding:16px; }
        .qtitle{ font-weight:700; margin-bottom:10px; }
        .qtext{ color:#333; margin-bottom:12px; }
        .opts{ display:grid; gap:8px; }
        .opt{ display:flex; gap:10px; align-items:flex-start; padding:10px 12px; border:1px solid var(--border);
              border-radius:10px; background:#fff; transition:box-shadow .15s, border-color .15s; cursor:pointer; }
        .opt:hover{ box-shadow:0 6px 16px rgba(0,0,0,.06); }
        .opt input{ margin-top:2px; }
        .opt .label{ line-height:1.4; color:#222; }
        .opt input:checked + .label{ outline:2px solid var(--brand); outline-offset:2px; border-radius:6px; padding:1px 2px; }
        .exam-footer{ background:linear-gradient(180deg, #ffe3f0, #ffc6df); padding:12px 16px; display:flex; justify-content:flex-end; gap:10px; }
        .btn{ padding:10px 16px; border-radius:10px; border:1px solid #e9ecef; background:#fff; font-weight:700; cursor:pointer; }
        .btn-primary{ background:var(--brand); border-color:var(--brand); color:#111; font-weight:800; }
        .visually-hidden{ position:absolute !important; width:1px; height:1px; margin:-1px; overflow:hidden; clip:rect(0 0 0 0); }
      </style>

      <header class="exam-header">
        <h2 id="exam-title" class="exam-title"></h2>
        <div class="exam-meta">
          <span><b>강사</b> <em id="exam-instructor"></em></span>
          <span>•</span>
          <span><b>학생</b> <em id="exam-student"></em></span>
          <span>•</span>
          <span><b>점수</b> <em id="exam-score">0</em> / <em id="exam-total">0</em></span>
        </div>
      </header>

      <main class="exam-body">
        <div id="exam-questions" class="grid"></div>
      </main>

      <footer class="exam-footer">
        <button type="button" id="exam-submit" class="btn btn-primary">제출하기</button>
        <button type="button" id="exam-close"  class="btn">닫기</button>
      </footer>
    </div>`;

        document.body.appendChild(wrap);

        // 내부 참조
        const $ = sel => wrap.querySelector(sel);
        const questionsBox = $('#exam-questions');
        const btnSubmit = $('#exam-submit');
        const btnClose  = $('#exam-close');

        // 헤더 채우기
        $('#exam-title').textContent      = courseTitle || '시험';
        $('#exam-instructor').textContent = instructorName || '-';
        $('#exam-student').textContent    = studentName || '';

        // 스크롤 잠금
        const prevOverflow = document.documentElement.style.overflow || '';
        document.documentElement.style.overflow = 'hidden';

        // 보호: 오버레이 클릭/ESC로는 닫히지 않음
        wrap.addEventListener('click', (e)=>{ /* 배경 클릭 무시 */ });
        const dlg = wrap.querySelector('.exam-dialog');
        dlg.addEventListener('click', (e)=> e.stopPropagation());
        const keyBlock = (e)=>{
            const k = (e.key||'').toLowerCase();
            if (k === 'escape' || k === 'esc') e.preventDefault();
            if (k === 'backspace' && !['input','textarea'].includes((e.target.tagName||'').toLowerCase())) e.preventDefault();
            if (e.altKey && (k === 'arrowleft' || k === 'left')) e.preventDefault();
        };
        document.addEventListener('keydown', keyBlock, true);
        const beforeUnload = (e)=>{ e.preventDefault(); e.returnValue=''; return ''; };
        window.addEventListener('beforeunload', beforeUnload);

        // 닫기 함수(버튼에서만 호출)
        function forceClose(){
            window.removeEventListener('beforeunload', beforeUnload);
            document.removeEventListener('keydown', keyBlock, true);
            document.documentElement.style.overflow = prevOverflow;
            wrap.remove();
        }

        // 문제 로드
        try {
            const url = examId
                ? `/api/exams/${encodeURIComponent(examId)}/questions`
                : `/api/exams/by-course/${encodeURIComponent(courseId)}/questions`;
            const res = await fetch(url, { headers:{Accept:'application/json'} });
            if (!res.ok) throw new Error('문제 조회 실패');
            const list = await res.json(); // [{id,question,options:[...],score:10}, ...]

            renderQuestions(list);
            calcTotal(list);

            // 제출/닫기
            btnSubmit.onclick = ()=> submitExam(examId || courseId, list, !!examId, forceClose);
            btnClose .onclick = ()=> { if (confirm('정말 닫을까요? 진행 내용이 사라질 수 있습니다.')) forceClose(); };

            // 첫 포커스
            const first = wrap.querySelector('input[type="radio"]') || btnClose;
            first && first.focus();

        } catch (e){
            console.error(e);
            alert('문제를 불러오지 못했습니다.');
            forceClose();
        }

        // ===== 내부 함수들 =====
        function renderQuestions(list){
            questionsBox.innerHTML = '';
            list.forEach((q, idx) => {
                const qId = q.id ?? idx + 1;
                const score = q.score ?? 0;
                const card = document.createElement('article');
                card.className = 'card';
                card.innerHTML = `
          <div class="qtitle">문항 ${idx + 1} <small style="color:#888;font-weight:600">(${score}점)</small></div>
          <div class="qtext">${escapeHtml(q.question || '')}</div>
          <div class="opts" role="group" aria-label="문항 ${idx + 1} 선택지">
            ${renderOptions(qId, q.options || [])}
          </div>`;
                card.addEventListener('change', () => updateScore(list));
                questionsBox.appendChild(card);
            });

            // 포커스 순환용 sentry (접근성)
            const start = document.createElement('span'); start.className='visually-hidden'; start.tabIndex=0;
            const end   = document.createElement('span'); end.className='visually-hidden';   end.tabIndex=0;
            start.addEventListener('focus', ()=> { (btnClose || questionsBox.querySelector('input'))?.focus(); });
            end  .addEventListener('focus', ()=> { (questionsBox.querySelector('input') || btnClose)?.focus(); });
            dlg.prepend(start); dlg.append(end);
        }

        function renderOptions(qId, opts){
            const marks = ['①','②','③','④','⑤','⑥'];
            return opts.map((text, i)=>`
        <label class="opt">
          <input type="radio" name="q_${qId}" value="${i}">
          <span class="label"><b>${marks[i] || String.fromCharCode(65+i)}</b> ${escapeHtml(text || '')}</span>
        </label>
      `).join('');
        }

        function calcTotal(list){
            const total = list.reduce((s,q)=> s + (q.score||0), 0);
            $('#exam-total').textContent = total;
            updateScore(list);
        }

        function updateScore(list){
            let current = 0;
            list.forEach(q=>{
                const chosen = wrap.querySelector(`input[name="q_${q.id}"]:checked`);
                if (chosen) current += (q.score || 0);
            });
            $('#exam-score').textContent = current;
        }

        async function submitExam(idOrCourseId, list, hasExamId, onClose){
            const unanswered = [];
            const answers = list.map(q=>{
                const chosen = wrap.querySelector(`input[name="q_${q.id}"]:checked`);
                if (!chosen) unanswered.push(q);
                return { questionId: q.id, answerIndex: chosen ? Number(chosen.value) : null };
            });

            if (unanswered.length){
                const ok = confirm(`미답변 문항이 ${unanswered.length}개 있습니다. 제출할까요?`);
                if (!ok) return;
            }

            btnSubmit.disabled = true;

            try{
                const url = hasExamId
                    ? `/api/exams/${encodeURIComponent(idOrCourseId)}/submit`
                    : `/api/exams/by-course/${encodeURIComponent(idOrCourseId)}/submit`;

                const res = await fetch(url, {
                    method:'POST',
                    headers:{'Content-Type':'application/json', Accept:'application/json'},
                    body: JSON.stringify({ answers })
                });
                if (res.status === 401){ alert('로그인이 필요합니다.'); location.href='/user/login'; return; }
                if (!res.ok) throw new Error('제출 실패');

                const result = await res.json(); // { ok:true, score, total, message }
                alert(result.message || `제출 완료! 점수: ${result.score}/${result.total}`);
                onClose(); // 제출 성공 시에만 닫기
            }catch(e){
                console.error(e);
                alert('제출 중 오류가 발생했습니다.');
                btnSubmit.disabled = false;
            }
        }

        function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }
    };
})();
