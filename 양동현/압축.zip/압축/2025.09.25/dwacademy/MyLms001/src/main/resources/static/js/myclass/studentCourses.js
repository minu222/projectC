// src/main/resources/static/js/myclass/studentCourses.js
// ✅ enrollments(수강등록) 기준으로 "수강중(progress)" 렌더
(function () {
    'use strict';

    /** ====== DOM ====== */
    const $id = (id) => document.getElementById(id);
    const courseGrid   = $id('courseGrid');
    const pagination   = $id('pagination');
    const filterSelect = $id('filter');
    const searchInput  = $id('searchInput');
    const searchBtn    = $id('searchBtn');

    /** ====== 상태 ====== */
    const PER_PAGE = 9;
    let currentPage = 1;
    let rawItems = [];
    let viewItems = [];

    /** ====== 유틸 ====== */
    function escapeHtml(s) {
        return String(s ?? '').replace(/[&<>"']/g, (m) => ({
            '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
        }[m]));
    }
    function buildPeriod(start, end){
        if (!start && !end) return '-';
        const fmt = (v)=> v ? new Date(v).toISOString().slice(0,10) : '';
        return `${fmt(start)} ~ ${fmt(end)}`;
    }
    function clamp(n, min, max){ return Math.max(min, Math.min(max, n)); }
    function formatWon(v) {
        const n = Number(v ?? 0) || 0;
        return n.toLocaleString('ko-KR') + '원';
    }

    /** ====== 서버에서 enrollments 불러오기 ====== */
    async function loadFromEnrollments() {
        if (courseGrid) {
            courseGrid.innerHTML = '<p style="padding:16px;color:#666;">불러오는 중...</p>';
        }
        try {
            const res = await fetch('/api/enrollments/my', { headers: { 'Accept': 'application/json' } });
            if (res.status === 401) throw new Error('로그인이 필요합니다.');
            if (!res.ok) throw new Error('목록 조회에 실패했습니다.');

            const data = await res.json();

            // enrollments + courses(+users) 조인 결과를 화면 모델로 변환
            rawItems = Array.isArray(data) ? data.map(row => {
                const title    = row.title || '(제목 없음)';
                const teacher  = row.instructor_name || '';           // 표시용
                const teacherNick = row.instructor_nickname || teacher; // ✅ 닉네임 우선
                const period   = buildPeriod(row.enrolled_at, row.expired_at);
                const progress = 0; // 추적 전이면 0 (추후 course_progress 연동)
                const isFree   = !!row.is_free && (row.is_free === 1 || String(row.is_free).toLowerCase() === 'true');
                return {
                    id: row.course_id,
                    title,
                    teacher,
                    teacherNick, // ✅ 시험 조회 파라미터용
                    period,
                    score: 0,
                    progress,
                    thumb: row.thumbnail_url || '',
                    lastAccess: row.last_access_at || row.enrolled_at,
                    purchaseDate: row.enrolled_at,
                    price: isFree ? 0 : (row.price || 0),
                    isFree,
                    status: 'progress'
                };
            }) : [];

            applyAndRender();
        } catch (e) {
            console.error(e);
            if (courseGrid) courseGrid.innerHTML = '<p style="padding:16px;color:#b40000;">목록을 불러오지 못했습니다.</p>';
        }
    }

    /** ====== 필터링 & 렌더링 ====== */
    function getFiltered() {
        let items = [...rawItems];

        // 검색(강의명/강사명)
        const keyword = (searchInput?.value || '').trim().toLowerCase();
        if (keyword) {
            items = items.filter(c =>
                c.title.toLowerCase().includes(keyword) ||
                (c.teacher || '').toLowerCase().includes(keyword)
            );
        }

        // 필터
        const filter = filterSelect?.value || 'all';
        if (filter === 'progress') {
            items = items.filter(c => c.status === 'progress');
        } else if (filter === 'completed') {
            items = items.filter(c => c.status === 'completed'); // 추후 수료 연동
        } else if (filter === 'purchase') {
            items.sort((a, b) => new Date(b.purchaseDate) - new Date(a.purchaseDate)); // 최신 수강등록순
        } else if (filter === 'recent') {
            items.sort((a, b) => new Date(b.lastAccess) - new Date(a.lastAccess));     // 최근 수강순
        }
        return items;
    }

    function applyAndRender() {
        viewItems = getFiltered();
        currentPage = 1;
        render();
    }

    function render() {
        if (!courseGrid) return;

        const total = viewItems.length;
        const totalPages = Math.max(1, Math.ceil(total / PER_PAGE));
        currentPage = clamp(currentPage, 1, totalPages);
        const start = (currentPage - 1) * PER_PAGE;
        const pageItems = viewItems.slice(start, start + PER_PAGE);

        if (total === 0) {
            courseGrid.innerHTML = `
              <div style="padding:24px;color:#667085;">수강 중인 강의가 없습니다.</div>
            `;
            pagination && (pagination.innerHTML = '');
            return;
        }

        courseGrid.innerHTML = pageItems.map((c) => `
          <article class="course-card">
            <div class="thumb" style="aspect-ratio:16/9;background:#f2f2f2;border:1px solid #eee;border-radius:8px;overflow:hidden;">
              ${c.thumb ? `<img src="${escapeHtml(c.thumb)}" alt="">` : ''}
            </div>
            <div class="info">
              <h3 class="title">${escapeHtml(c.title)}</h3>
              <div class="meta">
                <span>${escapeHtml(c.teacher || '')}</span>
                <span style="opacity:.5">•</span>
                <span>${escapeHtml(c.period || '-')}</span>
              </div>
            </div>
            <div class="actions">
              <button type="button"
                      class="btn"
                      data-popup="lecture"
                      data-course-id="${encodeURIComponent(c.id)}">
                강의실 입장
              </button>

              <!-- ✅ 시험보기: 시험 페이지로 이동 -->
              <button type="button"
                      class="btn-exam"
                      data-exam="open"
                      data-course-id="${encodeURIComponent(c.id)}"
                      data-title="${escapeHtml(c.title)}"
                      data-teacher="${escapeHtml(c.teacher || '')}"
                      data-teacher-nick="${escapeHtml(c.teacherNick || '')}">
                시험보기
              </button>

              <button type="button" class="btn" data-link="/review/course/${encodeURIComponent(c.id)}">강의후기 작성</button>
              <button type="button" class="btn" data-link="/review/instructor/${encodeURIComponent(c.id)}">강사후기 작성</button>
            </div>
          </article>
        `).join('');

        // 페이지네이션
        if (pagination) {
            pagination.innerHTML = `
              <div class="pagin">
                <button type="button" ${currentPage===1?'disabled':''} data-page="1">«</button>
                <button type="button" ${currentPage===1?'disabled':''} data-page="${currentPage-1}">‹</button>
                <span>${currentPage} / ${totalPages}</span>
                <button type="button" ${currentPage===totalPages?'disabled':''} data-page="${currentPage+1}">›</button>
                <button type="button" ${currentPage===totalPages?'disabled':''} data-page="${totalPages}">»</button>
              </div>
            `;
            pagination.querySelectorAll('button[data-page]').forEach(btn=>{
                btn.addEventListener('click', ()=>{
                    const p = Number(btn.getAttribute('data-page'));
                    currentPage = clamp(p, 1, totalPages);
                    render();
                });
            });
        }
    }

    /** ====== 팝업 유틸(강의실) ====== */
    const _popupRefs = {};
    function openCenteredPopup(url, name, width = 1100, height = 800) {
        const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : window.screenX;
        const dualScreenTop  = window.screenTop  !== undefined ? window.screenTop  : window.screenY;
        const w = window.innerWidth  || document.documentElement.clientWidth  || screen.width;
        const h = window.innerHeight || document.documentElement.clientHeight || screen.height;
        const left = (w - width) / 2 + dualScreenLeft;
        const top  = (h - height) / 2 + dualScreenTop;

        const features = `scrollbars=yes,resizable=yes,width=${width},height=${height},top=${top},left=${left}`;

        if (_popupRefs[name] && !_popupRefs[name].closed) {
            _popupRefs[name].focus();
            _popupRefs[name].location.href = url;
            return _popupRefs[name];
        }

        const win = window.open(url, name, features);
        if (!win) {
            alert('브라우저에서 팝업이 차단되었습니다. 사이트의 팝업을 허용해 주세요.');
            return null;
        }
        _popupRefs[name] = win;
        return win;
    }

    /** ====== 클릭 이벤트 위임 ====== */
    document.addEventListener('click', (e) => {
        // 강의실 입장(팝업)
        const enterBtn = e.target.closest('[data-popup="lecture"]');
        if (enterBtn) {
            e.preventDefault();
            e.stopPropagation();
            const courseId = enterBtn.getAttribute('data-course-id');
            const url = `/myclass/lectureroom?courseId=${encodeURIComponent(courseId)}&popup=1`;
            const win = openCenteredPopup(url, `lectureRoom-${courseId}`, 1100, 800);
            if (win) { try { win.focus(); } catch (_) {} }
            return;
        }

        // ✅ 시험보기 → 시험 페이지로 이동
        const examBtn = e.target.closest('[data-exam="open"]');
        if (examBtn) {
            e.preventDefault();
            e.stopPropagation();

            const courseId    = examBtn.getAttribute('data-course-id');
            const title       = examBtn.getAttribute('data-title')        || '시험';
            const teacherNick = examBtn.getAttribute('data-teacher-nick') || examBtn.getAttribute('data-teacher') || '';

            if (!teacherNick) {
                alert('강사 닉네임 정보를 찾을 수 없어 시험 페이지를 열 수 없습니다.');
                return;
            }
            // ✅ API가 요구하는 파라미터명으로 전달 (courseTitle → course)
            const q = new URLSearchParams({
                instructorNickname: teacherNick,
                course: title
            });
            window.location.href = `/exam/take?${q.toString()}`;
            return;
        }

        // 일반 링크 이동
        const go = e.target.closest('[data-link]');
        if (go) {
            const href = go.getAttribute('data-link');
            if (href) window.location.href = href;
        }
    });

    // 필터/검색 이벤트
    filterSelect && filterSelect.addEventListener('change', applyAndRender);
    searchBtn    && searchBtn.addEventListener('click', applyAndRender);
    searchInput  && searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') applyAndRender();
    });

    // ✅ 최초 로드
    document.addEventListener('DOMContentLoaded', loadFromEnrollments);
})();
