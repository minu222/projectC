package dwacademy.mylms001.dto;

import java.time.OffsetDateTime;
import java.util.List;

public class CompatDtos {
    public record Eligibility(boolean ok, Boolean allowed, String reason, String message) {}

    public record StartResp(boolean ok, Long attemptId, OffsetDateTime expiresAt, String message) {}

    public record QuestionItem(Long id, String question, List<String> options, Integer score) {}
    public record QuestionsResp(boolean ok, List<QuestionItem> items) {}

    public record Answer(Long questionId, Integer choice) {}
    public record SubmitReq(Long attemptId, Long examId, String courseTitle, List<Answer> answers) {}
    public record SubmitResp(boolean ok, int score, int total, String message) {}
}
