// /js/myclass/exam_compat.js
// ✅ 기존 코드/HTML 수정 없이 동작하도록 설계된 '호환 모달 + 타이머 + 1회 제한 + 자동채점/저장'
//  - 서버 엔드포인트: /api/compat/* (ExamCompatController)
//  - 시험시간: 50분 (서버+클라이언트 동시검증)

(() => {
    const API = {
        elig:      (examId, courseTitle) =>
            fetch(`/api/compat/my/exams/${encodeURIComponent(examId)}/eligibility?courseTitle=${encodeURIComponent(courseTitle)}`, {credentials:'same-origin'}).then(r=>r.json()),
        start:     (examId, courseTitle) =>
            fetch(`/api/compat/exams/${encodeURIComponent(examId)}/start?courseTitle=${encodeURIComponent(courseTitle)}`, {method:'POST', credentials:'same-origin'}).then(r=>r.json()),
        questions: (courseTitle) =>
            fetch(`/api/compat/exams/by-course/${encodeURIComponent(courseTitle)}/questions`, {credentials:'same-origin'}).then(r=>r.json()),
        submit:    (courseTitle, payload) =>
            fetch(`/api/compat/exams/by-course/${encodeURIComponent(courseTitle)}/submit`, {method:'POST', headers:{'Content-Type':'application/json'}, credentials:'same-origin', body: JSON.stringify(payload)}).then(r=>r.json())
    };

    // ==== 0) 기존 openExamModal Shim ====
    const prev = window.openExamModal;
    window.openExamModal = async function shimOpenExamModal(arg) {
        // 최대한 안전하게 파라미터 해석 (객체형만 지원)
        const opts = typeof arg === 'object' && arg ? arg : {};
        const examId      = opts.examId || opts.id || opts.exam_id || 0;  // 시험 식별자
        const courseTitle = opts.courseTitle || opts.course || opts.title || 'COURSE';
        if (!examId) { alert('examId가 필요합니다.'); return; }

        // 1) 응시 가능 여부
        const G = await API.elig(examId, courseTitle);
        if (!G.ok) { alert(G.message || '응시여부 확인 실패'); return; }
        if (G.allowed === false && G.reason === 'ALREADY_SUBMITTED') {
            alert('이미 제출한 시험입니다. (1회 응시 제한)');
            return;
        }

        // 2) 토큰 발급(서버 타이머 시작/확인)
        const T = await API.start(examId, courseTitle);
        if (!T.ok) { alert(T.message || '시험 시작 실패'); return; }

        // 3) 문제 불러오기
        const Q = await API.questions(courseTitle);
        if (!Q.ok || !Array.isArray(Q.items) || Q.items.length === 0) {
            alert('문제를 불러오지 못했습니다.');
            return;
        }

        // 4) 모달/타이머 UI
        openUI({ examId, courseTitle, attemptId: T.attemptId, expiresAt: T.expiresAt, items: Q.items });
    };

    // ==== 1) 모달 + 타이머 + 제출 ====
    function openUI({ examId, courseTitle, attemptId, expiresAt, items }) {
        closeUI(); // 중복방지
        const wrap = document.createElement('div');
        wrap.id = 'exam-compat-modal';
        wrap.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;z-index:10000;';
        wrap.innerHTML = `
      <div style="width:min(1100px,94vw);max-height:92vh;background:#fff;border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.25);overflow:hidden;display:grid;grid-template-rows:auto 1fr auto;font-family:inherit;">
        <header style="display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid #eee;">
          <h3 style="margin:0;font-size:18px;font-weight:800;">${escapeHtml(courseTitle)} | 모의고사</h3>
          <div id="timer" style="font-weight:800;">--:--</div>
        </header>
        <section id="examBody" style="padding:14px 18px;overflow:auto;">
          ${items.map((q,idx)=>renderQ(q, idx+1)).join('')}
        </section>
        <footer style="display:flex;gap:10px;justify-content:flex-end;align-items:center;padding:12px 16px;border-top:1px solid #eee;background:#fafafa;">
          <button id="btnCancel" style="padding:10px 14px;border:1px solid #ddd;background:#fff;border-radius:8px;">나가기</button>
          <button id="btnSubmit" style="padding:10px 16px;background:#ffb400;border:none;border-radius:8px;font-weight:800;">제출</button>
        </footer>
      </div>
    `;
        document.body.appendChild(wrap);

        const btnCancel = wrap.querySelector('#btnCancel');
        const btnSubmit = wrap.querySelector('#btnSubmit');
        const timerEl   = wrap.querySelector('#timer');

        btnCancel.onclick = () => {
            if (confirm('정말 나가시겠습니까? (제출 전에는 기록되지 않습니다)')) closeUI();
        };

        btnSubmit.onclick = async () => {
            btnSubmit.disabled = true;
            try {
                const answers = collectAnswers(items);
                const res = await API.submit(courseTitle, { attemptId, examId, courseTitle, answers });
                if (!res.ok) { alert(res.message || '제출 실패'); btnSubmit.disabled=false; return; }
                alert(`제출 완료! 점수: ${res.score}/${res.total}`);
                closeUI();
            } catch (e) {
                console.error(e); alert('제출 중 오류'); btnSubmit.disabled=false;
            }
        };

        // 타이머 (서버 만료시각 기준)
        const end = new Date(expiresAt).getTime();
        const intv = setInterval(() => {
            const now = Date.now();
            let diff = Math.max(0, Math.floor((end - now)/1000));
            const mm = String(Math.floor(diff/60)).padStart(2,'0');
            const ss = String(diff%60).padStart(2,'0');
            timerEl.textContent = `${mm}:${ss}`;
            if (diff <= 0) {
                clearInterval(intv);
                // 자동 제출
                btnSubmit.disabled = true;
                (async () => {
                    try {
                        const answers = collectAnswers(items);
                        const res = await API.submit(courseTitle, { attemptId, examId, courseTitle, answers });
                        alert(res.ok ? `시간 종료로 자동 제출되었습니다. 점수: ${res.score}/${res.total}` : (res.message || '시간 종료'));
                    } finally { closeUI(); }
                })();
            }
        }, 500);
    }

    function collectAnswers(items) {
        return items.map(q => {
            const sel = document.querySelector(`input[name="q_${q.id}"]:checked`);
            return { questionId: q.id, choice: sel ? sel.value : null };
        });
    }

    function renderQ(q, no) {
        const opts = (q.options || []).map((op, i) => {
            const val = String(i+1);
            return `
        <label style="display:flex;gap:8px;align-items:flex-start;padding:6px 8px;border:1px solid #eee;border-radius:8px;">
          <input type="radio" name="q_${q.id}" value="${val}">
          <span>${escapeHtml(String(op ?? ''))}</span>
        </label>`;
        }).join('');
        return `
      <article style="margin-bottom:14px;padding:12px;border:1px solid #eee;border-radius:10px;">
        <div style="font-weight:800;margin-bottom:8px;">Q${no}. ${escapeHtml(String(q.question||''))}</div>
        <div style="display:grid;grid-template-columns:1fr;gap:6px;">${opts}</div>
      </article>
    `;
    }

    function closeUI() {
        const el = document.getElementById('exam-compat-modal');
        if (el) el.remove();
    }

    function escapeHtml(s){return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));}
})();
