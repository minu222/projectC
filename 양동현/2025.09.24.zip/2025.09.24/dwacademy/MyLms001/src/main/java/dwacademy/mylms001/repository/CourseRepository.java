// src/main/java/dwacademy/mylms001/repository/CourseRepository.java
package dwacademy.mylms001.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;

@Repository
public class CourseRepository {

    private final JdbcTemplate jdbc;

    public CourseRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** INSERT into courses, returns generated course_id */
    public long insertCourse(
            int instructorId,
            String title,
            String description,
            String category,
            BigDecimal price,
            boolean isFree,
            String status,
            int studentCount,
            LocalDate expiryDate
    ) {
        final String sql = """
            INSERT INTO courses
              (instructor_id, title, description, category,
               price, is_free, avg_rating, status, student_count, expiry_date,
               created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 0.0, ?, ?, ?, NOW(), NOW())
            """;

        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            int i = 1;
            ps.setInt(i++, instructorId);
            ps.setString(i++, title);
            ps.setString(i++, description);
            ps.setString(i++, category);
            if (price != null) ps.setBigDecimal(i++, price); else ps.setNull(i++, Types.DECIMAL);
            ps.setInt(i++, isFree ? 1 : 0);
            ps.setString(i++, (status == null ? "published" : status));
            ps.setInt(i++, studentCount);
            if (expiryDate != null) ps.setDate(i++, Date.valueOf(expiryDate)); else ps.setNull(i++, Types.DATE);
            return ps;
        }, kh);

        Number key = kh.getKey();
        if (key == null) throw new IllegalStateException("course_id 생성 실패");
        return key.longValue();
    }

    /* ===== (이전 이슈 대응용) 필요 시 사용 ===== */
    public boolean existsById(long id) {
        Integer cnt = jdbc.queryForObject("SELECT COUNT(*) FROM courses WHERE course_id = ?", Integer.class, id);
        return cnt != null && cnt > 0;
    }

    public boolean existsByIdAndInstructor(long id, int instructorId) {
        Integer cnt = jdbc.queryForObject(
                "SELECT COUNT(*) FROM courses WHERE course_id = ? AND instructor_id = ?",
                Integer.class, id, instructorId
        );
        return cnt != null && cnt > 0;
    }

    public int deleteById(long id) {
        return jdbc.update("DELETE FROM courses WHERE course_id = ?", id);
    }

    public int deleteByIdAndInstructor(long id, int instructorId) {
        return jdbc.update("DELETE FROM courses WHERE course_id = ? AND instructor_id = ?", id, instructorId);
    }
}
