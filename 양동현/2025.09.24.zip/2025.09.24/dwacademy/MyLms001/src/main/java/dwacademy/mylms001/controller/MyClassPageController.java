// src/main/java/dwacademy/mylms001/controller/MyClassPageController.java
package dwacademy.mylms001.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/myclass")
public class MyClassPageController {

    // 예: /myclass/lectureroom?courseId=123
    @GetMapping("/lectureroom")
    public String lectureRoom(@RequestParam("courseId") long courseId, Model model) {
        model.addAttribute("courseId", courseId);
        return "myclass/lectureroom"; // => templates/myclass/lectureroom.html
    }

    // (원하면 path variable 버전도 가능)
    // 예: /myclass/lecture/123
    @GetMapping("/lecture/{courseId}")
    public String lectureRoom2(@PathVariable long courseId, Model model) {
        model.addAttribute("courseId", courseId);
        return "myclass/lectureroom";
    }
}
