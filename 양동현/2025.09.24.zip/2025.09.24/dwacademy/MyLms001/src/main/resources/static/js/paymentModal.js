// src/main/resources/static/js/paymentModal.js
(function () {
    function formatWon(v) {
        const n = typeof v === 'number' ? v : Number(v) || 0;
        return n.toLocaleString('ko-KR') + '원';
    }

    function csrfHeaders() {
        const tokenEl = document.querySelector('meta[name="_csrf"]');
        const headerEl = document.querySelector('meta[name="_csrf_header"]');
        const token = tokenEl ? tokenEl.getAttribute('content') : null;
        const headerName = headerEl ? headerEl.getAttribute('content') : null;
        return token && headerName ? { [headerName]: token } : {};
    }

    function hideAllPaymentForms() {
        document.querySelectorAll('.payment-form').forEach(function (f) {
            f.style.display = 'none';
        });
    }

    window.showPaymentForm = function () {
        hideAllPaymentForms();
        const pm = document.getElementById('paymentMethod');
        const method = pm ? pm.value : '';
        if (!method) return;

        const formEl = document.getElementById(method + 'Form');
        if (formEl) formEl.style.display = 'block'; // ✅ 대입의 LHS에 옵셔널 체이닝 사용 금지
    };

    window.closeModal = function () {
        const modal = document.getElementById('paymentModal');
        if (!modal) return;
        modal.style.display = 'none';

        const pm = document.getElementById('paymentMethod');
        if (pm) pm.value = '';
        hideAllPaymentForms();
    };

    /**
     * 결제 모달 열기
     * @param {string} courseName
     * @param {number} price
     * @param {number} qty
     * @param {string} imgUrl
     * @param {string} instructor
     * @param {string} desc
     * @param {number} courseId
     */
    window.goToPayment = function (courseName, price, qty = 1, imgUrl, instructor, desc, courseId) {
        const modal = document.getElementById('paymentModal');
        if (!modal) return;

        const byId = (id) => document.getElementById(id);

        const titleEl = byId('modalCourseName');
        if (titleEl) titleEl.textContent = '결제 - ' + (courseName || '');

        const titleDetailEl = byId('modalCourseNameDetail');
        if (titleDetailEl) titleDetailEl.textContent = courseName || '';

        const priceEl = byId('modalPrice');
        if (priceEl) priceEl.textContent = formatWon(price || 0);

        const qtyEl = byId('modalQty');
        if (qtyEl) qtyEl.textContent = String(qty || 1);

        const totalEl = byId('modalTotal');
        if (totalEl) totalEl.textContent = formatWon((price || 0) * (qty || 1));

        const imgEl = byId('modalImg');
        if (imgUrl && imgEl) imgEl.src = imgUrl;

        const instEl = byId('modalInstructor');
        if (instructor && instEl) instEl.textContent = '강사: ' + instructor;

        const descEl = byId('modalDesc');
        if (desc && descEl) descEl.textContent = desc;

        const hid = byId('modalCourseId');
        if (hid) hid.value = courseId || '';

        modal.style.display = 'flex';
    };

    // 결제 확인 → /api/cart에 장바구니 추가
    window.confirmPayment = async function () {
        const agree1El = document.getElementById('agreeTerms1');
        const agree2El = document.getElementById('agreeTerms2');
        const agree1 = !!(agree1El && agree1El.checked);
        const agree2 = !!(agree2El && agree2El.checked);
        if (!agree1 || !agree2) {
            alert('약관에 모두 동의해야 결제할 수 있습니다.');
            return;
        }

        const cidEl = document.getElementById('modalCourseId');
        const courseId = cidEl ? Number(cidEl.value) : 0;
        if (!courseId) {
            alert('강의 정보를 찾을 수 없습니다.');
            return;
        }

        try {
            const res = await fetch('/api/cart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    ...csrfHeaders(),
                },
                body: JSON.stringify({ courseId }),
            });

            const data = await res.json().catch(() => ({}));
            if (res.status === 401) throw new Error('로그인이 필요합니다.');
            if (res.status === 409) throw new Error(data.message || '이미 장바구니에 담긴 강의입니다.');
            if (!res.ok) throw new Error(data.message || '장바구니 추가에 실패했습니다.');

            alert('결제가 완료되었습니다! 장바구니에 담겼습니다.');
            window.closeModal();
        } catch (e) {
            alert(e.message || '오류가 발생했습니다.');
        }
    };

    // ESC로 닫기
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') window.closeModal();
    });
})();
